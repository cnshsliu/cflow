package com.lkh.cflow.client;

import java.net.URI;
import java.util.ArrayList;
import java.util.List;

import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.NameValuePair;
import org.apache.http.client.HttpClient;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.HttpDelete;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.client.methods.HttpPut;
import org.apache.http.client.utils.URIBuilder;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.message.BasicNameValuePair;
import org.apache.http.protocol.BasicHttpContext;
import org.apache.http.protocol.HttpContext;
import org.apache.http.util.EntityUtils;
import org.apache.log4j.Logger;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;

/**
 * MWFClient is a MWF Restful API wrapper class. MWFClient use <a
 * href="http://hc.apache.org/">Apache HttpComponents</a> to invoke http request
 * to MWF Server.
 * 
 * @author Nean
 * 
 * @version 0.9
 * 
 */
public class MWFClient {
	private static Logger logger = Logger.getLogger(MWFClient.class);
	private static JSONParser parser = new JSONParser();
	private static HttpClient httpclient = new DefaultHttpClient();
	private static HttpContext localContext = new BasicHttpContext();
	private String hostname = "localhost";

	/**
	 * Initiate a MWFClient instance.
	 * 
	 * @param hostname
	 *            The hostname of MWF server, for example, "www.myworldflow.com"
	 * @return a MWFClient instance
	 */
	public static MWFClient newClient(String hostname) {
		MWFClient ret = new MWFClient();
		ret.setHost(hostname);

		return ret;
	}

	/**
	 * Set the hostname of MWF server
	 * 
	 * @param hostname
	 *            the hostname of IP of MWF server
	 */
	public void setHost(String hostname) {
		this.hostname = hostname;
	}

	/**
	 * Delete a workflow template on MWF server
	 * 
	 * @param acsk
	 *            current access session key
	 * @param wftid
	 *            the id of workflow template to be deleted.
	 * @return true if deleted successfully.
	 * @throws Exception
	 */
	public boolean deleteWft(String acsk, String wftid) throws Exception {
		URIBuilder builder = new URIBuilder();
		builder.setScheme("http").setHost(hostname).setPath("/cflow/rest/wft").setParameter("wftid", wftid).setParameter("acsk", acsk);
		return myDelete(builder.build());
	}

	/**
	 * Delete a process (workflow instance) by id
	 * 
	 * @param acsk
	 *            current access key
	 * @param prcid
	 *            the id of process to be deleted
	 * @return true if deleted successfully
	 * @throws Exception
	 */
	public boolean deleteProcess(String acsk, String prcid) throws Exception {
		URIBuilder builder = new URIBuilder();
		builder.setScheme("http").setHost(hostname).setPath("/cflow/rest/process").setParameter("prcid", prcid).setParameter("acsk", acsk);
		return myDelete(builder.build());
	}

	/**
	 * Do a task. When a task is done, MWF will drive the process to move
	 * forward.
	 * 
	 * @param acsk
	 *            current access key.
	 * @param prcid
	 *            the id of the process which the task belong to.
	 * @param nodeid
	 *            the nodeid of the current task, which is the id of it's
	 *            corresponding workflow node.
	 * @param sessid
	 *            the sessid of current task
	 * @param option
	 *            the option value you provided.
	 * @param attachments
	 *            the attachments to this task.
	 * @return the sessid of next task if the current task is done successfully.
	 * @throws Exception
	 */
	public String doTask(String acsk, String prcid, String nodeid, String sessid, String option, String attachments) throws Exception {
		if (option == null)
			option = "DEFAULT";
		List<NameValuePair> formparams = new ArrayList<NameValuePair>();
		formparams.add(new BasicNameValuePair("prcid", prcid));
		formparams.add(new BasicNameValuePair("nodeid", nodeid));
		formparams.add(new BasicNameValuePair("sessid", sessid));
		formparams.add(new BasicNameValuePair("option", option));
		formparams.add(new BasicNameValuePair("acsk", acsk));
		if (attachments != null)
			formparams.add(new BasicNameValuePair("attachments", attachments));

		URIBuilder builder = new URIBuilder();
		builder.setScheme("http").setHost(hostname).setPath("/cflow/rest/task");
		return myPost(builder.build(), formparams);
	}

	/**
	 * Login and get access key to MWF
	 * 
	 * @param user_id
	 *            user's id
	 * @param user_password
	 *            user's password
	 * @return the access key. Access key must be provided for following API
	 *         calls to interact with MWF server. Access key is expired in 30
	 *         minutes.
	 * @throws Exception
	 */
	public String login(String user_id, String user_password) throws Exception {

		List<NameValuePair> formparams = new ArrayList<NameValuePair>();
		formparams.add(new BasicNameValuePair("userid", user_id));
		formparams.add(new BasicNameValuePair("passwd", user_password));

		URIBuilder builder = new URIBuilder();
		builder.setScheme("http").setHost(hostname).setPath("/cflow/rest/user/login");
		return myPost(builder.build(), formparams);

	}

	/**
	 * Get user's profile by access key
	 * 
	 * @param accessKey
	 * @return a JSONObject represents user profile attributes.
	 * @see MWF Restful API
	 * @throws Exception
	 */
	public JSONObject getUserInfo(String accessKey) throws Exception {
		URIBuilder builder = new URIBuilder();
		builder.setScheme("http").setHost(hostname).setPath("/cflow/rest/user").setParameter("acsk", accessKey);
		String ret = myGet(builder.build());
		if (ret != null)
			return (JSONObject) parser.parse(ret);
		else
			return null;
	}

	/**
	 * Register a new account
	 * 
	 * @param accessKey
	 * @param userid
	 * @param username
	 * @param passwd
	 * @param email
	 * @param tzid
	 * @param lang
	 * @return
	 * @throws Exception
	 */
	public String userRegister(String accessKey, String userid, String username, String passwd, String email, String tzid, String lang) throws Exception {

		List<NameValuePair> formparams = new ArrayList<NameValuePair>();
		formparams.add(new BasicNameValuePair("userid", userid));
		formparams.add(new BasicNameValuePair("username", username));
		formparams.add(new BasicNameValuePair("passwd", passwd));
		formparams.add(new BasicNameValuePair("email", email));
		formparams.add(new BasicNameValuePair("tzid", tzid));
		formparams.add(new BasicNameValuePair("lang", lang));
		formparams.add(new BasicNameValuePair("acsk", accessKey));

		URIBuilder builder = new URIBuilder();
		builder.setScheme("http").setHost(hostname).setPath("/cflow/rest/user/new");
		return myPost(builder.build(), formparams);
	}

	/**
	 * Delete a user
	 * 
	 * @param accessKey
	 * @param userid
	 * @return
	 * @throws Exception
	 */
	public boolean deleteUser(String accessKey, String userid) throws Exception {
		URIBuilder builder = new URIBuilder();
		builder.setScheme("http").setHost(hostname).setPath("/cflow/rest/user").setParameter("userid", userid).setParameter("acsk", accessKey);
		return myDelete(builder.build());
	}

	/**
	 * Get a user's work list.
	 * 
	 * @param accessKey
	 *            the access key of a user
	 * @return a JSONArray contains all works assigned to the user.
	 * @throws Exception
	 */
	public JSONArray getWorklist(String accessKey) throws Exception {
		URIBuilder builder = new URIBuilder();
		builder.setScheme("http").setHost(hostname).setPath("/cflow/rest/worklist").setParameter("acsk", accessKey);
		String ret = myGet(builder.build());
		if (ret != null)
			return (JSONArray) parser.parse(ret);
		else
			return null;
	}

	/**
	 * Get a single work item
	 * 
	 * @param worklist
	 *            the JSONArray returned by getWorklist(String accessKey)
	 * @param prcid
	 *            the id of process.
	 * @param nodeid
	 *            the id of template node.
	 * @return a JSONObject represents work item
	 * @see MWF Restful API
	 */
	public JSONObject getWorkitem(JSONArray worklist, String prcid, String nodeid) {
		JSONObject ret = null;
		for (int i = 0; i < worklist.size(); i++) {
			JSONObject wii = (JSONObject) worklist.get(i);
			if (wii.get("PRCID").equals(prcid) && wii.get("NODEID").equals(nodeid)) {
				ret = wii;
				break;
			}
		}
		return ret;
	}

	/**
	 * Upload a workflow template XML to MWF server
	 * 
	 * @param accessKey
	 * @param wft
	 *            the content of template XML
	 * @param wftname
	 *            the name of this template
	 * @return the id of newly created workflow template.
	 * @throws Exception
	 */
	public String uploadWft(String accessKey, String wft, String wftname) throws Exception {
		String ret = null;

		List<NameValuePair> formparams = new ArrayList<NameValuePair>();
		formparams.add(new BasicNameValuePair("wft", wft));
		formparams.add(new BasicNameValuePair("wftname", wftname));
		formparams.add(new BasicNameValuePair("acsk", accessKey));

		URIBuilder builder = new URIBuilder();
		builder.setScheme("http").setHost(hostname).setPath("/cflow/rest/wft");
		return myPost(builder.build(), formparams);

	}

	/**
	 * Get content of a workflow template
	 * 
	 * @param accessKey
	 * @param wftid
	 *            the id of workflow template
	 * @return the content of the workflow template
	 * @throws Exception
	 */
	public String getWftDoc(String accessKey, String wftid) throws Exception {
		URIBuilder builder = new URIBuilder();
		builder.setScheme("http").setHost(hostname).setPath("/cflow/rest/wft/doc").setParameter("wftid", wftid).setParameter("acsk", accessKey);
		String ret = myGet(builder.build());

		return ret;
	}

	/**
	 * Start a workflow. The corresponding process will be created
	 * 
	 * @param accessKey
	 *            current access key
	 * @param startby
	 *            the id of the starter
	 * @param wftid
	 *            the id of tempalte
	 * @param teamid
	 *            the id of team members of which will participate in the
	 *            process.
	 * @param instanceName
	 *            give the newly created process a instance name
	 * @return the id of the newly created process
	 * @throws Exception
	 */
	public String startWorkflow(String accessKey, String startby, String wftid, String teamid, String instanceName) throws Exception {
		List<NameValuePair> formparams = new ArrayList<NameValuePair>();
		formparams.add(new BasicNameValuePair("wftid", wftid));
		formparams.add(new BasicNameValuePair("teamid", teamid));
		formparams.add(new BasicNameValuePair("instancename", instanceName));
		formparams.add(new BasicNameValuePair("startby", startby));
		formparams.add(new BasicNameValuePair("acsk", accessKey));

		URIBuilder builder = new URIBuilder();
		builder.setScheme("http").setHost(hostname).setPath("/cflow/rest/process");
		return myPost(builder.build(), formparams);
	}

	/**
	 * Get contextual variables and their values of a process
	 * 
	 * @param accessKey
	 *            current access key
	 * @param prcid
	 *            the id of the process
	 * @return a JSONObject contains all process contextual varialbes and their
	 *         values.
	 * @see MWF Restful API
	 * @throws Exception
	 * 
	 */
	public JSONObject getPrcVariables(String accessKey, String prcid) throws Exception {
		URIBuilder builder = new URIBuilder();
		builder.setScheme("http").setHost(hostname).setPath("/cflow/rest/process/variables").setParameter("prcid", prcid).setParameter("acsk", accessKey);
		String ret = myGet(builder.build());
		if (ret != null)
			return (JSONObject) parser.parse(ret);
		else
			return null;
	}

	/**
	 * Create a team
	 * 
	 * @param accessKey
	 *            current access key
	 * @param teamName
	 *            the name
	 * @param teamMemo
	 *            the memo
	 * @return the id of newly created team
	 * @throws Exception
	 */
	public String createTeam(String accessKey, String teamName, String teamMemo) throws Exception {
		List<NameValuePair> formparams = new ArrayList<NameValuePair>();
		formparams.add(new BasicNameValuePair("teamname", teamName));
		formparams.add(new BasicNameValuePair("memo", teamMemo));
		formparams.add(new BasicNameValuePair("acsk", accessKey));

		URIBuilder builder = new URIBuilder();
		builder.setScheme("http").setHost(hostname).setPath("/cflow/rest/team");
		return myPost(builder.build(), formparams);
	}

	/**
	 * Add multiple members to a team
	 * 
	 * @param accessKey
	 *            current access key
	 * @param teamid
	 *            the id of the team
	 * @param memberships
	 *            memberships description in JSON format. For example;
	 *            {"USER_ID1":"USER_ROLE1", "USER_ID2":"USER_ROLE2"} It's better
	 *            to construct a JSONObject like this:<BR>
	 *            JSONObject members = new JSONObject(); <BR>
	 *            members.put("U3307", "Approver"); <BR>
	 *            members.put("U3308", "Auditor");
	 *            client.addTeamMembers(accessKey, teamid,
	 *            members.toJSONString());
	 * @return
	 * @throws Exception
	 */
	public String addTeamMembers(String accessKey, String teamid, String memberships) throws Exception {
		List<NameValuePair> formparams = new ArrayList<NameValuePair>();
		formparams.add(new BasicNameValuePair("teamid", teamid));
		formparams.add(new BasicNameValuePair("memberships", memberships));
		formparams.add(new BasicNameValuePair("acsk", accessKey));

		URIBuilder builder = new URIBuilder();
		builder.setScheme("http").setHost(hostname).setPath("/cflow/rest/team/members");
		return myPost(builder.build(), formparams);
	}

	/**
	 * Delete a team from WMF server by it's id
	 * 
	 * @param accessKey
	 *            current access key
	 * @param teamid
	 *            id of the team to be deleted
	 * @return true if success
	 * @throws Exception
	 */
	public boolean deleteTeam(String accessKey, String teamid) throws Exception {
		URIBuilder builder = new URIBuilder();
		builder.setScheme("http").setHost(hostname).setPath("/cflow/rest/team").setParameter("teamid", teamid).setParameter("acsk", accessKey);
		return myDelete(builder.build());
	}

	/**
	 * Get all teams of a user
	 * 
	 * @param accessKey
	 *            the current access key.
	 * @return a JSONArray contains user's teams
	 * @see MWF Restful API
	 * @throws Exception
	 */
	public JSONArray getTeams(String accessKey) throws Exception {
		URIBuilder builder = new URIBuilder();
		builder.setScheme("http").setHost(hostname).setPath("/cflow/rest/team/all").setParameter("acsk", accessKey);
		String ret = myGet(builder.build());
		if (ret != null)
			return (JSONArray) parser.parse(ret);
		else
			return null;
	}

	/**
	 * Get team information by it's id
	 * 
	 * @param accessKey
	 * @param teamid
	 *            the id of the team
	 * @return return a JSONObject describe the team
	 * @throws Exception
	 */
	public JSONObject getTeam(String accessKey, String teamid) throws Exception {
		URIBuilder builder = new URIBuilder();
		builder.setScheme("http").setHost(hostname).setPath("/cflow/rest/team").setParameter("teamid", teamid).setParameter("acsk", accessKey);
		String ret = myGet(builder.build());
		if (ret != null)
			return (JSONObject) parser.parse(ret);
		else
			return null;
	}

	/**
	 * Get the context value of a process
	 * 
	 * @param accessKey
	 *            current access key
	 * @param prcid
	 *            id of the process
	 * @return a JSONObject represent the context value.
	 * @throws Exception
	 */
	public JSONObject getPrcInfo(String accessKey, String prcid) throws Exception {
		URIBuilder builder = new URIBuilder();
		builder.setScheme("http").setHost(hostname).setPath("/cflow/rest/process").setParameter("prcid", prcid).setParameter("acsk", accessKey);
		String ret = myGet(builder.build());
		if (ret != null)
			return (JSONObject) parser.parse(ret);
		else
			return null;
	}

	/**
	 * Get processes by status
	 * 
	 * @param accessKey
	 *            current access key
	 * @param status
	 *            process status, should be one of "running", "suspended",
	 *            "finished", "canceled"
	 * @return a JSONArray of processes.
	 * @throws Exception
	 */
	public JSONArray getProcessesByStatus(String accessKey, String status) throws Exception {
		URIBuilder builder = new URIBuilder();
		builder.setScheme("http").setHost(hostname).setPath("/cflow/rest/process/all").setParameter("status", status).setParameter("acsk", accessKey);
		String ret = myGet(builder.build());
		if (ret != null)
			return (JSONArray) parser.parse(ret);
		else
			return null;
	}

	/**
	 * Create an organization
	 * 
	 * @param accessKey
	 *            current access key
	 * @param orgname
	 *            organization name
	 * @param orgpasswd
	 *            organization password
	 * @param fedpasswd
	 *            federation password, which is required to add this
	 *            organization into a federation
	 * @return
	 * @throws Exception
	 */
	public String createOrg(String accessKey, String orgname, String orgpasswd, String fedpasswd) throws Exception {
		List<NameValuePair> formparams = new ArrayList<NameValuePair>();
		formparams.add(new BasicNameValuePair("orgname", orgname));
		formparams.add(new BasicNameValuePair("orgpwd", orgpasswd));
		formparams.add(new BasicNameValuePair("fedpwd", fedpasswd));
		formparams.add(new BasicNameValuePair("acsk", accessKey));

		URIBuilder builder = new URIBuilder();
		builder.setScheme("http").setHost(hostname).setPath("/cflow/rest/org");
		return myPost(builder.build(), formparams);
	}

	/**
	 * Get information of an organization
	 * 
	 * @param accessKey
	 *            current access key
	 * @param orgid
	 *            id of the organization
	 * @return a JSONObject describes organization
	 * @throws Exception
	 */
	public JSONObject getOrg(String accessKey, String orgid) throws Exception {
		URIBuilder builder = new URIBuilder();
		builder.setScheme("http").setHost(hostname).setPath("/cflow/rest/org").setParameter("orgid", orgid).setParameter("acsk", accessKey);
		String ret = myGet(builder.build());
		if (ret != null)
			return (JSONObject) parser.parse(ret);
		else
			return null;
	}

	/**
	 * Get ids of the users belong to an organization
	 * 
	 * @param accessKey
	 *            current access key
	 * @param orgid
	 *            id of the organization
	 * @return an JSONArray of user ids.
	 * @throws Exception
	 */
	public JSONArray getOrgUserIds(String accessKey, String orgid) throws Exception {
		URIBuilder builder = new URIBuilder();
		builder.setScheme("http").setHost(hostname).setPath("/cflow/rest/org/users").setParameter("orgid", orgid).setParameter("acsk", accessKey);
		String ret = myGet(builder.build());
		if (ret != null)
			return (JSONArray) parser.parse(ret);
		else
			return null;
	}

	/**
	 * Delete an organization from MWF server
	 * 
	 * @param accessKey
	 *            current access key
	 * @param orgid
	 *            id of the organization to be deleted
	 * @return true if success.
	 * @throws Exception
	 */
	public boolean deleteOrg(String accessKey, String orgid) throws Exception {
		URIBuilder builder = new URIBuilder();
		builder.setScheme("http").setHost(hostname).setPath("/cflow/rest/org").setParameter("orgid", orgid).setParameter("acsk", accessKey);
		return myDelete(builder.build());
	}

	/**
	 * Add a single user to organization
	 * 
	 * @param accessKey
	 *            current access key
	 * @param orgid
	 *            id of the organization
	 * @param userid
	 *            user id to add
	 * @return
	 * @throws Exception
	 */
	public String addUserToOrg(String accessKey, String orgid, String userid) throws Exception {
		List<NameValuePair> formparams = new ArrayList<NameValuePair>();
		formparams.add(new BasicNameValuePair("orgid", orgid));
		formparams.add(new BasicNameValuePair("userid", userid));
		formparams.add(new BasicNameValuePair("acsk", accessKey));

		URIBuilder builder = new URIBuilder();
		builder.setScheme("http").setHost(hostname).setPath("/cflow/rest/org/user");
		return myPost(builder.build(), formparams);
	}

	/**
	 * Add many users to an organization
	 * 
	 * @param accessKey
	 *            current access key
	 * @param orgid
	 *            id of the organization
	 * @param userkvs
	 *            a String in JSON format, for example: <BR>
	 *            String userIds =
	 *            "{\"USER1\":\"member\", \"USER2\":\"member\",\"USER3\":\"member\",\"USER4\":\"member\"}"
	 *            ;<BR>
	 *            client.addUsersToOrg(accessKey, orgid_1, userIds);
	 * @return
	 * @throws Exception
	 */
	public String addUsersToOrg(String accessKey, String orgid, String userkvs) throws Exception {
		List<NameValuePair> formparams = new ArrayList<NameValuePair>();
		formparams.add(new BasicNameValuePair("orgid", orgid));
		formparams.add(new BasicNameValuePair("userkvs", userkvs));
		formparams.add(new BasicNameValuePair("acsk", accessKey));

		URIBuilder builder = new URIBuilder();
		builder.setScheme("http").setHost(hostname).setPath("/cflow/rest/org/users");
		return myPost(builder.build(), formparams);
	}

	/**
	 * Delete a user from a organization
	 * 
	 * @param accessKey
	 *            current access key
	 * @param orgid
	 *            id of the organization
	 * @param userid
	 *            id of the user to be removed from organization
	 * @return true if success
	 * @throws Exception
	 */
	public boolean deleteUserFromOrg(String accessKey, String orgid, String userid) throws Exception {
		URIBuilder builder = new URIBuilder();
		builder.setScheme("http").setHost(hostname).setPath("/cflow/rest/org/user").setParameter("orgid", orgid).setParameter("userid", userid).setParameter("acsk", accessKey);
		return myDelete(builder.build());
	}

	/**
	 * Get workflow templates user can use
	 * 
	 * @param accessKey
	 *            current access key
	 * @return a JSONArray of workflow templates information
	 * @throws Exception
	 */
	public JSONArray getWfts(String accessKey) throws Exception {
		URIBuilder builder = new URIBuilder();
		builder.setScheme("http").setHost(hostname).setPath("/cflow/rest/wft/all").setParameter("acsk", accessKey);
		String ret = myGet(builder.build());
		if (ret != null)
			return (JSONArray) parser.parse(ret);
		else
			return null;
	}

	/**
	 * Get own workflow tempaltes of a user
	 * 
	 * @param accessKey
	 *            current access key
	 * @return a JSONArray of workflow templates information
	 * @throws Exception
	 */
	public JSONArray getOwnWfts(String accessKey) throws Exception {
		URIBuilder builder = new URIBuilder();
		builder.setScheme("http").setHost(hostname).setPath("/cflow/rest/wft/own").setParameter("acsk", accessKey);
		String ret = myGet(builder.build());
		if (ret != null)
			return (JSONArray) parser.parse(ret);
		else
			return null;
	}

	/**
	 * Suspend a process
	 * 
	 * @param accessKey
	 *            current access key
	 * @param prcid
	 *            id of the process to be suspended
	 * @return
	 * @throws Exception
	 */
	public boolean suspendProcess(String accessKey, String prcid) throws Exception {
		return _changeProcessStatus(accessKey, prcid, "suspendProcess");
	}

	/**
	 * Resume a process
	 * 
	 * @param accessKey
	 *            current access key
	 * @param prcid
	 *            id of the process to be resumed
	 * @return
	 * @throws Exception
	 */
	public boolean resumeProcess(String accessKey, String prcid) throws Exception {
		return _changeProcessStatus(accessKey, prcid, "resumeProcess");
	}

	/**
	 * Suspend a work
	 * 
	 * @param accessKey
	 *            current access key
	 * @param prcid
	 *            id of the process this work belongs to
	 * @param nodeid
	 *            id of the node to be suspended
	 * @return
	 * @throws Exception
	 */
	public boolean suspendWork(String accessKey, String prcid, String nodeid) throws Exception {
		return _changeWorkStatus(accessKey, prcid, nodeid, "suspendWork");
	}

	/**
	 * Resume a work
	 * 
	 * @param accessKey
	 *            current access key
	 * @param prcid
	 *            id of the process this work belongs to
	 * @param nodeid
	 *            id of the node to be resumed
	 * @return
	 * @throws Exception
	 */
	public boolean resumeWork(String accessKey, String prcid, String nodeid) throws Exception {
		return _changeWorkStatus(accessKey, prcid, nodeid, "resumeWork");
	}

	/**
	 * @param accessKey
	 * @param prcid
	 * @param action
	 * @return
	 * @throws Exception
	 */
	private boolean _changeProcessStatus(String accessKey, String prcid, String action) throws Exception {
		URIBuilder builder = new URIBuilder();
		builder.setScheme("http").setHost(hostname).setPath("/cflow/rest/process/status").setParameter("prcid", prcid).setParameter("action", action).setParameter("acsk", accessKey);
		return myPut(builder.build());
	}

	/**
	 * @param accessKey
	 * @param prcid
	 * @param nodeid
	 * @param action
	 * @return
	 * @throws Exception
	 */
	private boolean _changeWorkStatus(String accessKey, String prcid, String nodeid, String action) throws Exception {
		URIBuilder builder = new URIBuilder();
		builder.setScheme("http").setHost(hostname).setPath("/cflow/rest/process/status").setParameter("prcid", prcid).setParameter("nodeid", nodeid).setParameter("action", action).setParameter("acsk", accessKey);
		return myPut(builder.build());
	}

	/**
	 * Delete a task from delegater to delegatee
	 * 
	 * @param accessKey
	 *            current access key
	 * @param prcid
	 *            process id
	 * @param sessid
	 *            sessid of the task
	 * @param delegater
	 *            delegate from delegater
	 * @param delegatee
	 *            delegate to delegatee
	 * @return
	 * @throws Exception
	 */
	public String delegate(String accessKey, String prcid, String sessid, String delegater, String delegatee) throws Exception {
		List<NameValuePair> formparams = new ArrayList<NameValuePair>();
		formparams.add(new BasicNameValuePair("delegater", delegater));
		formparams.add(new BasicNameValuePair("delegatee", delegatee));
		formparams.add(new BasicNameValuePair("prcid", prcid));
		formparams.add(new BasicNameValuePair("sessid", sessid));
		formparams.add(new BasicNameValuePair("acsk", accessKey));

		URIBuilder builder = new URIBuilder();
		builder.setScheme("http").setHost(hostname).setPath("/cflow/rest/delegation");
		return myPost(builder.build(), formparams);
	}

	/**
	 * Create a fedeeration
	 * 
	 * @param accessKey
	 *            current access key
	 * @param fedname
	 *            federation name
	 * @param fedpasswd
	 *            federation password
	 * @return
	 * @throws Exception
	 */
	public String createFed(String accessKey, String fedname, String fedpasswd) throws Exception {
		List<NameValuePair> formparams = new ArrayList<NameValuePair>();
		formparams.add(new BasicNameValuePair("fedname", fedname));
		formparams.add(new BasicNameValuePair("fedpwd", fedpasswd));
		formparams.add(new BasicNameValuePair("acsk", accessKey));

		URIBuilder builder = new URIBuilder();
		builder.setScheme("http").setHost(hostname).setPath("/cflow/rest/fed");
		return myPost(builder.build(), formparams);
	}

	/**
	 * Get a federation information
	 * 
	 * @param accessKey
	 *            current access key
	 * @param fedid
	 *            the id of the federation
	 * @return a JSONObject presents federation
	 * @throws Exception
	 */
	public JSONObject getFed(String accessKey, String fedid) throws Exception {
		URIBuilder builder = new URIBuilder();
		builder.setScheme("http").setHost(hostname).setPath("/cflow/rest/fed").setParameter("fedid", fedid).setParameter("acsk", accessKey);
		String ret = myGet(builder.build());
		if (ret != null)
			return (JSONObject) parser.parse(ret);
		else
			return null;
	}

	/**
	 * Get organization ids in a federation
	 * 
	 * @param accessKey
	 *            current access key
	 * @param fedid
	 *            id of the federation
	 * @return a JSONObject of organization ids
	 * @throws Exception
	 */
	public JSONObject getFedOrgIds(String accessKey, String fedid) throws Exception {
		URIBuilder builder = new URIBuilder();
		builder.setScheme("http").setHost(hostname).setPath("/cflow/rest/fed/orgs").setParameter("fedid", fedid).setParameter("acsk", accessKey);
		String ret = myGet(builder.build());
		if (ret != null)
			return (JSONObject) parser.parse(ret);
		else
			return null;
	}

	/**
	 * Delete a federation from MWF server
	 * 
	 * @param accessKey
	 *            current access key
	 * @param fedid
	 *            id of the federation to be deleted
	 * @return
	 * @throws Exception
	 */
	public boolean deleteFed(String accessKey, String fedid) throws Exception {
		URIBuilder builder = new URIBuilder();
		builder.setScheme("http").setHost(hostname).setPath("/cflow/rest/fed").setParameter("fedid", fedid).setParameter("acsk", accessKey);
		return myDelete(builder.build());
	}

	/**
	 * Add a organization to federation
	 * 
	 * @param accessKey
	 *            current access key
	 * @param fedid
	 *            id of the federation
	 * @param orgid
	 *            id of the organization
	 * @param fedpwd
	 *            password of the federation
	 * @param orgfedpwd
	 *            fed-password of the organization
	 * @return
	 * @throws Exception
	 */
	public String addOrgToFed(String accessKey, String fedid, String orgid, String fedpwd, String orgfedpwd) throws Exception {
		List<NameValuePair> formparams = new ArrayList<NameValuePair>();
		formparams.add(new BasicNameValuePair("fedid", fedid));
		formparams.add(new BasicNameValuePair("orgid", orgid));
		formparams.add(new BasicNameValuePair("fedpwd", fedpwd));
		formparams.add(new BasicNameValuePair("orgfedpwd", orgfedpwd));
		formparams.add(new BasicNameValuePair("acsk", accessKey));

		URIBuilder builder = new URIBuilder();
		builder.setScheme("http").setHost(hostname).setPath("/cflow/rest/fed/org");
		return myPost(builder.build(), formparams);
	}

	/**
	 * Delete a organization from a federation
	 * 
	 * @param accessKey
	 *            current access key
	 * @param fedid
	 *            id of the federation
	 * @param orgid
	 *            id of the organization
	 * @return
	 * @throws Exception
	 */
	public boolean deleteOrgFromFed(String accessKey, String fedid, String orgid) throws Exception {
		URIBuilder builder = new URIBuilder();
		builder.setScheme("http").setHost(hostname).setPath("/cflow/rest/fed/org").setParameter("fedid", fedid).setParameter("orgid", orgid).setParameter("acsk", accessKey);
		return myDelete(builder.build());
	}

	/**
	 * Determine if usr1 and user2 belongs to one organization or organizations
	 * in one federation
	 * 
	 * @param accessKey
	 * @param usr1
	 *            id of user
	 * @param usr2
	 *            id of another user
	 * @return true or false
	 * @throws Exception
	 */
	public boolean sameOrgxFed(String accessKey, String usr1, String usr2) throws Exception {
		URIBuilder builder = new URIBuilder();
		builder.setScheme("http").setHost(hostname).setPath("/cflow/rest/user/together").setParameter("usr1", usr1).setParameter("usr2", usr2).setParameter("acsk", accessKey);
		String ret = myGet(builder.build());
		if (ret != null)
			return true;
		else
			return false;
	}

	private String myGet(URI url) throws Exception {
		String ret = null;
		HttpGet httpGet = new HttpGet(url);
		HttpResponse response = httpclient.execute(httpGet, localContext);
		try {
			int statusCode = response.getStatusLine().getStatusCode();
			HttpEntity entity = response.getEntity();
			if (statusCode == 200) {
				ret = EntityUtils.toString(entity);
			} else {
				logger.error("Response status " + statusCode + ": " + EntityUtils.toString(entity));
				ret = null;
			}
			EntityUtils.consume(entity);
			return ret;
		} finally {
			httpGet.releaseConnection();
		}
	}

	private boolean myDelete(URI url) throws Exception {
		boolean ret = false;
		HttpDelete httpDelete = new HttpDelete(url);
		HttpResponse response = httpclient.execute(httpDelete, localContext);
		try {
			int statusCode = response.getStatusLine().getStatusCode();
			HttpEntity entity = response.getEntity();
			if (statusCode == 200) {
				ret = true;
			} else {
				logger.error("Response status " + statusCode + ": " + EntityUtils.toString(entity));
				ret = false;
			}
			EntityUtils.consume(entity);

			return ret;
		} finally {
			httpDelete.releaseConnection();
		}
	}

	private boolean myPut(URI url) throws Exception {
		boolean ret = false;
		HttpPut httpPut = new HttpPut(url);
		HttpResponse response = httpclient.execute(httpPut, localContext);
		try {
			int statusCode = response.getStatusLine().getStatusCode();
			HttpEntity entity = response.getEntity();
			if (statusCode == 200) {
				ret = true;
			} else {
				logger.error("Response status " + statusCode + ": " + EntityUtils.toString(entity));
				ret = false;
			}
			EntityUtils.consume(entity);

			return ret;
		} finally {
			httpPut.releaseConnection();
		}
	}

	private String myPost(URI url, List<NameValuePair> formparams) throws Exception {
		String ret = null;

		HttpPost httpPost = new HttpPost(url);
		UrlEncodedFormEntity entity = new UrlEncodedFormEntity(formparams, "UTF-8");
		httpPost.setEntity(entity);

		HttpResponse response = httpclient.execute(httpPost, localContext);
		try {
			int statusCode = response.getStatusLine().getStatusCode();
			HttpEntity entity_return = response.getEntity();
			if (statusCode == 200) {
				ret = EntityUtils.toString(entity_return);
			} else {
				logger.error("Response status " + statusCode + ": " + EntityUtils.toString(entity_return));
				ret = null;
			}
			EntityUtils.consume(entity);

			return ret;
		} finally {
			httpPost.releaseConnection();
		}
	}
}
