package com.lkh.cflow.test;

import org.apache.log4j.ConsoleAppender;
import org.apache.log4j.Logger;
import org.apache.log4j.SimpleLayout;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;

import com.lkh.cflow.client.MWFClient;

public class MWFDemoApplication {
	private static String hostname = "localhost:8080";
	String accessKey = null;
	private static JSONParser parser = new JSONParser();
	private static Logger logger = Logger.getLogger(MWFDemoApplication.class);
	private static MWFClient client = MWFClient.newClient(hostname);

	public static void main(String[] args) {
		MWFDemoApplication app = new MWFDemoApplication();
		try {
			app.demo();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	private void demo() throws Exception {
		setUp();
		demoLogin();
		demoRegister();
		demoOrg();
		demoWorkflowTemplates();
		demoProcess();
		demoProcess_1();
		demoProcess_2();
		demoProcess_3();
		demoProcess_4();
		demoProcess_5();

		tearDown();

	}

	public void setUp() throws Exception {
		SimpleLayout layout = new SimpleLayout();
		ConsoleAppender appender = new ConsoleAppender(layout);
		logger.addAppender(appender);

		// String userJSON = getUserInfo(accessKey).toJSONString();
	}

	public void tearDown() throws Exception {
	}

	public void demoLogin() throws Exception {
		logger.debug("entering demoLogin");

		String tmp = client.login("U3306", "abcd0");

		tmp = client.login("U3306", "abcd");
		logger.debug("leaving demoLogin");

	}

	public void demoRegister() throws Exception {
		logger.debug("entering demoReigster");
		accessKey = client.login("U3306", "abcd");
		client.userRegister(accessKey, "TEST_1", "TEST_1", "TEST_1", "TEST_1@abc.com", "GMT+08:00", "en_US");
		client.userRegister(accessKey, "TEST_2", "TEST_2", "TEST_2", "TEST_2@abc.com", "GMT+08:00", "en_US");
		client.userRegister(accessKey, "TEST_3", "TEST_3", "TEST_3", "TEST_3@abc.com", "GMT+08:00", "en_US");
		client.userRegister(accessKey, "TEST_4", "TEST_4", "TEST_4", "TEST_4@abc.com", "GMT+08:00", "en_US");

		client.deleteUser(accessKey, "TEST_1");
		client.deleteUser(accessKey, "TEST_2");
		client.deleteUser(accessKey, "TEST_3");
		client.deleteUser(accessKey, "TEST_4");
		logger.debug("leaving demoRegister");
	}

	public void demoOrg() throws Exception {
		logger.debug("entering demoOrg");
		accessKey = client.login("U3306", "abcd");
		// Create org.
		String orgid_1 = client.createOrg(accessKey, "my org", "my passwd", "my fed passwd");

		JSONObject tmpOrg = client.getOrg(accessKey, orgid_1);
		String theOrgId = (String) tmpOrg.get("ORGID");

		JSONArray memberIds = client.getOrgUserIds(accessKey, orgid_1);

		client.addUserToOrg(accessKey, orgid_1, "U3307");
		memberIds = client.getOrgUserIds(accessKey, orgid_1);

		String userIds = "{\"U3308\":\"member\", \"U3309\":\"member\",\"U3310\":\"member\",\"U3311\":\"member\"}";
		client.addUsersToOrg(accessKey, orgid_1, userIds);
		memberIds = client.getOrgUserIds(accessKey, orgid_1);

		client.deleteUserFromOrg(accessKey, orgid_1, "U3310");
		client.deleteUserFromOrg(accessKey, orgid_1, "U3311");
		memberIds = client.getOrgUserIds(accessKey, orgid_1);

		client.deleteUserFromOrg(accessKey, orgid_1, "U4410");

		String orgid_2 = client.createOrg(accessKey, "my org 2", "my passwd 2", "my fed passwd 2");
		client.addUsersToOrg(accessKey, orgid_2, "{\"U3308\":\"member\", \"U3310\":\"member\"}");

		logger.debug("leavinig demoOrg");
	}

	public void demoWorkflowTemplates() throws Exception {
		logger.debug("entering demoWorkflowTemplates");
		accessKey = client.login("U3306", "abcd");

		String wft = "<?xml version=\"1.0\" encoding=\"UTF-8\"?><cf:workflow xsi:schemaLocation=\"http://lkh.com/cflow ../schemas/wft.xsd\" name=\"tobedelete\" owner=\"U3306\" acl=\"private\" lastModified=\"2011-03-19T04:18:58\" created=\"2011-03-19T04:18:58\" xmlns:cf=\"http://lkh.com/cflow\" xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\">"
				+ "<node id=\"58DE1222-4446-C2DE-1F8B-CA9EBE43C965\" type=\"start\" title=\"Start\" name=\"Start\" x=\"27\" y=\"213\">\n <next targetID=\"5094DF39-F83A-BE01-3FE0-CA9EC768D9B7\"/></node>"
				+ "<node id=\"7E40C95C-333D-964E-2EA3-CA9EBE457AE1\" type=\"end\" title=\"End\" name=\"End\" x=\"738\" y=\"213\">\n <next targetID=\"7E40C95C-333D-964E-2EA3-CA9EBE457AE1\"/></node>"
				+ "<node id=\"5094DF39-F83A-BE01-3FE0-CA9EC768D9B7\" type=\"task\" title=\"Task\" name=\"Task\" x=\"356\" y=\"203\" acquirable=\"false\" acqThreshold=\"1\" allowRoleChange=\"false\" allowDelegate=\"false\" allowAdhoc=\"false\" roleToChange=\"all\" form=\"\" mpsm=\"1\">\n <taskto type=\"role\" whom=\"starter\"/>\n <mpcdc/>\n <oec/>\n <next targetID=\"7E40C95C-333D-964E-2EA3-CA9EBE457AE1\"/>\n </node>"
				+ "</cf:workflow>";
		String wftname = "rstest1";

		String wftid = client.uploadWft(accessKey, wft, wftname);

		String theWft = client.getWftDoc(accessKey, wftid);

		JSONArray wfts = client.getOwnWfts(accessKey);

		// 依次删除新建的这些模板
		for (int i = 0; i < wfts.size(); i++) {
			JSONObject aWft = (JSONObject) wfts.get(i);
			if (aWft.get("WFTNAME").equals(wftname)) {
				String tmp = (String) aWft.get("WFTID");
			}
		}
		wfts = client.getOwnWfts(accessKey);
		// 此时，未必>0, 所以用>=0
		// 依次检查每个模板，并统计所以名字为测试名字的模板个数
		int numberOfTestWft = 0;
		for (int i = 0; i < wfts.size(); i++) {
			JSONObject aWft = (JSONObject) wfts.get(i);
			if (aWft.get("WFTNAME").equals(wftname)) {
				numberOfTestWft++;
			}
		}
		// 这个数字应该全部为零。

		logger.debug("leavinig demoWorkflowTemplates");
	}

	public void demoTeams() throws Exception {
		logger.debug("entering demoTeams");
		accessKey = client.login("U3306", "abcd");

		// 取得已有的Teams

		JSONArray existing_teams = client.getTeams(accessKey);

		// // Create a new team demo_team1
		String teamid = client.createTeam(accessKey, "test_team1", "test_team1_memo");

		// 再次取得所有的Teams
		JSONArray new_existing_teams = client.getTeams(accessKey);

		// 应该比以前多了一个Team

		// 根据ID取得Team对象
		JSONObject theTeam = client.getTeam(accessKey, teamid);

		// 删除所有名字为test_team1的Team
		for (int i = 0; i < new_existing_teams.size(); i++) {
			JSONObject aTeam = (JSONObject) new_existing_teams.get(i);
			String aTeam_id = (String) aTeam.get("ID");

		}

		// 再次尝试取这个Team， 应失败
		theTeam = client.getTeam(accessKey, teamid);

		logger.debug("leavinig demoTeams");
	}

	public void demoProcess() throws Exception {
		logger.debug("entering demoProcess");
		accessKey = client.login("U3306", "abcd");

		// 新建一个模板， 里面有一个活动，给到流程启动者
		String wft = "<?xml version=\"1.0\" encoding=\"UTF-8\"?><cf:workflow xsi:schemaLocation=\"http://lkh.com/cflow ../schemas/wft.xsd\" name=\"tobedelete\" owner=\"U3306\" acl=\"private\" lastModified=\"2011-03-19T04:18:58\" created=\"2011-03-19T04:18:58\" xmlns:cf=\"http://lkh.com/cflow\" xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\">"
				+ "<node id=\"58DE1222-4446-C2DE-1F8B-CA9EBE43C965\" type=\"start\" title=\"Start\" name=\"Start\" x=\"27\" y=\"213\">\n <next targetID=\"id_1\"/></node>"
				+ "<node id=\"7E40C95C-333D-964E-2EA3-CA9EBE457AE1\" type=\"end\" title=\"End\" name=\"End\" x=\"738\" y=\"213\">\n <next targetID=\"7E40C95C-333D-964E-2EA3-CA9EBE457AE1\"/></node>"
				+ "<node id=\"id_1\" type=\"task\" title=\"Task\" name=\"Task\" x=\"356\" y=\"203\" acquirable=\"false\" acqThreshold=\"1\" allowRoleChange=\"false\" allowDelegate=\"false\" allowAdhoc=\"false\" roleToChange=\"all\" form=\"\" mpsm=\"1\">\n <taskto type=\"role\" whom=\"starter\"/>\n <mpcdc/>\n <oec/>\n <next targetID=\"7E40C95C-333D-964E-2EA3-CA9EBE457AE1\"/>\n </node>"
				+ "</cf:workflow>";
		String wftname = "rstest1";

		String wftid = client.uploadWft(accessKey, wft, wftname);

		// 从系统中取出这个模板
		String theWft = client.getWftDoc(accessKey, wftid);
		// 其内容应该与前面创建的模板内容一致

		// 新建一个Team
		String teamid = client.createTeam(accessKey, "test_team2", "test_team2_memo");

		// 取正在运行的进程
		JSONArray runningProcs = client.getProcessesByStatus(accessKey, "running");
		int running_processes_number = runningProcs.size();

		// 启动进程
		String prcid = client.startWorkflow(accessKey, "U3306", wftid, teamid, "test_process2");

		// 重新取出正在运行的进程，其个数应该增加了1
		runningProcs = client.getProcessesByStatus(accessKey, "running");
		int new_running_processes_number = runningProcs.size();

		// 取该进程的内容（JSON格式）
		JSONObject prcJson = client.getPrcInfo(accessKey, prcid);

		// 取得worklist, 找到属于该进程的那个work
		JSONArray wlist = client.getWorklist(accessKey);
		JSONObject theWii = client.getWorkitem(wlist, prcid, "id_1");

		// Suspend该进程
		boolean tt = client.suspendProcess(accessKey, prcid);

		// 再取worklist, 应该找不到前面那个work
		wlist = client.getWorklist(accessKey);
		theWii = client.getWorkitem(wlist, prcid, "id_1");

		// Resume该进程
		tt = client.resumeProcess(accessKey, prcid);

		// 再取worklist, 应该再次找到前面那个work
		wlist = client.getWorklist(accessKey);
		theWii = client.getWorkitem(wlist, prcid, "id_1");
		String theNodeId = (String) theWii.get("NODEID");

		// 取得当前活动节点
		// 挂起这个节点
		client.suspendWork(accessKey, prcid, theNodeId);

		// 再取worklist, 应该找不到前面那个work
		wlist = client.getWorklist(accessKey);
		theWii = client.getWorkitem(wlist, prcid, "id_1");

		// 恢复这个节点
		client.resumeWork(accessKey, prcid, theNodeId);

		// 再取worklist, 应该再次找到前面那个work
		wlist = client.getWorklist(accessKey);
		theWii = client.getWorkitem(wlist, prcid, "id_1");

		// 使用用户U3307登录
		String U3307_accessKey = client.login("U3307", "abcd");
		// 取U3307的Worklist
		JSONArray U3307_wlist = client.getWorklist(U3307_accessKey);

		// 测试Delegation.
		// U3306将工作委托给U3307
		String ret = client.delegate(accessKey, (String) theWii.get("PRCID"), (String) theWii.get("SESSID"), "U3306", "U3307");

		// 再取U3307的Worklist， U3307的工作列表中应该多了一个。
		JSONArray U3307_new_wlist = client.getWorklist(U3307_accessKey);
		JSONObject U3307_theWii = client.getWorkitem(U3307_new_wlist, prcid, "id_1");

		// 完成这个work
		client.doTask(U3307_accessKey, (String) U3307_theWii.get("PRCID"), (String) U3307_theWii.get("NODEID"), (String) U3307_theWii.get("SESSID"), null, null);

		// 再次看这个进程的状态，应该是完成状态
		prcJson = client.getPrcInfo(U3307_accessKey, (String) U3307_theWii.get("PRCID"));

		// 删除这个新进程

		// 删除前面测试创建的Team

		// 删除这个模板

		logger.debug("leavinig demoProcess");
	}

	// 测试工作流模板中制定活动给特定的用户名 <taskto type=\"person\" whom=\"U3307\"/>\
	public void demoProcess_1() throws Exception {
		logger.debug("entering demoProcess_1");
		accessKey = client.login("U3306", "abcd");

		// 新建一个模板， 活动id_1，给到流程启动者
		// 活动 id_2, 制定给到U3307
		String wft = "<?xml version=\"1.0\" encoding=\"UTF-8\"?><cf:workflow xsi:schemaLocation=\"http://lkh.com/cflow ../schemas/wft.xsd\" name=\"tobedelete\" owner=\"U3306\" acl=\"private\" lastModified=\"2011-03-19T04:18:58\" created=\"2011-03-19T04:18:58\" xmlns:cf=\"http://lkh.com/cflow\" xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\">"
				+ "<node id=\"id_start\" type=\"start\" title=\"Start\" name=\"Start\" x=\"27\" y=\"213\">\n <next targetID=\"id_1\"/></node>"
				+ "<node id=\"id_end\" type=\"end\" title=\"End\" name=\"End\" x=\"738\" y=\"213\">\n <next targetID=\"id_end\"/></node>"
				+ "<node id=\"id_1\" type=\"task\" title=\"Apply Leaving\" name=\"Apply Leaving\" x=\"356\" y=\"203\" acquirable=\"false\" acqThreshold=\"1\" allowRoleChange=\"false\" allowDelegate=\"false\" allowAdhoc=\"false\" roleToChange=\"all\" form=\"\" mpsm=\"1\">\n <taskto type=\"role\" whom=\"starter\"/>\n <mpcdc/>\n <oec/>\n <next targetID=\"id_2\"/>\n </node>"
				+ "<node id=\"id_2\" type=\"task\" title=\"Approve Leaving\" name=\"Approve Leaving\" x=\"356\" y=\"203\" acquirable=\"false\" acqThreshold=\"1\" allowRoleChange=\"false\" allowDelegate=\"false\" allowAdhoc=\"false\" roleToChange=\"all\" form=\"\" mpsm=\"1\">\n <taskto type=\"person\" whom=\"U3307\"/>\n <mpcdc/>\n <oec/>\n <next targetID=\"id_end\"/>\n </node>"
				+ "</cf:workflow>";
		String wftid = client.uploadWft(accessKey, wft, "testProcess_1");

		// 从系统中取出这个模板
		String theWft = client.getWftDoc(accessKey, wftid);
		// 其内容应该与前面创建的模板内容一致

		// 启动进程
		String prcid = client.startWorkflow(accessKey, "U3306", wftid, "GLOBAL", "testProcess_1");

		// 取该进程的内容（JSON格式）
		JSONObject prcJson = client.getPrcInfo(accessKey, prcid);
		String thePrcId = (String) prcJson.get("PRCID");

		// 取得worklist, 找到属于该进程的那个work
		JSONArray wlist = client.getWorklist(accessKey);
		JSONObject theWii = client.getWorkitem(wlist, prcid, "id_1");

		// 完成这个work
		client.doTask(accessKey, prcid, (String) theWii.get("NODEID"), (String) theWii.get("SESSID"), null, null);

		// 使用用户U3307登录
		String U3307_accessKey = client.login("U3307", "abcd");
		// 取U3307的Worklist
		JSONArray U3307_wlist = client.getWorklist(U3307_accessKey);

		JSONObject U3307_theWii = client.getWorkitem(U3307_wlist, prcid, "id_2");

		client.doTask(U3307_accessKey, (String) U3307_theWii.get("PRCID"), (String) U3307_theWii.get("NODEID"), (String) U3307_theWii.get("SESSID"), null, null);

		// 再次看这个进程的状态，应该是完成状态
		prcJson = client.getPrcInfo(accessKey, prcid);

		// U3307 再取worklist, 应该找不到前面那个work
		U3307_wlist = client.getWorklist(U3307_accessKey);
		U3307_theWii = client.getWorkitem(U3307_wlist, prcid, "id_5");

		// 删除这个新进程
		client.deleteProcess(accessKey, prcid);

		// 删除这个模板
		client.deleteWft(accessKey, wftid);

		logger.debug("leavinig demoProcess_1");
	}

	// 测试工作流模板中制定活动给特定的角色和reference
	public void demoProcess_2() throws Exception {
		logger.debug("entering demoProcess_2");
		accessKey = client.login("U3306", "abcd");

		String org1 = client.createOrg(accessKey, "my org1", "my passwd", "my fed passwd");
		String org2 = client.createOrg(accessKey, "my org2", "my passwd", "my fed passwd");
		client.addUserToOrg(accessKey, org1, "U3306");
		client.addUserToOrg(accessKey, org2, "U3306");
		client.addUserToOrg(accessKey, org1, "U3307");
		client.addUserToOrg(accessKey, org2, "U3308");
		JSONArray memberIds = client.getOrgUserIds(accessKey, org1);
		memberIds = client.getOrgUserIds(accessKey, org2);

		// 新建一个模板， 活动id_1，给到流程启动者
		// 活动 id_2, 给到 role Approver
		// 活动 id_3, 给到 role Auditor
		// 活动 id_4, 给到 与id_2一样
		// 活动 id_5, 给到 与id_1一样
		// 活动 id_6, 给到 person U3307
		String wft = "<?xml version=\"1.0\" encoding=\"UTF-8\"?><cf:workflow xsi:schemaLocation=\"http://lkh.com/cflow ../schemas/wft.xsd\" name=\"tobedelete\" owner=\"U3306\" acl=\"private\" lastModified=\"2011-03-19T04:18:58\" created=\"2011-03-19T04:18:58\" xmlns:cf=\"http://lkh.com/cflow\" xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\">"
				+ "<node id=\"id_start\" type=\"start\" title=\"Start\" name=\"Start\" x=\"27\" y=\"213\">\n <next targetID=\"id_1\"/></node>"
				+ "<node id=\"id_end\" type=\"end\" title=\"End\" name=\"End\" x=\"738\" y=\"213\">\n <next targetID=\"id_end\"/></node>"
				+ "<node id=\"id_1\" type=\"task\" title=\"Apply Leaving\" name=\"Apply Leaving\" x=\"356\" y=\"203\" acquirable=\"false\" acqThreshold=\"1\" allowRoleChange=\"false\" allowDelegate=\"false\" allowAdhoc=\"false\" roleToChange=\"all\" form=\"\" mpsm=\"1\">\n <taskto type=\"role\" whom=\"starter\"/>\n <mpcdc/>\n <oec/>\n <next targetID=\"id_2\"/>\n </node>"
				+ "<node id=\"id_2\" type=\"task\" title=\"Approve Leaving\" name=\"Approve Leaving\" x=\"356\" y=\"203\" acquirable=\"false\" acqThreshold=\"1\" allowRoleChange=\"false\" allowDelegate=\"false\" allowAdhoc=\"false\" roleToChange=\"all\" form=\"\" mpsm=\"1\">\n <taskto type=\"role\" whom=\"Approver\"/>\n <mpcdc/>\n <oec/>\n <next targetID=\"id_3\"/>\n </node>"
				+ "<node id=\"id_3\" type=\"task\" title=\"Auditor Leaving\" name=\"Auditor Leaving\" x=\"356\" y=\"203\" acquirable=\"false\" acqThreshold=\"1\" allowRoleChange=\"false\" allowDelegate=\"false\" allowAdhoc=\"false\" roleToChange=\"all\" form=\"\" mpsm=\"1\">\n <taskto type=\"role\" whom=\"Auditor\"/>\n <mpcdc/>\n <oec/>\n <next targetID=\"id_4\"/>\n </node>"
				+ "<node id=\"id_4\" type=\"task\" title=\"Approver Check Result\" name=\"Approver Check Result\" x=\"356\" y=\"203\" acquirable=\"false\" acqThreshold=\"1\" allowRoleChange=\"false\" allowDelegate=\"false\" allowAdhoc=\"false\" roleToChange=\"all\" form=\"\" mpsm=\"1\">\n <taskto type=\"RefertoNode\" whom=\"id_2\"/>\n <mpcdc/>\n <oec/>\n <next targetID=\"id_5\"/>\n </node>"
				+ "<node id=\"id_5\" type=\"task\" title=\"Starter Check Result\" name=\"Starter Check Result\" x=\"356\" y=\"203\" acquirable=\"false\" acqThreshold=\"1\" allowRoleChange=\"false\" allowDelegate=\"false\" allowAdhoc=\"false\" roleToChange=\"all\" form=\"\" mpsm=\"1\">\n <taskto type=\"RefertoNode\" whom=\"id_1\"/>\n <mpcdc/>\n <oec/>\n <next targetID=\"id_6\"/>\n </node>"
				+ "<node id=\"id_6\" type=\"task\" title=\"Approve Leaving\" name=\"Approve Leaving\" x=\"356\" y=\"203\" acquirable=\"false\" acqThreshold=\"1\" allowRoleChange=\"false\" allowDelegate=\"false\" allowAdhoc=\"false\" roleToChange=\"all\" form=\"\" mpsm=\"1\">\n <taskto type=\"person\" whom=\"U3307\"/>\n <mpcdc/>\n <oec/>\n <next targetID=\"id_end\"/>\n </node>"
				+ "</cf:workflow>";

		String wftid = client.uploadWft(accessKey, wft, "testProcess_2");

		// 从系统中取出这个模板
		String theWft = client.getWftDoc(accessKey, wftid);
		// 其内容应该与前面创建的模板内容一致

		// 新建一个Team
		String teamid = client.createTeam(accessKey, "test_team2", "test_team2_memo");
		// 指派团队成员
		JSONObject members = new JSONObject();
		members.put("U3307", "Approver");
		members.put("U3308", "Auditor");
		client.addTeamMembers(accessKey, teamid, members.toJSONString());

		// 启动进程
		String prcid = client.startWorkflow(accessKey, "U3306", wftid, teamid, "testProcess_2");

		// 取该进程的内容（JSON格式）
		JSONObject prcJson = client.getPrcInfo(accessKey, prcid);
		String thePrcId = (String) prcJson.get("PRCID");

		// 取得worklist, 找到属于该进程的那个work
		JSONArray wlist = client.getWorklist(accessKey);
		JSONObject theWii = client.getWorkitem(wlist, prcid, "id_1");

		// 完成这个work
		client.doTask(accessKey, prcid, (String) theWii.get("NODEID"), (String) theWii.get("SESSID"), null, null);

		// 使用用户U3307登录
		String U3307_accessKey = client.login("U3307", "abcd");
		// 取U3307的Worklist
		JSONArray U3307_wlist = client.getWorklist(U3307_accessKey);
		JSONObject U3307_theWii = client.getWorkitem(U3307_wlist, prcid, "id_2");

		client.doTask(U3307_accessKey, (String) U3307_theWii.get("PRCID"), (String) U3307_theWii.get("NODEID"), (String) U3307_theWii.get("SESSID"), null, null);

		// 使用用户U3308登录
		String U3308_accessKey = client.login("U3308", "abcd");
		// 取U3308的Worklist
		JSONArray U3308_wlist = client.getWorklist(U3308_accessKey);
		JSONObject U3308_theWii = client.getWorkitem(U3308_wlist, prcid, "id_3");
		client.doTask(U3308_accessKey, (String) U3308_theWii.get("PRCID"), (String) U3308_theWii.get("NODEID"), (String) U3308_theWii.get("SESSID"), null, null);

		U3307_wlist = client.getWorklist(U3307_accessKey);
		U3307_theWii = client.getWorkitem(U3307_wlist, prcid, "id_4");
		client.doTask(U3307_accessKey, (String) U3307_theWii.get("PRCID"), (String) U3307_theWii.get("NODEID"), (String) U3307_theWii.get("SESSID"), null, null);

		wlist = client.getWorklist(accessKey);
		theWii = client.getWorkitem(wlist, prcid, "id_5");
		client.doTask(accessKey, (String) theWii.get("PRCID"), (String) theWii.get("NODEID"), (String) theWii.get("SESSID"), null, null);

		U3307_wlist = client.getWorklist(U3307_accessKey);
		U3307_theWii = client.getWorkitem(U3307_wlist, prcid, "id_6");
		client.doTask(U3307_accessKey, (String) U3307_theWii.get("PRCID"), (String) U3307_theWii.get("NODEID"), (String) U3307_theWii.get("SESSID"), null, null);

		// 再次看这个进程的状态，应该是完成状态
		prcJson = client.getPrcInfo(accessKey, prcid);

		// 删除这个新进程
		client.deleteProcess(accessKey, prcid);

		// 删除前面测试创建的Team
		client.deleteTeam(accessKey, teamid);

		// 删除这个模板
		client.deleteWft(accessKey, wftid);

		logger.debug("leavinig demoProcess_2");
	}

	// 测试选择
	public void demoProcess_3() throws Exception {
		logger.debug("entering demoProcess_3");
		accessKey = client.login("U3306", "abcd");

		String org1 = client.createOrg(accessKey, "my org1", "my passwd", "my fed passwd");
		String org2 = client.createOrg(accessKey, "my org2", "my passwd", "my fed passwd");
		client.addUserToOrg(accessKey, org1, "U3306");
		client.addUserToOrg(accessKey, org2, "U3306");
		client.addUserToOrg(accessKey, org1, "U3307");
		client.addUserToOrg(accessKey, org2, "U3308");
		JSONArray memberIds = client.getOrgUserIds(accessKey, org1);
		memberIds = client.getOrgUserIds(accessKey, org2);

		String wft = "<?xml version=\"1.0\" encoding=\"UTF-8\"?><cf:workflow xsi:schemaLocation=\"http://lkh.com/cflow ../schemas/wft.xsd\" name=\"tobedelete\" owner=\"U3306\" acl=\"private\" lastModified=\"2011-03-19T04:18:58\" created=\"2011-03-19T04:18:58\" xmlns:cf=\"http://lkh.com/cflow\" xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\">"
				+ "<node id=\"id_start\" type=\"start\" title=\"Start\" name=\"Start\" x=\"27\" y=\"213\">\n <next targetID=\"id_apply_leaving\"/></node>"
				+ "<node id=\"id_end\" type=\"end\" title=\"End\" name=\"End\" x=\"738\" y=\"213\">\n <next targetID=\"id_end\"/></node>"
				+ "<node id=\"id_apply_leaving\" type=\"task\" title=\"Apply Leaving\" name=\"Apply Leaving\" x=\"356\" y=\"203\" acquirable=\"false\" acqThreshold=\"1\" allowRoleChange=\"false\" allowDelegate=\"false\" allowAdhoc=\"false\" roleToChange=\"all\" form=\"\" mpsm=\"1\">\n <taskto type=\"role\" whom=\"starter\"/>\n <mpcdc/>\n <oec/>\n <next targetID=\"id_approve_leaving\"/>\n </node>"
				+ "<node id=\"id_approve_leaving\" type=\"task\" title=\"Approve Leaving\" name=\"Approve Leaving\" x=\"356\" y=\"203\" acquirable=\"false\" acqThreshold=\"1\" allowRoleChange=\"false\" allowDelegate=\"false\" allowAdhoc=\"false\" roleToChange=\"all\" form=\"\" mpsm=\"1\">\n <taskto type=\"role\" whom=\"Approver\"/>\n <mpcdc/>\n <oec/>\n <next option=\"Approve\" targetID=\"id_approved\"/><next option=\"Reject\" targetID=\"id_rejected\"/>\n </node>"
				+ "<node id=\"id_approved\" type=\"task\" title=\"Approved\" name=\"Approved\" x=\"356\" y=\"203\" acquirable=\"false\" acqThreshold=\"1\" allowRoleChange=\"false\" allowDelegate=\"false\" allowAdhoc=\"false\" roleToChange=\"all\" form=\"\" mpsm=\"1\">\n <taskto type=\"RefertoNode\" whom=\"id_apply_leaving\"/>\n <mpcdc/>\n <oec/>\n <next targetID=\"id_end\"/>\n </node>"
				+ "<node id=\"id_rejected\" type=\"task\" title=\"Rejected\" name=\"Rejected\" x=\"356\" y=\"203\" acquirable=\"false\" acqThreshold=\"1\" allowRoleChange=\"false\" allowDelegate=\"false\" allowAdhoc=\"false\" roleToChange=\"all\" form=\"\" mpsm=\"1\">\n <taskto type=\"RefertoNode\" whom=\"id_apply_leaving\"/>\n <mpcdc/>\n <oec/>\n <next targetID=\"id_end\"/>\n </node>"
				+ "</cf:workflow>";

		String wftid = client.uploadWft(accessKey, wft, "testProcess_3");

		// 从系统中取出这个模板
		String theWft = client.getWftDoc(accessKey, wftid);
		// 其内容应该与前面创建的模板内容一致

		// 新建一个Team
		String teamid = client.createTeam(accessKey, "test_team2", "test_team2_memo");
		// 指派团队成员
		JSONObject members = new JSONObject();
		members.put("U3307", "Approver");
		members.put("U3308", "Auditor");
		client.addTeamMembers(accessKey, teamid, members.toJSONString());

		// 启动进程
		String prcid = client.startWorkflow(accessKey, "U3306", wftid, teamid, "testProcess_3");

		// 取得worklist, 找到属于该进程的那个work
		JSONArray wlist = client.getWorklist(accessKey);
		JSONObject theWii = client.getWorkitem(wlist, prcid, "id_apply_leaving");

		// 完成这个work
		client.doTask(accessKey, prcid, (String) theWii.get("NODEID"), (String) theWii.get("SESSID"), null, null);

		// 使用用户U3307登录
		String U3307_accessKey = client.login("U3307", "abcd");
		// 取U3307的Worklist
		JSONArray U3307_wlist = client.getWorklist(U3307_accessKey);
		JSONObject U3307_theWii = client.getWorkitem(U3307_wlist, prcid, "id_approve_leaving");

		client.doTask(U3307_accessKey, (String) U3307_theWii.get("PRCID"), (String) U3307_theWii.get("NODEID"), (String) U3307_theWii.get("SESSID"), "Approve", null);

		wlist = client.getWorklist(accessKey);
		theWii = client.getWorkitem(wlist, prcid, "id_rejected");
		theWii = client.getWorkitem(wlist, prcid, "id_approved");
		client.doTask(accessKey, (String) theWii.get("PRCID"), (String) theWii.get("NODEID"), (String) theWii.get("SESSID"), null, null);

		// 再次看这个进程的状态，应该是完成状态
		JSONObject prcJson = client.getPrcInfo(accessKey, prcid);

		// 删除这个新进程
		client.deleteProcess(accessKey, prcid);

		// 启动进程
		prcid = client.startWorkflow(accessKey, "U3306", wftid, teamid, "testProcess_3");

		// 取得worklist, 找到属于该进程的那个work
		wlist = client.getWorklist(accessKey);
		theWii = client.getWorkitem(wlist, prcid, "id_apply_leaving");

		// 完成这个work
		client.doTask(accessKey, prcid, (String) theWii.get("NODEID"), (String) theWii.get("SESSID"), null, null);

		// 取U3307的Worklist
		U3307_wlist = client.getWorklist(U3307_accessKey);
		U3307_theWii = client.getWorkitem(U3307_wlist, prcid, "id_approve_leaving");

		client.doTask(U3307_accessKey, (String) U3307_theWii.get("PRCID"), (String) U3307_theWii.get("NODEID"), (String) U3307_theWii.get("SESSID"), "Reject", null);

		wlist = client.getWorklist(accessKey);
		theWii = client.getWorkitem(wlist, prcid, "id_approved");
		theWii = client.getWorkitem(wlist, prcid, "id_rejected");
		client.doTask(accessKey, (String) theWii.get("PRCID"), (String) theWii.get("NODEID"), (String) theWii.get("SESSID"), null, null);

		// 再次看这个进程的状态，应该是完成状态
		prcJson = client.getPrcInfo(accessKey, prcid);

		// 删除这个新进程
		client.deleteProcess(accessKey, prcid);

		// 删除前面测试创建的Team
		client.deleteTeam(accessKey, teamid);

		// 删除这个模板
		client.deleteWft(accessKey, wftid);

		logger.debug("leavinig demoProcess_3");
	}

	// 测试AND_OR
	public void demoProcess_4() throws Exception {
		logger.debug("entering demoProcess_4");
		accessKey = client.login("U3306", "abcd");

		String org1 = client.createOrg(accessKey, "my org1", "my passwd", "my fed passwd");
		String org2 = client.createOrg(accessKey, "my org2", "my passwd", "my fed passwd");
		client.addUserToOrg(accessKey, org1, "U3306");
		client.addUserToOrg(accessKey, org2, "U3306");
		client.addUserToOrg(accessKey, org1, "U3307");
		client.addUserToOrg(accessKey, org2, "U3308");
		JSONArray memberIds = client.getOrgUserIds(accessKey, org1);
		memberIds = client.getOrgUserIds(accessKey, org2);

		String wft = "<?xml version=\"1.0\" encoding=\"UTF-8\"?><cf:workflow xsi:schemaLocation=\"http://lkh.com/cflow ../schemas/wft.xsd\" name=\"tobedelete\" owner=\"U3306\" acl=\"private\" lastModified=\"2011-03-19T04:18:58\" created=\"2011-03-19T04:18:58\" xmlns:cf=\"http://lkh.com/cflow\" xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\">"
				+ "<node id=\"id_start\" type=\"start\" title=\"Start\" name=\"Start\" x=\"27\" y=\"213\">\n <next targetID=\"id_apply_leaving\"/></node>"
				+ "<node id=\"id_end\" type=\"end\" title=\"End\" name=\"End\" x=\"738\" y=\"213\">\n <next targetID=\"id_end\"/></node>"
				+ "<node id=\"id_apply_leaving\" type=\"task\" title=\"Apply Leaving\" name=\"Apply Leaving\"  acquirable=\"false\" acqThreshold=\"1\" allowRoleChange=\"false\" allowDelegate=\"false\" allowAdhoc=\"false\" roleToChange=\"all\" form=\"\" mpsm=\"1\">\n "
				+ "<taskto type=\"role\" whom=\"starter\"/>\n <mpcdc/>\n <oec/>\n <next targetID=\"id_approve_leaving\"/>\n </node>"
				+ "<node id=\"id_approve_leaving\" type=\"task\" title=\"Approve Leaving\" name=\"Approve Leaving\"  acquirable=\"false\" acqThreshold=\"1\" allowRoleChange=\"false\" allowDelegate=\"false\" allowAdhoc=\"false\" roleToChange=\"all\" form=\"\" mpsm=\"1\">\n "
				+ "<taskto type=\"role\" whom=\"Approver\"/>\n <mpcdc/>\n <oec/>\n <next option=\"Approve\" targetID=\"id_approved\"/><next option=\"Approve\" targetID=\"id_approved2\"/><next option=\"Reject\" targetID=\"id_rejected\"/><next option=\"Reject\" targetID=\"id_rejected2\"/>\n </node>"
				+ "<node id=\"id_approved\" type=\"task\" title=\"Approved\" name=\"Approved\"  acquirable=\"false\" acqThreshold=\"1\" allowRoleChange=\"false\" allowDelegate=\"false\" allowAdhoc=\"false\" roleToChange=\"all\" form=\"\" mpsm=\"1\">\n "
				+ "<taskto type=\"RefertoNode\" whom=\"id_apply_leaving\"/>\n <mpcdc/>\n <oec/>\n <next targetID=\"id_AND\"/>\n </node>"
				+ "<node id=\"id_approved2\" type=\"task\" title=\"Approved2\" name=\"Approved2\"  acquirable=\"false\" acqThreshold=\"1\" allowRoleChange=\"false\" allowDelegate=\"false\" allowAdhoc=\"false\" roleToChange=\"all\" form=\"\" mpsm=\"1\">\n "
				+ "<taskto type=\"RefertoNode\" whom=\"id_approve_leaving\"/>\n <mpcdc/>\n <oec/>\n <next targetID=\"id_AND\"/>\n </node>"
				+ "<node id=\"id_AND\" type=\"and\" ><next targetID=\"id_end\"/></node>\n "
				+ "<node id=\"id_rejected\" type=\"task\" title=\"Rejected\" name=\"Rejected\"  acquirable=\"false\" acqThreshold=\"1\" allowRoleChange=\"false\" allowDelegate=\"false\" allowAdhoc=\"false\" roleToChange=\"all\" form=\"\" mpsm=\"1\">\n "
				+ "<taskto type=\"RefertoNode\" whom=\"id_apply_leaving\"/>\n <mpcdc/>\n <oec/>\n <next targetID=\"id_OR\"/>\n </node>"
				+ "<node id=\"id_rejected2\" type=\"task\" title=\"Rejected2\" name=\"Rejected2\"  acquirable=\"false\" acqThreshold=\"1\" allowRoleChange=\"false\" allowDelegate=\"false\" allowAdhoc=\"false\" roleToChange=\"all\" form=\"\" mpsm=\"1\">\n "
				+ "<taskto type=\"RefertoNode\" whom=\"id_approve_leaving\"/>\n <mpcdc/>\n <oec/>\n <next targetID=\"id_OR\"/>\n </node>" + "<node id=\"id_OR\" type=\"or\" ><next targetID=\"id_end\"/></node>\n " + "</cf:workflow>";

		String wftid = client.uploadWft(accessKey, wft, "testProcess_4");

		// 新建一个Team
		String teamid = client.createTeam(accessKey, "test_team2", "test_team2_memo");
		// 指派团队成员
		JSONObject members = new JSONObject();
		members.put("U3307", "Approver");
		members.put("U3308", "Auditor");
		client.addTeamMembers(accessKey, teamid, members.toJSONString());

		// 启动进程
		String prcid = client.startWorkflow(accessKey, "U3306", wftid, teamid, "testProcess_4");

		// id_apply_leaving
		JSONArray wlist = client.getWorklist(accessKey);
		JSONObject theWii = client.getWorkitem(wlist, prcid, "id_apply_leaving");
		client.doTask(accessKey, prcid, (String) theWii.get("NODEID"), (String) theWii.get("SESSID"), null, null);

		// 使用用户U3307登录
		String U3307_accessKey = client.login("U3307", "abcd");
		// 取U3307的Worklist
		JSONArray U3307_wlist = client.getWorklist(U3307_accessKey);
		JSONObject U3307_theWii = client.getWorkitem(U3307_wlist, prcid, "id_approve_leaving");

		client.doTask(U3307_accessKey, (String) U3307_theWii.get("PRCID"), (String) U3307_theWii.get("NODEID"), (String) U3307_theWii.get("SESSID"), "Approve", null);

		wlist = client.getWorklist(accessKey);
		U3307_wlist = client.getWorklist(U3307_accessKey);
		theWii = client.getWorkitem(wlist, prcid, "id_approved");
		U3307_theWii = client.getWorkitem(U3307_wlist, prcid, "id_approved2");
		client.doTask(accessKey, (String) theWii.get("PRCID"), (String) theWii.get("NODEID"), (String) theWii.get("SESSID"), null, null);
		JSONObject prcJson = client.getPrcInfo(accessKey, prcid);
		client.doTask(U3307_accessKey, (String) U3307_theWii.get("PRCID"), (String) U3307_theWii.get("NODEID"), (String) U3307_theWii.get("SESSID"), null, null);

		// 再次看这个进程的状态，应该是完成状态
		prcJson = client.getPrcInfo(accessKey, prcid);

		// 删除这个新进程
		client.deleteProcess(accessKey, prcid);

		// 启动进程
		prcid = client.startWorkflow(accessKey, "U3306", wftid, teamid, "testProcess_4");

		// 取得worklist, 找到属于该进程的那个work
		wlist = client.getWorklist(accessKey);
		theWii = client.getWorkitem(wlist, prcid, "id_apply_leaving");

		// 完成这个work
		client.doTask(accessKey, prcid, (String) theWii.get("NODEID"), (String) theWii.get("SESSID"), null, null);

		// 取U3307的Worklist
		U3307_wlist = client.getWorklist(U3307_accessKey);
		U3307_theWii = client.getWorkitem(U3307_wlist, prcid, "id_approve_leaving");

		client.doTask(U3307_accessKey, (String) U3307_theWii.get("PRCID"), (String) U3307_theWii.get("NODEID"), (String) U3307_theWii.get("SESSID"), "Reject", null);

		wlist = client.getWorklist(accessKey);
		U3307_wlist = client.getWorklist(U3307_accessKey);
		theWii = client.getWorkitem(wlist, prcid, "id_rejected");
		U3307_theWii = client.getWorkitem(U3307_wlist, prcid, "id_rejected2");
		client.doTask(accessKey, (String) theWii.get("PRCID"), (String) theWii.get("NODEID"), (String) theWii.get("SESSID"), null, null);

		// 再次看这个进程的状态，应该是完成状态
		prcJson = client.getPrcInfo(accessKey, prcid);

		// 删除这个新进程
		client.deleteProcess(accessKey, prcid);

		// 删除前面测试创建的Team
		client.deleteTeam(accessKey, teamid);

		// 删除这个模板
		client.deleteWft(accessKey, wftid);

		logger.debug("leavinig demoProcess_4");
	}

	// 测试 Option, AND_OR, Variables, Script执行，以及script回写参数值
	// script回写的例子是com.lkh.cflow.test.MyLiner, 通过 java类型的script来调用
	public void demoProcess_5() throws Exception {
		logger.debug("entering demoProcess_5");
		accessKey = client.login("U3306", "abcd");

		String org1 = client.createOrg(accessKey, "my org1", "my passwd", "my fed passwd");
		String org2 = client.createOrg(accessKey, "my org2", "my passwd", "my fed passwd");
		client.addUserToOrg(accessKey, org1, "U3306");
		client.addUserToOrg(accessKey, org2, "U3306");
		client.addUserToOrg(accessKey, org1, "U3307");
		client.addUserToOrg(accessKey, org2, "U3308");
		JSONArray memberIds = client.getOrgUserIds(accessKey, org1);
		memberIds = client.getOrgUserIds(accessKey, org2);

		String wft_script_java = "<?xml version=\"1.0\" encoding=\"UTF-8\"?><cf:workflow xsi:schemaLocation=\"http://lkh.com/cflow ../schemas/wft.xsd\" name=\"tobedelete\" owner=\"U3306\" acl=\"private\" lastModified=\"2011-03-19T04:18:58\" created=\"2011-03-19T04:18:58\" xmlns:cf=\"http://lkh.com/cflow\" xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\">"
				+ "<node id=\"id_start\" type=\"start\" title=\"Start\" name=\"Start\" x=\"27\" y=\"213\">\n <next targetID=\"id_apply_leaving\"/></node>"
				+ "<node id=\"id_end\" type=\"end\" title=\"End\" name=\"End\" x=\"738\" y=\"213\">\n <next targetID=\"id_end\"/></node>"

				+ "<node id=\"id_apply_leaving\" type=\"task\" title=\"Apply Leaving\" name=\"Apply Leaving\"  acquirable=\"false\" acqThreshold=\"1\" allowRoleChange=\"false\" allowDelegate=\"false\" allowAdhoc=\"false\" roleToChange=\"all\" form=\"\" mpsm=\"1\">\n "
				+ "<attachment type=\"int\" label=\"Leave days\" attname=\"days\" value=\"\"/>"
				+ "<taskto type=\"role\" whom=\"starter\"/>\n <mpcdc/>\n <oec/>\n "
				+ "<next targetID=\"id_reason\"/></node>"

				+ "<node id=\"id_reason\" type=\"task\" title=\"Give Reason\" name=\"Give Reason\">"
				+ "<attachment type=\"String\" label=\"Leave reason\" attname=\"reason\" value=\"\"/>"
				+ "<taskto type=\"role\" whom=\"starter\"/>\n <mpcdc/>\n <oec/>\n "
				+ "<next targetID=\"id_script\"/>\n "
				+ "</node>"

				+ "<node id='id_script' type='script'><script>JAVA:com.lkh.cflow.test.MyLinker</script>" + "<next option='long' targetID='id_long'/>" + "<next option='short' targetID='id_short'/>" + "</node>"

				+ "<node id='id_long' type='task' name='LONG'>" + "<taskto type=\"RefertoNode\" whom=\"id_apply_leaving\"/>" + "<next targetID='id_end'/>" + "</node>"

				+ "<node id='id_short' type='task' name='SHORT'>" + "<taskto type=\"RefertoNode\" whom=\"id_apply_leaving\"/>" + "<next targetID='id_end'/>" + "</node>"

				+ "</cf:workflow>";

		String wft_script_web = "<?xml version=\"1.0\" encoding=\"UTF-8\"?><cf:workflow xsi:schemaLocation=\"http://lkh.com/cflow ../schemas/wft.xsd\" name=\"tobedelete\" owner=\"U3306\" acl=\"private\" lastModified=\"2011-03-19T04:18:58\" created=\"2011-03-19T04:18:58\" xmlns:cf=\"http://lkh.com/cflow\" xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\">"
				+ "<node id=\"id_start\" type=\"start\" title=\"Start\" name=\"Start\" x=\"27\" y=\"213\">\n <next targetID=\"id_apply_leaving\"/></node>"
				+ "<node id=\"id_end\" type=\"end\" title=\"End\" name=\"End\" x=\"738\" y=\"213\">\n <next targetID=\"id_end\"/></node>"

				+ "<node id=\"id_apply_leaving\" type=\"task\" title=\"Apply Leaving\" name=\"Apply Leaving\"  acquirable=\"false\" acqThreshold=\"1\" allowRoleChange=\"false\" allowDelegate=\"false\" allowAdhoc=\"false\" roleToChange=\"all\" form=\"\" mpsm=\"1\">\n "
				+ "<attachment type=\"int\" label=\"Leave days\" attname=\"days\" value=\"\"/>"
				+ "<attachment type=\"String\" label=\"Leave Reason\" attname=\"reason\" value=\"\"/>"
				+ "<taskto type=\"role\" whom=\"starter\"/>\n <mpcdc/>\n <oec/>\n "
				+ "<next targetID=\"id_script\"/>\n "
				+ "</node>"

				+ "<node id='id_script' type='script'><script>URL:http://" + hostname + "/cflow/TestScriptWeb</script>" + "<next option='long' targetID='id_long'/>" + "<next option='short' targetID='id_short'/>" + "</node>"

				+ "<node id='id_long' type='task' name='LONG'>" + "<taskto type=\"RefertoNode\" whom=\"id_apply_leaving\"/>" + "<next targetID='id_end'/>" + "</node>"

				+ "<node id='id_short' type='task' name='SHORT'>" + "<taskto type=\"RefertoNode\" whom=\"id_apply_leaving\"/>" + "<next targetID='id_end'/>" + "</node>"

				+ "</cf:workflow>";
		String wft_script_javascirpt = "<?xml version=\"1.0\" encoding=\"UTF-8\"?><cf:workflow xsi:schemaLocation=\"http://lkh.com/cflow ../schemas/wft.xsd\" name=\"tobedelete\" owner=\"U3306\" acl=\"private\" lastModified=\"2011-03-19T04:18:58\" created=\"2011-03-19T04:18:58\" xmlns:cf=\"http://lkh.com/cflow\" xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\">"
				+ "<node id=\"id_start\" type=\"start\" title=\"Start\" name=\"Start\" x=\"27\" y=\"213\">\n <next targetID=\"id_apply_leaving\"/></node>"
				+ "<node id=\"id_end\" type=\"end\" title=\"End\" name=\"End\" x=\"738\" y=\"213\">\n <next targetID=\"id_end\"/></node>"

				+ "<node id=\"id_apply_leaving\" type=\"task\" title=\"Apply Leaving\" name=\"Apply Leaving\"  acquirable=\"false\" acqThreshold=\"1\" allowRoleChange=\"false\" allowDelegate=\"false\" allowAdhoc=\"false\" roleToChange=\"all\" form=\"\" mpsm=\"1\">\n "
				+ "<attachment type=\"int\" label=\"Leave days\" attname=\"days\" value=\"\"/>" + "<taskto type=\"role\" whom=\"starter\"/>\n <mpcdc/>\n <oec/>\n " + "<next targetID=\"id_script\"/>\n " + "</node>"

				+ "<node id='id_script' type='script'><script>return 'long';</script>" + "<next option='long' targetID='id_long'/>" + "<next option='short' targetID='id_short'/>" + "</node>"

				+ "<node id='id_long' type='task' name='LONG'>" + "<taskto type=\"RefertoNode\" whom=\"id_apply_leaving\"/>" + "<next targetID='id_end'/>" + "</node>"

				+ "<node id='id_short' type='task' name='SHORT'>" + "<taskto type=\"RefertoNode\" whom=\"id_apply_leaving\"/>" + "<next targetID='id_end'/>" + "</node>"

				+ "</cf:workflow>";

		String wftid_script_java = client.uploadWft(accessKey, wft_script_java, "testProcess_5");
		String wftid_script_web = client.uploadWft(accessKey, wft_script_web, "testProcess_5");

		// 新建一个Team
		String teamid = client.createTeam(accessKey, "test_team2", "test_team2_memo");
		// 指派团队成员
		JSONObject members = new JSONObject();
		members.put("U3307", "Approver");
		members.put("U3308", "Auditor");
		client.addTeamMembers(accessKey, teamid, members.toJSONString());

		// 启动进程
		String prcid = client.startWorkflow(accessKey, "U3306", wftid_script_java, teamid, "testProcess_5");

		// id_apply_leaving
		JSONArray wlist = client.getWorklist(accessKey);
		JSONObject theWii = client.getWorkitem(wlist, prcid, "id_apply_leaving");
		client.doTask(accessKey, prcid, (String) theWii.get("NODEID"), (String) theWii.get("SESSID"), null, "{\"days\":\"11\", \"reason\":\"gohome\", \"var3\":\"value3\"}");
		wlist = client.getWorklist(accessKey);
		theWii = client.getWorkitem(wlist, prcid, "id_reason");
		client.doTask(accessKey, prcid, (String) theWii.get("NODEID"), (String) theWii.get("SESSID"), null, "{ \"reason\":\"gohome2\"}");

		wlist = client.getWorklist(accessKey);
		theWii = client.getWorkitem(wlist, prcid, "id_long");
		client.doTask(accessKey, (String) theWii.get("PRCID"), (String) theWii.get("NODEID"), (String) theWii.get("SESSID"), null, null);

		// 再次看这个进程的状态，应该是完成状态
		JSONObject prcJson = client.getPrcInfo(accessKey, prcid);

		// 删除这个新进程
		client.deleteProcess(accessKey, prcid);

		// 启动进程
		prcid = client.startWorkflow(accessKey, "U3306", wftid_script_java, teamid, "testProcess_5");

		// id_apply_leaving
		wlist = client.getWorklist(accessKey);
		theWii = client.getWorkitem(wlist, prcid, "id_apply_leaving");
		client.doTask(accessKey, prcid, (String) theWii.get("NODEID"), (String) theWii.get("SESSID"), null, "{\"days\":\"11\", \"reason\":\"gohome\"}");
		wlist = client.getWorklist(accessKey);
		theWii = client.getWorkitem(wlist, prcid, "id_reason");

		JSONObject beforeScript = client.getPrcVariables(accessKey, prcid);
		// 下面一个task完成后，将自动调用script活动
		client.doTask(accessKey, prcid, (String) theWii.get("NODEID"), (String) theWii.get("SESSID"), null, "{\"days\":\"9\", \"reason\":\"gohome2\"}");
		// Here, the script node will be executed. com.lkh.cflow.test.MyLinker.
		// will write "test value to change back to process attachment" back to
		// “reason”
		JSONObject afterScript = client.getPrcVariables(accessKey, prcid);

		wlist = client.getWorklist(accessKey);
		theWii = client.getWorkitem(wlist, prcid, "id_short");
		client.doTask(accessKey, (String) theWii.get("PRCID"), (String) theWii.get("NODEID"), (String) theWii.get("SESSID"), null, null);

		// 再次看这个进程的状态，应该是完成状态
		prcJson = client.getPrcInfo(accessKey, prcid);

		// 删除这个新进程
		client.deleteProcess(accessKey, prcid);

		// 启动进程
		prcid = client.startWorkflow(accessKey, "U3306", wftid_script_web, teamid, "testProcess_5");

		// id_apply_leaving
		wlist = client.getWorklist(accessKey);
		theWii = client.getWorkitem(wlist, prcid, "id_apply_leaving");
		client.doTask(accessKey, prcid, (String) theWii.get("NODEID"), (String) theWii.get("SESSID"), null, "{\"days\":\"11\", \"reason\":\"gohome\"}");

		wlist = client.getWorklist(accessKey);
		theWii = client.getWorkitem(wlist, prcid, "id_long");
		client.doTask(accessKey, (String) theWii.get("PRCID"), (String) theWii.get("NODEID"), (String) theWii.get("SESSID"), null, null);

		// 再次看这个进程的状态，应该是完成状态
		prcJson = client.getPrcInfo(accessKey, prcid);

		// 删除这个新进程
		client.deleteProcess(accessKey, prcid);

		// 启动进程
		prcid = client.startWorkflow(accessKey, "U3306", wftid_script_web, teamid, "testProcess_5");

		// id_apply_leaving
		wlist = client.getWorklist(accessKey);
		theWii = client.getWorkitem(wlist, prcid, "id_apply_leaving");
		client.doTask(accessKey, prcid, (String) theWii.get("NODEID"), (String) theWii.get("SESSID"), null, "{\"days\":\"6\", \"reason\":\"gohome\"}");

		wlist = client.getWorklist(accessKey);
		theWii = client.getWorkitem(wlist, prcid, "id_short");
		client.doTask(accessKey, (String) theWii.get("PRCID"), (String) theWii.get("NODEID"), (String) theWii.get("SESSID"), null, null);

		// 再次看这个进程的状态，应该是完成状态
		prcJson = client.getPrcInfo(accessKey, prcid);

		// 删除这个新进程
		client.deleteProcess(accessKey, prcid);

		// 删除前面测试创建的Team
		client.deleteTeam(accessKey, teamid);

		// 删除这个模板
		client.deleteWft(accessKey, wftid_script_java);
		client.deleteWft(accessKey, wftid_script_web);

		logger.debug("leavinig demoProcess_5");
	}
}
