package com.lkh.mwfclient.test;

import java.util.concurrent.Callable;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
import java.util.concurrent.TimeUnit;

import org.json.simple.JSONArray;
import org.json.simple.JSONObject;

import com.lkh.mwfclient.AWEClient;

public class Burnit {
	AWEClient awe = AWEClient.newClient("localhost:8080");

	/**
	 * @param args
	 * @throws InterruptedException
	 */
	public static void main(String[] args) throws InterruptedException {
		Burnit burnit = new Burnit();
		ExecutorService executor = Executors.newCachedThreadPool();
		try {
			for (int i = 0; i < 100; i++) {
				System.out.println(Thread.currentThread().getId() + "\tround:"
						+ i);
				Task aTask = burnit.new Task();
				Future<String> future = executor.submit(aTask);
				Object obj = future.get(60, TimeUnit.SECONDS);
			}
		} catch (Exception ex) {
			ex.printStackTrace();
		} finally {
			executor.shutdownNow();
		}

	}

	public class Task implements Callable<String> {
		@Override
		public String call() throws Exception {
			Burnit burnit = new Burnit();
			try {
				burnit.burnDemo_TIMEOUT();
			} catch (Exception ex) {
				ex.printStackTrace();
			}
			try {
				burnit.burnDemo_WEB();
			} catch (Exception ex) {
				ex.printStackTrace();
			}
			try {
				burnit.burnLeaveApplication();
			} catch (Exception ex) {
				ex.printStackTrace();
			}
			try {
				burnit.burnVoucherAdmin();
			} catch (Exception ex) {
				ex.printStackTrace();
			}
			try {
				burnit.burnSJYJ();
			} catch (Exception ex) {
				ex.printStackTrace();
			}

			return "";
		}
	}

	private void burnDemo_WEB() throws Exception {
		System.out.println(Thread.currentThread().getId() + "\tburnDemo_WEB");
		String wftName = "Demo_WEB";
		String teamName = null;
		String instanceName = "v1";
		JSONObject ctx = null;
		String actor = null;

		String token = awe.getToken("ACCESS_ID", "ACCESS_KEY");
		actor = "peixin.baipx";
		String prcid = awe.startWorkflowByName(token, actor, wftName, teamName,
				instanceName, ctx);
		try {
			JSONObject input = new JSONObject();
			input.put("days", 20);
			input.put("reason", "go home");
			JSONArray wlist = awe.getWorklist(token, actor);
			JSONObject wii = getWii(wlist, prcid, actor);
			doTask(token, actor, prcid, (String) wii.get("NODEID"),
					(String) wii.get("SESSID"), "", input.toString());

			actor = "peixin.baipx";
			wlist = awe.getWorklist(token, actor);
			wii = getWii(wlist, prcid, actor);
			// System.out.println("20>10 should go to Long Leave, get " +
			// wii.get("NAME"));
			doTask(token, actor, prcid, (String) wii.get("NODEID"),
					(String) wii.get("SESSID"), "", null);

			JSONObject prcInfo = awe.getPrcInfo(token, prcid);
			// System.out.println("Process status: " + prcInfo.get("STATUS"));
		} finally {
			awe.deleteProcess(token, prcid);
		}

	}

	private void burnDemo_TIMEOUT() throws Exception {
		String wftName = "Demo_WEB_TIMEOUT";
		String teamName = null;
		String instanceName = "v1";
		JSONObject ctx = null;
		String actor = null;

		System.out.println(Thread.currentThread().getId()
				+ "\tburnDemo_TIMEOUT");

		String token = awe.getToken("ACCESS_ID", "ACCESS_KEY");
		// loadTestUsers(token);
		actor = "peixin.baipx";
		String prcid = awe.startWorkflowByName(token, actor, wftName, teamName,
				instanceName, ctx);
		try {
			JSONObject input = new JSONObject();
			input.put("days", 20);
			input.put("reason", "go home");
			JSONArray wlist = awe.getWorklist(token, actor);
			JSONObject wii = getWii(wlist, prcid, actor);
			doTask(token, actor, prcid, (String) wii.get("NODEID"),
					(String) wii.get("SESSID"), "", input.toString());

			actor = "peixin.baipx";
			wlist = awe.getWorklist(token, actor);
			wii = getWii(wlist, prcid, actor);
			// System.out.println("Should go to Error, get " + wii.get("NAME"));
			doTask(token, actor, prcid, (String) wii.get("NODEID"),
					(String) wii.get("SESSID"), "", null);

			JSONObject prcInfo = awe.getPrcInfo(token, prcid);
			// System.out.println("Process status: " + prcInfo.get("STATUS"));
		} finally {
			awe.deleteProcess(token, prcid);
		}

	}

	private void burnSJYJ() throws Exception {
		String wftName = "数据英佳";
		String teamName = null;
		String instanceName = "v1";
		JSONObject ctx = null;
		String actor = null;

		System.out.println(Thread.currentThread().getId() + "\tburnSJYJ");
		String token = awe.getToken("ACCESS_ID", "ACCESS_KEY");
		// loadTestUsers(token);
		actor = "peixin.baipx";
		String prcid = awe.startWorkflowByName(token, actor, wftName, teamName,
				instanceName, ctx);
		try {
			JSONObject input = new JSONObject();
			input.put("month", 2);
			JSONArray wlist = awe.getWorklist(token, actor);
			JSONObject wii = getWii(wlist, prcid, actor);
			doTask(token, actor, prcid, (String) wii.get("NODEID"),
					(String) wii.get("SESSID"), "", input.toString());

			actor = "peixin.baipx";
			wlist = awe.getWorklist(token, actor);
			wii = getWii(wlist, prcid, actor);
			input = new JSONObject();
			input.put("methodG1", "代金券");
			input.put("methodG2", "优惠价");
			doTask(token, actor, prcid, (String) wii.get("NODEID"),
					(String) wii.get("SESSID"), "", input.toString());

			actor = "peixin.baipx";
			wlist = awe.getWorklist(token, actor);
			wii = getWii(wlist, prcid, actor);
			doTask(token, actor, prcid, (String) wii.get("NODEID"),
					(String) wii.get("SESSID"), "", null);

			JSONObject prcInfo = awe.getPrcInfo(token, prcid);
			// System.out.println("Process status: " + prcInfo.get("STATUS"));
		} finally {
			awe.deleteProcess(token, prcid);
		}
	}

	private void burnLeaveApplication() throws Exception {
		String wftName = "Leave Application";
		String teamName = "LeaveApprovalTeam";
		String instanceName = "v1";
		JSONObject ctx = null;
		String actor = null;

		System.out.println(Thread.currentThread().getId()
				+ "\tburnLeaveApplication");
		String token = awe.getToken("ACCESS_ID", "ACCESS_KEY");
		// loadTestUsers(token);
		actor = "peixin.baipx";
		String prcid = awe.startWorkflowByName(token, actor, wftName, teamName,
				instanceName, ctx);
		try {
			JSONObject input = new JSONObject();
			input.put("days", 11);
			input.put("reason", "go home");
			JSONArray wlist = awe.getWorklist(token, actor);
			JSONObject wii = getWii(wlist, prcid, actor);
			doTask(token, actor, prcid, (String) wii.get("NODEID"),
					(String) wii.get("SESSID"), "", input.toString());

			actor = "allen";
			wlist = awe.getWorklist(token, actor);
			wii = getWii(wlist, prcid, actor);
			input = new JSONObject();
			input.put("approveComment", actor + "-Okay");
			doTask(token, actor, prcid, (String) wii.get("NODEID"),
					(String) wii.get("SESSID"), "1.Approve it.",
					input.toString());

			actor = "peixin.baipx";
			wlist = awe.getWorklist(token, actor);
			wii = getWii(wlist, prcid, actor);
			doTask(token, actor, prcid, (String) wii.get("NODEID"),
					(String) wii.get("SESSID"), "", null);

			JSONObject prcInfo = awe.getPrcInfo(token, prcid);
			// System.out.println("Process status: " + prcInfo.get("STATUS"));
		} finally {
			awe.deleteProcess(token, prcid);
		}
	}

	/**
	 * @throws Exception
	 */
	private void burnVoucherAdmin() throws Exception {
		String wftName = "Voucher Application";
		String teamName = "VoucherAdmin1";
		String instanceName = "v1";
		JSONObject ctx = null;
		String actor = null;
		System.out.println(Thread.currentThread().getId()
				+ "\tburnVoucherAdmin");
		String token = awe.getToken("ACCESS_ID", "ACCESS_KEY");
		// loadTestUsers(token);
		actor = "peixin.baipx";
		String prcid = awe.startWorkflowByName(token, actor, wftName, teamName,
				instanceName, ctx);
		try {
			JSONObject input = new JSONObject();
			input.put("projectName", "myProject");
			input.put("purpose", "Promotion");
			input.put("number", 100);
			input.put("due", "2012-12-31");
			input.put("eventpurpose", "sell 1000");
			input.put("eventrule", "rule");
			input.put("atturl", "http://www");
			input.put("memo", "thanks");
			input.put("eventdate", "2012-11-15");
			input.put("figure", 100);
			input.put("service", "VM");
			JSONArray wlist = awe.getWorklist(token, actor);
			JSONObject wii = getWii(wlist, prcid, actor);
			doTask(token, actor, prcid, (String) wii.get("NODEID"),
					(String) wii.get("SESSID"), "", input.toString());

			actor = "allen";
			wlist = awe.getWorklist(token, actor);
			wii = getWii(wlist, prcid, actor);
			input = new JSONObject();
			input.put("1stapproveComment", actor + "-Okay");
			doTask(token, actor, prcid, (String) wii.get("NODEID"),
					(String) wii.get("SESSID"), "Approve", input.toString());

			actor = "huali.shihl";
			wlist = awe.getWorklist(token, actor);
			wii = getWii(wlist, prcid, actor);
			input = new JSONObject();
			input.put("voucherNumber", actor + "-100-1000");
			doTask(token, actor, prcid, (String) wii.get("NODEID"),
					(String) wii.get("SESSID"), "", input.toString());

			actor = "peixin.baipx";
			wlist = awe.getWorklist(token, actor);
			wii = getWii(wlist, prcid, actor);
			doTask(token, actor, prcid, (String) wii.get("NODEID"),
					(String) wii.get("SESSID"), "", null);

			JSONObject prcInfo = awe.getPrcInfo(token, prcid);
			// System.out.println("Process status: " + prcInfo.get("STATUS"));
		} finally {
			awe.deleteProcess(token, prcid);
		}
	}

	private void doTask(String token, String actor, String prcId,
			String nodeId, String sessId, String option, String input)
			throws Exception {
		awe.doTask(token, actor, prcId, nodeId, sessId, option, input);
		// System.out.println(actor + " do task with option[" + option +
		// "] input[" + input + "]");
	}

	private JSONObject getWii(JSONArray wlist, String prcid, String actor) {
		JSONObject wii = null;
		for (int i = 0; i < wlist.size(); i++) {
			JSONObject tmp = (JSONObject) wlist.get(i);
			if (tmp.get("PRCID").equals(prcid) && tmp.get("DOER").equals(actor)) {
				wii = tmp;
				break;
			}
		}
		return wii;
	}

	private void loadTestUsers(String token) throws Exception {
		awe.addUser(token, "USER_IDENTITY", "USER_NAME",
				"USER_EMAIL", "GMT+08:00", "zh-CN", "E");
		/*
		 *
		 *
		 */
	}
}
