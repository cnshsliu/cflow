package com.lkh.mwfclient.test;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;

import junit.framework.TestCase;

import org.apache.commons.httpclient.DefaultHttpMethodRetryHandler;
import org.apache.commons.httpclient.HttpClient;
import org.apache.commons.httpclient.MultiThreadedHttpConnectionManager;
import org.apache.commons.httpclient.methods.GetMethod;
import org.apache.commons.httpclient.params.HttpMethodParams;
import org.apache.http.HttpStatus;
import org.apache.log4j.ConsoleAppender;
import org.apache.log4j.Logger;
import org.apache.log4j.SimpleLayout;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.junit.After;
import org.junit.Before;

import com.lkh.mwfclient.AWEClient;
import com.lkh.mwfclient.MwfException;

public class UT1 extends TestCase {
	private static String hostname = "MWF_SERVER_IP:8080";
	private static Logger logger = Logger.getLogger(UT1.class);
	private static AWEClient client = AWEClient.newClient(hostname);

	@Before
	public void setUp() throws Exception {
		SimpleLayout layout = new SimpleLayout();
		ConsoleAppender appender = new ConsoleAppender(layout);
		logger.addAppender(appender);

		// String userJSON = getUserInfo(token).toString();
	}

	@After
	public void tearDown() throws Exception {
	}

	public void test_user() throws Exception {

		// 登录两个开发者；
		String token = client.getToken("tester1", "test");
		assertAcsk(token);
		String token2 = client.getToken("tester2", "test");
		assertAcsk(token2);

		JSONArray users = client.getAllUsers(token);
		int count = users.size();
		// 分别载入用户；

		loadTestUsers(token);
		loadTestUsers(token2);
		users = client.getAllUsers(token);
		assertTrue(users.size() >= count);
		// tester修改一个用户，取用户信息检查是否成功修改
		client.updateUser(token, "T001", "T001_newName",
				"T001_newemail@null.com", "GMT+08:00", "zh_CN", "E");
		JSONObject tmp = client.getUserInfo(token, "T001");
		assertEquals("T001_newName", tmp.get("NAME"));
		client.updateUser(token, "T001", "T001", "T001_newemail@null.com",
				"GMT+08:00", "zh_CN", "E");
		tmp = client.getUserInfo(token, "T001");
		assertEquals("T001", tmp.get("NAME"));
		// liukehong没有修改过，
		tmp = client.getUserInfo(token2, "T001");
		assertEquals("T001", tmp.get("NAME"));
		// liukehong删除所有测试用户

	}



	public void test_wft() throws Exception {
		String token = client.getToken("tester1", "test");
		assertAcsk(token);

		String wft = "<?xml version=\"1.0\" encoding=\"UTF-8\"?><cf:workflow xsi:schemaLocation=\"http://lkh.com/cflow ../schemas/wft.xsd\" name=\"tobedelete\" owner=\"LKH\" acl=\"private\" lastModified=\"2011-03-19T04:18:58\" created=\"2011-03-19T04:18:58\" xmlns:cf=\"http://lkh.com/cflow\" xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\">"
				+ "<node id=\"58DE1222-4446-C2DE-1F8B-CA9EBE43C965\" type=\"start\" title=\"Start\" name=\"Start\" x=\"27\" y=\"213\">\n <next targetID=\"5094DF39-F83A-BE01-3FE0-CA9EC768D9B7\"/></node>"
				+ "<node id=\"7E40C95C-333D-964E-2EA3-CA9EBE457AE1\" type=\"end\" title=\"End\" name=\"End\" x=\"738\" y=\"213\">\n <next targetID=\"7E40C95C-333D-964E-2EA3-CA9EBE457AE1\"/></node>"
				+ "<node id=\"5094DF39-F83A-BE01-3FE0-CA9EC768D9B7\" type=\"task\" title=\"Task\" name=\"Task\" x=\"356\" y=\"203\" acquirable=\"false\" acqThreshold=\"1\" allowRoleChange=\"false\" allowDelegate=\"false\" allowAdhoc=\"false\" roleToChange=\"all\" form=\"\" mpsm=\"1\">\n <taskto type=\"role\" whom=\"starter\"/>\n <mpcdc/>\n <oec/>\n <next targetID=\"7E40C95C-333D-964E-2EA3-CA9EBE457AE1\"/>\n </node>"
				+ "</cf:workflow>";
		String wftname = "rstest1";

		String wftid = client.uploadWft(token, wft, wftname);
		logger.info(wftid);
		assertFalse(wftid.startsWith("ERROR"));

		String theWft = client.getWftDoc(token, wftid);
		assertEquals(theWft, wft);

		JSONArray wfts = client.getWfts(token);
		assertTrue(wfts.size() > 0);

		// 依次删除新建的这些模板
		for (int i = 0; i < wfts.size(); i++) {
			JSONObject aWft = (JSONObject) wfts.get(i);
			if (aWft.get("WFTNAME").equals(wftname)) {
				String tmp = (String) aWft.get("WFTID");
				assertFalse(client.deleteWft(token, tmp).startsWith("ERROR"));
			}
		}
		wfts = client.getWfts(token);
		// 此时，未必>0, 所以用>=0
		assertTrue(wfts.size() >= 0);
		// 依次检查每个模板，并统计所以名字为测试名字的模板个数
		int numberOfTestWft = 0;
		for (int i = 0; i < wfts.size(); i++) {
			JSONObject aWft = (JSONObject) wfts.get(i);
			if (aWft.get("WFTNAME").equals(wftname)) {
				numberOfTestWft++;
			}
		}
		// 这个数字应该全部为零。
		assertTrue(numberOfTestWft == 0);

		// 测试取Example模板
		int numberOfWft = client.getWfts(token).size();
		String newWftId = client.getWftExample(token, "Demo_AND");
		assertFalse(newWftId == null);
		JSONObject aWft = client.getWftInfo(token, newWftId);
		assertEquals(newWftId, aWft.get("WFTID"));
		assertTrue(client.getWfts(token).size() == numberOfWft + 1);
		client.deleteWft(token, newWftId);
		assertTrue(client.getWfts(token).size() == numberOfWft);

	}

	public void test_admin_teams() throws Exception {
		String token = client.getToken("tester1", "test");
		assertAcsk(token);

		// 取得已有的Teams

		int oldTeamCount = client.getTeams(token).size();
		String teamid = client.createTeam(token, "test_team1",
				"test_team1_memo");
		assertTrue(client.getTeams(token).size() >= oldTeamCount);

		// 根据ID取得Team对象
		JSONObject theTeam = client.getTeamById(token, teamid);
		assertTrue(theTeam != null);
		assertEquals(theTeam.get("NAME"), "test_team1");
		assertEquals(theTeam.get("ID"), teamid);

		assertFalse(client.deleteTeamById(token, teamid) == null);

		// 再次尝试取这个Team， 应失败
		theTeam = null;
		try {
			theTeam = client.getTeamById(token, teamid);
		} catch (MwfException mwfex) {
			theTeam = null;
		}
		assertEquals(null, theTeam);

		teamid = client.createTeam(token, "myTeam", "myTeam_Memo");
		JSONObject members = new JSONObject();
		members.put("T001", "Approver");
		members.put("T002", "Auditor");
		members.put("T003", "Approver");
		members.put("T004", "Auditor");
		client.addTeamMembers(token, teamid, members.toString());
		assertEquals(2, client.getTeamMembersByRole(token, teamid, "Approver")
				.size());
		assertEquals(2, client.getTeamMembersByRole(token, teamid, "Auditor")
				.size());
		assertEquals(0, client.getTeamMembersByRole(token, teamid, "Reviewer")
				.size());
		int oldTeamSize = client.getTeamMembers(token, teamid).size();
		client.removeTeamMember(token, teamid, "T002");
		assertEquals(1, client.getTeamMembersByRole(token, teamid, "Auditor")
				.size());
		assertTrue(oldTeamSize - 1 == client.getTeamMembers(token, teamid)
				.size());
		client.removeTeamMember(token, teamid, "T001");
		client.removeTeamMember(token, teamid, "T002");
		client.removeTeamMember(token, teamid, "T003");
		client.removeTeamMember(token, teamid, "T004");
		client.removeTeamMember(token, teamid, "T005");
		assertTrue(0 == client.getTeamMembers(token, teamid).size());

		client.deleteTeamById(token, teamid);

		boolean found = true;
		try {
			client.getTeamById(token, teamid);
		} catch (MwfException mwfex) {
			found = false;
		}
		assertEquals(false, found);

	}

	public void test_admin_VT() throws Exception {
		String token = client.getToken("tester1", "test");
		assertAcsk(token);

		String content = "Hello World!";
		client.deleteVt(token, "vt1");

		int oldVtCount = client.getVts(token).size();
		client.uploadVt(token, content, "vt1");
		assertEquals(oldVtCount, client.getVts(token).size() - 1);
		client.deleteVt(token, "vt1");
		assertEquals(oldVtCount, client.getVts(token).size());

	}

	public void test_OR() throws Exception {
		String token = client.getToken("tester1", "test");
		assertAcsk(token);

		String wft_OR = "<?xml version=\"1.0\" encoding=\"UTF-8\"?>"
				+ "<cf:workflow xsi:schemaLocation=\"http://lkh.com/cflow ../schemas/wft.xsd\" name=\"tobedelete\" owner=\"LKH\" acl=\"private\" lastModified=\"2011-03-19T04:18:58\" created=\"2011-03-19T04:18:58\" xmlns:cf=\"http://lkh.com/cflow\" xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\">"
				+ "<node id=\"id_start\" type=\"start\" title=\"Start\" name=\"Start\" x=\"27\" y=\"213\">\n <next targetID=\"id_1\"/><next targetID=\"id_2\"/><next targetID=\"id_3\"/></node>"
				+ "<node id=\"id_end\" type=\"end\" title=\"End\" name=\"End\" x=\"738\" y=\"213\">\n <next targetID=\"id_end\"/></node>"

				+ "<node id=\"id_1\" type=\"task\" title=\"ID_1\" name=\"ID_1\"  acquirable=\"false\" acqThreshold=\"1\" allowRoleChange=\"false\" allowDelegate=\"false\" allowAdhoc=\"false\" roleToChange=\"all\" form=\"\" mpsm=\"1\">\n "
				+ "<taskto type=\"role\" whom=\"starter\"/>\n <mpcdc/>\n <oec/>\n "
				+ "<next targetID=\"id_OR\"/></node>"

				+ "<node id=\"id_2\" type=\"task\" title=\"ID_2\" name=\"ID_2\"  acquirable=\"false\" acqThreshold=\"1\" allowRoleChange=\"false\" allowDelegate=\"false\" allowAdhoc=\"false\" roleToChange=\"all\" form=\"\" mpsm=\"1\">\n "
				+ "<taskto type=\"role\" whom=\"starter\"/>\n <mpcdc/>\n <oec/>\n "
				+ "<next targetID=\"id_OR\"/></node>"

				+ "<node id=\"id_3\" type=\"task\" title=\"ID_3\" name=\"ID_3\"  acquirable=\"false\" acqThreshold=\"1\" allowRoleChange=\"false\" allowDelegate=\"false\" allowAdhoc=\"false\" roleToChange=\"all\" form=\"\" mpsm=\"1\">\n "
				+ "<taskto type=\"role\" whom=\"starter\"/>\n <mpcdc/>\n <oec/>\n "
				+ "<next targetID=\"id_OR\"/></node>"

				+ "<node id='id_OR' type='or'>"
				+ "<next targetID='id_NULL'/>"
				+ "</node>"

				+ "<node id=\"id_NULL\" type=\"task\" title=\"ID_NULL\" name=\"ID_NULL\"  acquirable=\"false\" acqThreshold=\"1\" allowRoleChange=\"false\" allowDelegate=\"false\" allowAdhoc=\"false\" roleToChange=\"all\" form=\"\" mpsm=\"1\">\n "
				+ "<taskto type=\"role\" whom=\"starter\"/>\n <mpcdc/>\n <oec/>\n "
				+ "<next targetID=\"id_end\"/></node>"

				+ "</cf:workflow>";

		String wftid_OR = client.uploadWft(token, wft_OR, "testProcess_OR");
		assertFalse(wftid_OR.startsWith("ERROR"));

		JSONArray wlist = client.getWorklist(token, "T001");
		int old_wlist_count = wlist.size();

		JSONObject ctx = new JSONObject();
		ctx.put("author", "liukehong");
		String prcid = null;
		try {
			prcid = client.startWorkflow(token, "T001", wftid_OR, null,
					"instnacename_testProcess_OR", ctx);
			assertFalse(prcid.startsWith("ERROR"));
			try {

				// id_apply_leaving
				wlist = client.getWorklist(token, "T001");
				assertTrue(wlist.size() == old_wlist_count + 3);
				JSONObject theWii_1 = getWorkitem(wlist, prcid, "id_1");
				assertTrue(theWii_1 != null);
				JSONObject theWii_2 = getWorkitem(wlist, prcid, "id_2");
				assertTrue(theWii_2 != null);
				JSONObject theWii_3 = getWorkitem(wlist, prcid, "id_3");
				assertTrue(theWii_3 != null);
				client.doTask(token, "T001", prcid,
						(String) theWii_1.get("NODEID"),
						(String) theWii_1.get("SESSID"), null, null);
				wlist = client.getWorklist(token, "T001");
				assertTrue(wlist.size() == old_wlist_count + 1);
				JSONObject prcJson = client.getPrcInfo(token, prcid);
				assertEquals("running", prcJson.get("STATUS"));
				JSONObject theWii_NULL = getWorkitem(wlist, prcid, "id_NULL");
				client.doTask(token, "T001", prcid,
						(String) theWii_NULL.get("NODEID"),
						(String) theWii_NULL.get("SESSID"), null, null);
				wlist = client.getWorklist(token, "T001");
				assertTrue(wlist.size() == old_wlist_count);

				prcJson = client.getPrcInfo(token, prcid);
				assertEquals("finished", prcJson.get("STATUS"));
			} catch (Exception ex) {
				ex.printStackTrace();
			}
		} finally {
			if (prcid != null)
				client.deleteProcess(token, prcid);
			client.deleteWft(token, wftid_OR);
		}

		// do some house clean work.
		wlist = client.getWorklist(token, "T001");
		while (wlist.size() > 0) {
			JSONObject wii = (JSONObject) wlist.get(0);
			String aprcid = (String) wii.get("PRCID");
			client.deleteProcess(token, aprcid);
			wlist = client.getWorklist(token, "T001");
		}

		return;

	}

	private JSONArray myGetWL(String token, String doer) {
		JSONArray ret = null;
		try {
			for (int i = 0; i < 100; i++) {
				ret = client.getWorklist(token, "T001");
				if (ret != null) {
					break;
				}
				if (ret.size() > 0)
					break;
				Thread.sleep(1000);
			}
		} catch (Exception ex) {

		}
		return ret;
	}

	private String myStartWorkflow(String token, String startBy, String wftid,
			String teamId, String instanceName, JSONObject ctx)
			throws Exception {
		return client.startWorkflow(token, startBy, wftid, teamId,
				instanceName, ctx);
	}

	public void test_AND() throws Exception {
		String token = client.getToken("tester1", "test");
		assertAcsk(token);
		cleanHouse(token);

		String wft_AND = "<?xml version=\"1.0\" encoding=\"UTF-8\"?>"
				+ "<cf:workflow xsi:schemaLocation=\"http://lkh.com/cflow ../schemas/wft.xsd\" name=\"tobedelete\" owner=\"LKH\" acl=\"private\" lastModified=\"2011-03-19T04:18:58\" created=\"2011-03-19T04:18:58\" xmlns:cf=\"http://lkh.com/cflow\" xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\">"
				+ "<node id=\"id_start\" type=\"start\" title=\"Start\" name=\"Start\" x=\"27\" y=\"213\">\n <next targetID=\"id_1\"/><next targetID=\"id_2\"/><next targetID=\"id_3\"/></node>"
				+ "<node id=\"id_end\" type=\"end\" title=\"End\" name=\"End\" x=\"738\" y=\"213\">\n <next targetID=\"id_end\"/></node>"

				+ "<node id=\"id_1\" type=\"task\" title=\"ID_1\" name=\"ID_1\"  acquirable=\"false\" acqThreshold=\"1\" allowRoleChange=\"false\" allowDelegate=\"false\" allowAdhoc=\"false\" roleToChange=\"all\" form=\"\" mpsm=\"1\">\n "
				+ "<taskto type=\"role\" whom=\"starter\"/>\n <mpcdc/>\n <oec/>\n "
				+ "<next targetID=\"id_AND\"/></node>"

				+ "<node id=\"id_2\" type=\"task\" title=\"ID_2\" name=\"ID_2\"  acquirable=\"false\" acqThreshold=\"1\" allowRoleChange=\"false\" allowDelegate=\"false\" allowAdhoc=\"false\" roleToChange=\"all\" form=\"\" mpsm=\"1\">\n "
				+ "<taskto type=\"role\" whom=\"starter\"/>\n <mpcdc/>\n <oec/>\n "
				+ "<next targetID=\"id_AND\"/></node>"

				+ "<node id=\"id_3\" type=\"task\" title=\"ID_3\" name=\"ID_3\"  acquirable=\"false\" acqThreshold=\"1\" allowRoleChange=\"false\" allowDelegate=\"false\" allowAdhoc=\"false\" roleToChange=\"all\" form=\"\" mpsm=\"1\">\n "
				+ "<taskto type=\"role\" whom=\"starter\"/>\n <mpcdc/>\n <oec/>\n "
				+ "<next targetID=\"id_AND\"/></node>"

				+ "<node id='id_AND' type='and'>"
				+ "<next targetID='id_NULL'/>"
				+ "</node>"

				+ "<node id=\"id_NULL\" type=\"task\" title=\"ID_NULL\" name=\"ID_NULL\"  acquirable=\"false\" acqThreshold=\"1\" allowRoleChange=\"false\" allowDelegate=\"false\" allowAdhoc=\"false\" roleToChange=\"all\" form=\"\" mpsm=\"1\">\n "
				+ "<taskto type=\"role\" whom=\"starter\"/>\n <mpcdc/>\n <oec/>\n "
				+ "<next targetID=\"id_end\"/></node>"

				+ "</cf:workflow>";

		String wftid_AND = client.uploadWft(token, wft_AND, "testProcess_AND");
		JSONArray wlist = client.getWorklist(token, "T001");
		int old_wlist_count = wlist.size();

		JSONObject ctx = new JSONObject();
		ctx.put("author", "liukehong");

		String teamId = null;
		String tmp = null;
		String prcid = null;
		try {
			prcid = client.startWorkflow(token, "T001", wftid_AND, teamId,
					"testProcess_AND", ctx);
			assertFalse(prcid.startsWith("ERROR"));
			try {

				// id_apply_leaving
				wlist = myGetWL(token, "T001");
				assertTrue(wlist.size() == old_wlist_count + 3);
				JSONObject theWii_1 = getWorkitem(wlist, prcid, "id_1");
				assertTrue(theWii_1 != null);
				JSONObject theWii_2 = getWorkitem(wlist, prcid, "id_2");
				assertTrue(theWii_2 != null);
				JSONObject theWii_3 = getWorkitem(wlist, prcid, "id_3");
				assertTrue(theWii_3 != null);
				JSONObject theWii_NULL = getWorkitem(wlist, prcid, "id_NULL");
				assertTrue(theWii_NULL == null);
				tmp = client.doTask(token, "T001", prcid,
						(String) theWii_1.get("NODEID"),
						(String) theWii_1.get("SESSID"), null, null);
				assertFalse(tmp.startsWith("ERROR"));
				wlist = myGetWL(token, "T001");
				assertTrue(wlist.size() == old_wlist_count + 2);
				tmp = client.doTask(token, "T001", prcid,
						(String) theWii_2.get("NODEID"),
						(String) theWii_2.get("SESSID"), null, null);
				assertFalse(tmp.startsWith("ERROR"));
				wlist = myGetWL(token, "T001");
				assertTrue(wlist.size() == old_wlist_count + 1);
				tmp = client.doTask(token, "T001", prcid,
						(String) theWii_3.get("NODEID"),
						(String) theWii_3.get("SESSID"), null, null);
				assertFalse(tmp.startsWith("ERROR"));
				wlist = myGetWL(token, "T001");
				assertTrue(wlist.size() == old_wlist_count + 1);
				theWii_NULL = getWorkitem(wlist, prcid, "id_NULL");
				assertTrue(theWii_NULL != null);

				tmp = client.doTask(token, "T001", prcid,
						(String) theWii_NULL.get("NODEID"),
						(String) theWii_NULL.get("SESSID"), null, null);
				assertFalse(tmp.startsWith("ERROR"));
				wlist = myGetWL(token, "T001");
				assertTrue(wlist.size() == old_wlist_count);

				JSONObject prcJson = client.getPrcInfo(token, prcid);
				assertEquals("finished", prcJson.get("STATUS"));
			} catch (Exception ex) {
				ex.printStackTrace();
			}
		} finally {

			if (prcid != null)
				client.deleteProcess(token, prcid);

			client.deleteWft(token, wftid_AND);
		}

		wlist = client.getWorklist(token, "T001");
		while (wlist.size() > 0) {
			JSONObject wii = (JSONObject) wlist.get(0);
			String aprcid = (String) wii.get("PRCID");
			client.deleteProcess(token, aprcid);
			wlist = client.getWorklist(token, "T001");
		}

	}

	public void test_mpsm_anydone() throws Exception {
		String token = client.getToken("tester1", "test");
		assertAcsk(token);

		// 新建一个模板， 里面有一个活动，给到流程启动者
		String wft = "<?xml version=\"1.0\" encoding=\"UTF-8\"?><cf:workflow xsi:schemaLocation=\"http://lkh.com/cflow ../schemas/wft.xsd\" name=\"tobedelete\" owner=\"LKH\" acl=\"private\" lastModified=\"2011-03-19T04:18:58\" created=\"2011-03-19T04:18:58\" xmlns:cf=\"http://lkh.com/cflow\" xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\">"
				+ "<node id=\"id_start\" type=\"start\" title=\"Start\" name=\"Start\" x=\"27\" y=\"213\">\n <next targetID=\"id_1\"/></node>"
				+ "<node id=\"id_end\" type=\"end\" title=\"End\" name=\"End\" x=\"738\" y=\"213\">\n <next targetID=\"id_end\"/></node>"
				+ "<node id=\"id_1\" type=\"task\" title=\"mpsm_1\" name=\"Task\" x=\"356\" y=\"203\" acquirable=\"false\" acqThreshold=\"1\" allowRoleChange=\"false\" allowDelegate=\"false\" allowAdhoc=\"false\" roleToChange=\"all\" form=\"\" mpsm=\"1\">\n <taskto type=\"role\" whom=\"Approver\"/>\n <mpcdc/>\n <oec/>\n <next targetID=\"id_end\"/>\n </node>"
				+ "</cf:workflow>";
		String wftid = client.uploadWft(token, wft, "mpsm_1");

		JSONObject team = null;
		try {
			team = client.getTeamByName(token, "test_team2");
			client.deleteTeamById(token, (String) team.get("ID"));
		} catch (MwfException ex) {

		}
		String teamid = client.createTeam(token, "test_team2",
				"test_team2_memo");
		JSONObject members = new JSONObject();
		members.put("T002", "Approver");
		members.put("T003", "Approver");
		members.put("T004", "Approver");
		members.put("T005", "Approver");

		client.addTeamMembers(token, teamid, members);

		JSONObject ctx = new JSONObject();
		ctx.put("author", "liukehong");
		String prcid = null;
		try {
			prcid = client.startWorkflow(token, "T001", wftid, teamid,
					"testMpsm_1", ctx);
			assertFalse(prcid.startsWith("ERROR"));

			JSONObject prcJson = client.getPrcInfo(token, prcid);
			assertEquals("running", prcJson.get("STATUS"));
			String thePrcId = (String) prcJson.get("PRCID");
			assertEquals(prcid, thePrcId);

			JSONArray wlist_07 = client.getWorklist(token, "T002", prcid);
			JSONArray wlist_08 = client.getWorklist(token, "T003", prcid);
			JSONArray wlist_09 = client.getWorklist(token, "T004", prcid);
			JSONArray wlist_10 = client.getWorklist(token, "T005", prcid);
			assertTrue(wlist_07.size() > 0);
			assertTrue(wlist_08.size() > 0);
			assertTrue(wlist_09.size() > 0);
			assertTrue(wlist_10.size() > 0);
			JSONObject theWii_07 = getWorkitem(wlist_07, prcid, "id_1");
			assertTrue(theWii_07 != null);
			JSONObject theWii_08 = getWorkitem(wlist_08, prcid, "id_1");
			assertTrue(theWii_08 != null);
			JSONObject theWii_09 = getWorkitem(wlist_09, prcid, "id_1");
			assertTrue(theWii_09 != null);
			JSONObject theWii_10 = getWorkitem(wlist_10, prcid, "id_1");
			assertTrue(theWii_10 != null);

			client.doTask(token, "T002", prcid,
					(String) theWii_08.get("NODEID"),
					(String) theWii_08.get("SESSID"), null, null);

			wlist_07 = client.getWorklist(token, "T002", prcid);
			wlist_08 = client.getWorklist(token, "T003", prcid);
			wlist_09 = client.getWorklist(token, "T004", prcid);
			wlist_10 = client.getWorklist(token, "T005", prcid);
			assertTrue(wlist_07.size() == 0);
			assertTrue(wlist_08.size() == 0);
			assertTrue(wlist_09.size() == 0);
			assertTrue(wlist_10.size() == 0);

			prcJson = client.getPrcInfo(token, prcid);
			assertEquals("finished", prcJson.get("STATUS"));

			assertEquals(teamid, client.deleteTeamById(token, teamid));

		} finally {
			if (prcid != null)
				client.deleteProcess(token, prcid);
			client.deleteWft(token, wftid);
		}

	}

	public void test_mpsm_alldone() throws Exception {
		String token = client.getToken("tester1", "test");
		assertAcsk(token);

		// 新建一个模板， 里面有一个活动，给到流程启动者
		String wft = "<?xml version=\"1.0\" encoding=\"UTF-8\"?><cf:workflow xsi:schemaLocation=\"http://lkh.com/cflow ../schemas/wft.xsd\" name=\"tobedelete\" owner=\"LKH\" acl=\"private\" lastModified=\"2011-03-19T04:18:58\" created=\"2011-03-19T04:18:58\" xmlns:cf=\"http://lkh.com/cflow\" xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\">"
				+ "<node id=\"id_start\" type=\"start\" title=\"Start\" name=\"Start\" x=\"27\" y=\"213\">\n <next targetID=\"id_1\"/></node>"
				+ "<node id=\"id_end\" type=\"end\" title=\"End\" name=\"End\" x=\"738\" y=\"213\">\n <next targetID=\"id_end\"/></node>"
				+ "<node id=\"id_1\" type=\"task\" title=\"mpsm_2\" name=\"Task\" x=\"356\" y=\"203\" acquirable=\"false\" acqThreshold=\"1\" allowRoleChange=\"false\" allowDelegate=\"false\" allowAdhoc=\"false\" roleToChange=\"all\" form=\"\" mpsm=\"2\">\n <taskto type=\"role\" whom=\"Approver\"/>\n <mpcdc/>\n <oec>if(total==4) return \"4\"; else return \"DEFAULT\";</oec>\n <next option=\"4\" targetID=\"id_4\"/>\n <next option=\"DEFAULT\" targetID=\"id_end\"/>\n </node>"
				+ "<node id=\"id_4\" type=\"task\" title=\"totalequalsto4\" name=\"Task\" x=\"356\" y=\"203\" acquirable=\"false\" acqThreshold=\"1\" allowRoleChange=\"false\" allowDelegate=\"false\" allowAdhoc=\"false\" roleToChange=\"all\" form=\"\" mpsm=\"1\">\n <taskto type=\"role\" whom=\"starter\"/>\n <mpcdc/>\n <oec/>\n <next targetID=\"id_end\"/>\n  </node>"
				+ "</cf:workflow>";
		String wftid = client.uploadWft(token, wft, "mpsm_2");

		String teamid = client.createTeam(token, "test_team2",
				"test_team2_memo");
		JSONObject members = new JSONObject();
		members.put("T002", "Approver");
		members.put("T003", "Approver");
		members.put("T004", "Approver");
		members.put("T005", "Approver");

		client.addTeamMembers(token, teamid, members);

		JSONObject ctx = new JSONObject();
		ctx.put("author", "liukehong");
		String prcid = null;
		try {
			prcid = client.startWorkflow(token, "T001", wftid, teamid,
					"testMpsm_2", ctx);
			assertFalse(prcid.startsWith("ERROR"));
			JSONObject prcJson = client.getPrcInfo(token, prcid);
			assertEquals("running", prcJson.get("STATUS"));
			String thePrcId = (String) prcJson.get("PRCID");
			assertEquals(prcid, thePrcId);

			JSONArray wlist;
			JSONObject theWii;
			JSONArray wlist_07 = client.getWorklist(token, "T002", prcid);
			JSONArray wlist_08 = client.getWorklist(token, "T003", prcid);
			JSONArray wlist_09 = client.getWorklist(token, "T004", prcid);
			JSONArray wlist_10 = client.getWorklist(token, "T005", prcid);
			assertTrue(wlist_07.size() > 0);
			assertTrue(wlist_08.size() > 0);
			assertTrue(wlist_09.size() > 0);
			assertTrue(wlist_10.size() > 0);
			JSONObject theWii_07 = getWorkitem(wlist_07, prcid, "id_1");
			assertTrue(theWii_07 != null);
			JSONObject theWii_08 = getWorkitem(wlist_08, prcid, "id_1");
			assertTrue(theWii_08 != null);
			JSONObject theWii_09 = getWorkitem(wlist_09, prcid, "id_1");
			assertTrue(theWii_09 != null);
			JSONObject theWii_10 = getWorkitem(wlist_10, prcid, "id_1");
			assertTrue(theWii_10 != null);

			client.doTask(token, "T003", prcid,
					(String) theWii_08.get("NODEID"),
					(String) theWii_08.get("SESSID"), null, null);

			wlist_07 = client.getWorklist(token, "T002", prcid);
			wlist_08 = client.getWorklist(token, "T003", prcid);
			wlist_09 = client.getWorklist(token, "T004", prcid);
			wlist_10 = client.getWorklist(token, "T005", prcid);
			assertTrue(wlist_07.size() > 0);
			assertTrue(wlist_08.size() == 0);
			assertTrue(wlist_09.size() > 0);
			assertTrue(wlist_10.size() > 0);

			theWii_07 = getWorkitem(wlist_07, prcid, "id_1");
			assertTrue(theWii_07 != null);
			client.doTask(token, "T002", prcid,
					(String) theWii_07.get("NODEID"),
					(String) theWii_07.get("SESSID"), null, null);

			wlist_07 = client.getWorklist(token, "T002", prcid);
			wlist_08 = client.getWorklist(token, "T003", prcid);
			wlist_09 = client.getWorklist(token, "T004", prcid);
			wlist_10 = client.getWorklist(token, "T005", prcid);
			assertTrue(wlist_07.size() == 0);
			assertTrue(wlist_08.size() == 0);
			assertTrue(wlist_09.size() > 0);
			assertTrue(wlist_10.size() > 0);

			theWii_09 = getWorkitem(wlist_09, prcid, "id_1");
			assertTrue(theWii_09 != null);
			client.doTask(token, "T004", prcid,
					(String) theWii_09.get("NODEID"),
					(String) theWii_09.get("SESSID"), null, null);

			wlist_07 = client.getWorklist(token, "T002", prcid);
			wlist_08 = client.getWorklist(token, "T003", prcid);
			wlist_09 = client.getWorklist(token, "T004", prcid);
			wlist_10 = client.getWorklist(token, "T005", prcid);
			assertTrue(wlist_07.size() == 0);
			assertTrue(wlist_08.size() == 0);
			assertTrue(wlist_09.size() == 0);
			assertTrue(wlist_10.size() > 0);

			theWii_10 = getWorkitem(wlist_10, prcid, "id_1");
			assertTrue(theWii_10 != null);
			client.doTask(token, "T005", prcid,
					(String) theWii_10.get("NODEID"),
					(String) theWii_10.get("SESSID"), null, null);

			wlist_07 = client.getWorklist(token, "T002", prcid);
			wlist_08 = client.getWorklist(token, "T003", prcid);
			wlist_09 = client.getWorklist(token, "T004", prcid);
			wlist_10 = client.getWorklist(token, "T005", prcid);
			assertTrue(wlist_07.size() == 0);
			assertTrue(wlist_08.size() == 0);
			assertTrue(wlist_09.size() == 0);
			assertTrue(wlist_10.size() == 0);

			wlist = client.getWorklist(token, "T001");
			assertTrue(wlist.size() > 0);
			theWii = getWorkitem(wlist, prcid, "id_4");
			assertTrue(theWii != null);
			client.doTask(token, "T001", prcid, (String) theWii.get("NODEID"),
					(String) theWii.get("SESSID"), null, null);

			prcJson = client.getPrcInfo(token, prcid);
			assertEquals("finished", prcJson.get("STATUS"));

			assertEquals(teamid, client.deleteTeamById(token, teamid));

		} finally {
			if (prcid != null)
				client.deleteProcess(token, prcid);
			client.deleteWft(token, wftid);
		}

	}

	public void test_mpsm_variabledone() throws Exception {
		String token = client.getToken("tester1", "test");
		assertAcsk(token);

		// 新建一个模板， 里面有一个活动，给到流程启动者
		String wft = "<?xml version=\"1.0\" encoding=\"UTF-8\"?><cf:workflow xsi:schemaLocation=\"http://lkh.com/cflow ../schemas/wft.xsd\" name=\"tobedelete\" owner=\"LKH\" acl=\"private\" lastModified=\"2011-03-19T04:18:58\" created=\"2011-03-19T04:18:58\" xmlns:cf=\"http://lkh.com/cflow\" xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\">"
				+ "<node id=\"id_start\" type=\"start\" title=\"Start\" name=\"Start\" x=\"27\" y=\"213\">\n <next targetID=\"id_1\"/></node>"
				+ "<node id=\"id_end\" type=\"end\" title=\"End\" name=\"End\" x=\"738\" y=\"213\">\n <next targetID=\"id_end\"/></node>"
				+ "<node id=\"id_1\" type=\"task\" title=\"mpsm_2\" name=\"Task\" x=\"356\" y=\"203\" acquirable=\"false\" acqThreshold=\"1\" allowRoleChange=\"false\" allowDelegate=\"false\" allowAdhoc=\"false\" roleToChange=\"all\" form=\"\" mpsm=\"3\">\n <taskto type=\"role\" whom=\"Approver\"/>\n <mpcdc>if(finished>=2) return \"true\"; else return \"false\";</mpcdc>\n <oec>if(finished>=2) return \"4\"; else return \"DEFAULT\";</oec>\n <next option=\"4\" targetID=\"id_4\"/>\n <next option=\"DEFAULT\" targetID=\"id_end\"/>\n </node>"
				+ "<node id=\"id_4\" type=\"task\" title=\"totalequalsto4\" name=\"Task\" x=\"356\" y=\"203\" acquirable=\"false\" acqThreshold=\"1\" allowRoleChange=\"false\" allowDelegate=\"false\" allowAdhoc=\"false\" roleToChange=\"all\" form=\"\" mpsm=\"1\">\n <taskto type=\"role\" whom=\"starter\"/>\n <mpcdc/>\n <oec/>\n <next targetID=\"id_end\"/>\n  </node>"
				+ "</cf:workflow>";
		String wftid = client.uploadWft(token, wft, "mpsm_3");

		String teamid = client.createTeam(token, "test_team2",
				"test_team2_memo");
		JSONObject members = new JSONObject();
		members.put("T002", "Approver");
		members.put("T003", "Approver");
		members.put("T004", "Approver");
		members.put("T005", "Approver");

		client.addTeamMembers(token, teamid, members.toString());

		// T001启动流程
		String prcid = null;
		try {
			prcid = client.startWorkflow(token, "T001", wftid, teamid,
					"testMpsm_3", null);
			assertFalse(prcid.startsWith("ERROR"));

			JSONObject prcJson = client.getPrcInfo(token, prcid);
			assertEquals("running", prcJson.get("STATUS"));
			String thePrcId = (String) prcJson.get("PRCID");
			assertEquals(prcid, thePrcId);

			// 四个用户都应该收到工作项
			JSONArray wlist;
			JSONObject theWii;
			JSONArray wlist_07 = client.getWorklist(token, "T002", prcid);
			JSONArray wlist_08 = client.getWorklist(token, "T003", prcid);
			JSONArray wlist_09 = client.getWorklist(token, "T004", prcid);
			JSONArray wlist_10 = client.getWorklist(token, "T005", prcid);
			assertTrue(wlist_07.size() > 0);
			assertTrue(wlist_08.size() > 0);
			assertTrue(wlist_09.size() > 0);
			assertTrue(wlist_10.size() > 0);
			JSONObject theWii_07 = getWorkitem(wlist_07, prcid, "id_1");
			assertTrue(theWii_07 != null);
			JSONObject theWii_08 = getWorkitem(wlist_08, prcid, "id_1");
			assertTrue(theWii_08 != null);
			JSONObject theWii_09 = getWorkitem(wlist_09, prcid, "id_1");
			assertTrue(theWii_09 != null);
			JSONObject theWii_10 = getWorkitem(wlist_10, prcid, "id_1");
			assertTrue(theWii_10 != null);

			// T003完成id_1
			client.doTask(token, "T003", prcid,
					(String) theWii_08.get("NODEID"),
					(String) theWii_08.get("SESSID"), null, null);

			wlist_07 = client.getWorklist(token, "T002", prcid);
			wlist_08 = client.getWorklist(token, "T003", prcid);
			wlist_09 = client.getWorklist(token, "T004", prcid);
			wlist_10 = client.getWorklist(token, "T005", prcid);
			assertTrue(wlist_07.size() > 0);
			assertTrue(wlist_08.size() == 0);
			assertTrue(wlist_09.size() > 0);
			assertTrue(wlist_10.size() > 0);

			// T002完成id_1
			theWii_07 = getWorkitem(wlist_07, prcid, "id_1");
			assertTrue(theWii_07 != null);
			client.doTask(token, "T002", prcid,
					(String) theWii_07.get("NODEID"),
					(String) theWii_07.get("SESSID"), null, null);

			// 流向id_4;
			// 所有id_1上的工作取消
			wlist_07 = client.getWorklist(token, "T002", prcid);
			wlist_08 = client.getWorklist(token, "T003", prcid);
			wlist_09 = client.getWorklist(token, "T004", prcid);
			wlist_10 = client.getWorklist(token, "T005", prcid);
			assertTrue(wlist_07.size() == 0);
			assertTrue(wlist_08.size() == 0);
			assertTrue(wlist_09.size() == 0);
			assertTrue(wlist_10.size() == 0);

			wlist = client.getWorklist(token, "T001");
			assertTrue(wlist.size() > 0);
			theWii = getWorkitem(wlist, prcid, "id_4");
			assertTrue(theWii != null);
			client.doTask(token, "T001", prcid, (String) theWii.get("NODEID"),
					(String) theWii.get("SESSID"), null, null);

			prcJson = client.getPrcInfo(token, prcid);
			assertEquals("finished", prcJson.get("STATUS"));

			assertEquals(teamid, client.deleteTeamById(token, teamid));
		} finally {
			if (prcid != null)
				client.deleteProcess(token, prcid);
			client.deleteWft(token, wftid);
		}

	}

	public void test_admin_process_admin() throws Exception {
		String token = client.getToken("tester1", "test");
		assertAcsk(token);

		// 新建一个模板， 里面有一个活动，给到流程启动者
		String wft = "<?xml version=\"1.0\" encoding=\"UTF-8\"?><cf:workflow xsi:schemaLocation=\"http://lkh.com/cflow ../schemas/wft.xsd\" name=\"tobedelete\" owner=\"LKH\" acl=\"private\" lastModified=\"2011-03-19T04:18:58\" created=\"2011-03-19T04:18:58\" xmlns:cf=\"http://lkh.com/cflow\" xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\">"
				+ "<node id=\"58DE1222-4446-C2DE-1F8B-CA9EBE43C965\" type=\"start\" title=\"Start\" name=\"Start\" x=\"27\" y=\"213\">\n <next targetID=\"id_1\"/></node>"
				+ "<node id=\"7E40C95C-333D-964E-2EA3-CA9EBE457AE1\" type=\"end\" title=\"End\" name=\"End\" x=\"738\" y=\"213\">\n <next targetID=\"7E40C95C-333D-964E-2EA3-CA9EBE457AE1\"/></node>"
				+ "<node id=\"id_1\" type=\"task\" title=\"Task\" name=\"Task\" x=\"356\" y=\"203\" acquirable=\"false\" acqThreshold=\"1\" allowRoleChange=\"false\" allowDelegate=\"false\" allowAdhoc=\"false\" roleToChange=\"all\" form=\"\" mpsm=\"1\">\n <taskto type=\"role\" whom=\"starter\"/>\n <mpcdc/>\n <oec/>\n <next targetID=\"7E40C95C-333D-964E-2EA3-CA9EBE457AE1\"/>\n </node>"
				+ "</cf:workflow>";
		String wftname = "rstest1";

		String wftid = client.uploadWft(token, wft, wftname);

		// 新建一个Team
		String teamid = client.createTeam(token, "test_team2",
				"test_team2_memo");

		// 取正在运行的进程
		JSONArray runningProcs = client.getProcessesByStatus(token, "running");
		int running_processes_number = runningProcs.size();

		// 启动进程
		JSONObject ctx = new JSONObject();
		ctx.put("author", "liukehong");
		String prcid = null;
		try {
			prcid = client.startWorkflow(token, "T001", wftid, teamid,
					"test_process2", ctx);
			assertFalse(prcid.startsWith("ERROR"));

			// 重新取出正在运行的进程，其个数应该增加了1
			runningProcs = client.getProcessesByStatus(token, "running");
			int new_running_processes_number = runningProcs.size();
			assertEquals(running_processes_number + 1,
					new_running_processes_number);

			// 取该进程的内容（JSON格式）
			JSONObject prcJson = client.getPrcInfo(token, prcid);
			assertEquals("running", prcJson.get("STATUS"));
			assertEquals(prcid, prcJson.get("PRCID"));

			// 取得worklist, 找到属于该进程的那个work
			JSONArray wlist = client.getWorklist(token, "T001", prcid);
			assertTrue(wlist.size() > 0);
			JSONObject theWii = getWorkitem(wlist, prcid, "id_1");
			assertTrue(theWii != null);

			// Suspend该进程
			String tt = client.suspendProcess(token, prcid);
			assertFalse(tt == null);

			// 再取worklist, 应该找不到前面那个work
			wlist = client.getWorklist(token, "T001", prcid);
			assertTrue(wlist.size() == 0);
			theWii = getWorkitem(wlist, prcid, "id_1");
			assertTrue(theWii == null);

			// Resume该进程
			tt = client.resumeProcess(token, prcid);
			assertFalse(tt == null);

			// 再取worklist, 应该再次找到前面那个work
			wlist = client.getWorklist(token, "T001", prcid);
			assertTrue(wlist.size() > 0);
			theWii = getWorkitem(wlist, prcid, "id_1");
			assertTrue(theWii != null);
			String theNodeId = (String) theWii.get("NODEID");

			// 取得当前活动节点
			// 挂起这个节点
			client.suspendWork(token, prcid, theNodeId);

			// 再取worklist, 应该找不到前面那个work
			wlist = client.getWorklist(token, "T001", prcid);
			assertTrue(wlist.size() >= 0);
			theWii = getWorkitem(wlist, prcid, "id_1");
			assertTrue(theWii == null);

			// 恢复这个节点
			client.resumeWork(token, prcid, theNodeId);

			// 再取worklist, 应该再次找到前面那个work
			wlist = client.getWorklist(token, "T001", prcid);
			assertTrue(wlist.size() > 0);
			theWii = getWorkitem(wlist, prcid, "id_1");
			assertTrue(theWii != null);

			JSONArray T3307_wlist = client.getWorklist(token, "T002", prcid);

			// 测试Delegation.
			// LKH将工作委托给T002
			String ret = client.delegate(token, (String) theWii.get("PRCID"),
					(String) theWii.get("SESSID"), "T001", "T002");
			assertTrue(ret != null);

			JSONArray tmpWL = client.getWorklist(token, "T001", prcid);
			assertTrue(tmpWL.size() == 0);

			// 再取T002的Worklist， T002的工作列表中应该多了一个。
			JSONArray T3307_new_wlist = client
					.getWorklist(token, "T002", prcid);
			assertEquals(T3307_wlist.size() + 1, T3307_new_wlist.size());
			JSONObject T3307_theWii = getWorkitem(T3307_new_wlist, prcid,
					"id_1");

			// 完成这个work
			client.doTask(token, "T002", (String) T3307_theWii.get("PRCID"),
					(String) T3307_theWii.get("NODEID"),
					(String) T3307_theWii.get("SESSID"), null, null);

			tmpWL = client.getWorklist(token, "T002", prcid);
			assertTrue(tmpWL.size() == 0);

			// 再次看这个进程的状态，应该是完成状态
			prcJson = client.getPrcInfo(token,
					(String) T3307_theWii.get("PRCID"));
			assertEquals("finished", prcJson.get("STATUS"));
		} finally {

			// 删除这个新进程
			if (prcid != null)
				client.deleteProcess(token, prcid);

			// 删除前面测试创建的Team
			client.deleteTeamById(token, teamid);

			// 删除这个模板
			client.deleteWft(token, wftid);
		}

	}

	public void test_delegation() throws Exception {
		String token = client.getToken("tester1", "test");
		assertAcsk(token);

		// 新建一个模板， 里面有一个活动，给到流程启动者
		String wft = "<?xml version=\"1.0\" encoding=\"UTF-8\"?><cf:workflow xsi:schemaLocation=\"http://lkh.com/cflow ../schemas/wft.xsd\" name=\"tobedelete\" owner=\"LKH\" acl=\"private\" lastModified=\"2011-03-19T04:18:58\" created=\"2011-03-19T04:18:58\" xmlns:cf=\"http://lkh.com/cflow\" xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\">"
				+ "<node id=\"58DE1222-4446-C2DE-1F8B-CA9EBE43C965\" type=\"start\" title=\"Start\" name=\"Start\" x=\"27\" y=\"213\">\n <next targetID=\"id_1\"/></node>"
				+ "<node id=\"7E40C95C-333D-964E-2EA3-CA9EBE457AE1\" type=\"end\" title=\"End\" name=\"End\" x=\"738\" y=\"213\">\n <next targetID=\"7E40C95C-333D-964E-2EA3-CA9EBE457AE1\"/></node>"
				+ "<node id=\"id_1\" type=\"task\" title=\"Task\" name=\"Task\" x=\"356\" y=\"203\" acquirable=\"false\" acqThreshold=\"1\" allowRoleChange=\"false\" allowDelegate=\"false\" allowAdhoc=\"false\" roleToChange=\"all\" form=\"\" mpsm=\"1\">\n <taskto type=\"role\" whom=\"starter\"/>\n <mpcdc/>\n <oec/>\n <next targetID=\"7E40C95C-333D-964E-2EA3-CA9EBE457AE1\"/>\n </node>"
				+ "</cf:workflow>";
		String wftname = "rstest1";

		String wftid = client.uploadWft(token, wft, wftname);

		// 新建一个Team
		String teamid = client.createTeam(token, "test_team2",
				"test_team2_memo");

		// 取正在运行的进程
		JSONArray runningProcs = client.getProcessesByStatus(token, "running");
		int running_processes_number = runningProcs.size();

		// 启动进程
		JSONObject ctx = new JSONObject();
		ctx.put("author", "liukehong");
		String prcid = null;
		try {
			prcid = client.startWorkflow(token, "T001", wftid, teamid,
					"test_process2", ctx);
			assertFalse(prcid.startsWith("ERROR"));

			// 重新取出正在运行的进程，其个数应该增加了1
			runningProcs = client.getProcessesByStatus(token, "running");
			int new_running_processes_number = runningProcs.size();
			assertEquals(running_processes_number + 1,
					new_running_processes_number);

			// 取该进程的内容（JSON格式）
			JSONObject prcJson = client.getPrcInfo(token, prcid);
			assertEquals("running", prcJson.get("STATUS"));
			assertEquals(prcid, prcJson.get("PRCID"));

			// 取得worklist, 找到属于该进程的那个work
			JSONArray wlist = client.getWorklist(token, "T001", prcid);
			assertTrue(wlist.size() > 0);
			JSONObject theWii = getWorkitem(wlist, prcid, "id_1");
			assertTrue(theWii != null);

			JSONArray T3307_wlist = client.getWorklist(token, "T002", prcid);
			assertTrue(T3307_wlist.size() == 0);

			// 测试Delegation.
			// LKH将工作委托给T002
			String ret = client.delegate(token, (String) theWii.get("PRCID"),
					(String) theWii.get("SESSID"), "T001", "T002");
			assertTrue(ret != null);

			JSONArray tmpWL = client.getWorklist(token, "T001", prcid);
			assertTrue(tmpWL.size() == 0);

			// 再取T002的Worklist， T002的工作列表中应该多了一个。
			JSONArray T3307_new_wlist = client
					.getWorklist(token, "T002", prcid);
			assertEquals(T3307_wlist.size() + 1, T3307_new_wlist.size());
			JSONObject T3307_theWii = getWorkitem(T3307_new_wlist, prcid,
					"id_1");

			// 完成这个work
			client.doTask(token, "T002", (String) T3307_theWii.get("PRCID"),
					(String) T3307_theWii.get("NODEID"),
					(String) T3307_theWii.get("SESSID"), null, null);

			tmpWL = client.getWorklist(token, "T002", prcid);
			assertTrue(tmpWL.size() == 0);

			// 再次看这个进程的状态，应该是完成状态
			prcJson = client.getPrcInfo(token,
					(String) T3307_theWii.get("PRCID"));
			assertEquals("finished", prcJson.get("STATUS"));
		} finally {
			// 删除这个新进程
			if (prcid != null)
				client.deleteProcess(token, prcid);

			// 删除前面测试创建的Team
			client.deleteTeamById(token, teamid);

			// 删除这个模板
			client.deleteWft(token, wftid);
		}

	}

	// 测试工作流模板中制定活动给特定的用户名 <taskto type=\"person\" whom=\"T3307\"/>\
	public void test_taskto_user() throws Exception {
		String token = client.getToken("tester1", "test");
		assertAcsk(token);

		// 新建一个模板， 活动id_1，给到流程启动者
		// 活动 id_2, 制定给到T004
		String wft = "<?xml version=\"1.0\" encoding=\"UTF-8\"?><cf:workflow xsi:schemaLocation=\"http://lkh.com/cflow ../schemas/wft.xsd\" name=\"tobedelete\" owner=\"LKH\" acl=\"private\" lastModified=\"2011-03-19T04:18:58\" created=\"2011-03-19T04:18:58\" xmlns:cf=\"http://lkh.com/cflow\" xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\">"
				+ "<node id=\"id_start\" type=\"start\" title=\"Start\" name=\"Start\" x=\"27\" y=\"213\">\n <next targetID=\"id_1\"/></node>"
				+ "<node id=\"id_end\" type=\"end\" title=\"End\" name=\"End\" x=\"738\" y=\"213\">\n <next targetID=\"id_end\"/></node>"
				+ "<node id=\"id_1\" type=\"task\" title=\"Apply Leaving\" name=\"Apply Leaving\" x=\"356\" y=\"203\" acquirable=\"false\" acqThreshold=\"1\" allowRoleChange=\"false\" allowDelegate=\"false\" allowAdhoc=\"false\" roleToChange=\"all\" form=\"\" mpsm=\"1\">\n <taskto type=\"role\" whom=\"starter\"/>\n <mpcdc/>\n <oec/>\n <next targetID=\"id_2\"/>\n </node>"
				+ "<node id=\"id_2\" type=\"task\" title=\"Approve Leaving\" name=\"Approve Leaving\" x=\"356\" y=\"203\" acquirable=\"false\" acqThreshold=\"1\" allowRoleChange=\"false\" allowDelegate=\"false\" allowAdhoc=\"false\" roleToChange=\"all\" form=\"\" mpsm=\"1\">\n <taskto type=\"person\" whom=\"T004\"/>\n <mpcdc/>\n <oec/>\n <next targetID=\"id_end\"/>\n </node>"
				+ "</cf:workflow>";
		String wftid = client.uploadWft(token, wft, "testProcess_1");

		// 启动进程
		String prcid = null;
		try {
			prcid = client.startWorkflow(token, "T001", wftid, null,
					"testProcess_1", null);
			assertFalse(prcid.startsWith("ERROR"));

			// 取该进程的内容（JSON格式）
			JSONObject prcJson = client.getPrcInfo(token, prcid);
			assertEquals("running", prcJson.get("STATUS"));
			String thePrcId = (String) prcJson.get("PRCID");
			assertEquals(prcid, thePrcId);

			// 取得worklist, 找到属于该进程的那个work
			JSONArray wlist = client.getWorklist(token, "T001", prcid);
			assertTrue(wlist.size() > 0);
			JSONObject theWii = getWorkitem(wlist, prcid, "id_1");
			assertTrue(theWii != null);

			// 完成这个work
			client.doTask(token, "T001", prcid, (String) theWii.get("NODEID"),
					(String) theWii.get("SESSID"), null, null);

			JSONArray T004_wlist = client.getWorklist(token, "T004");

			JSONObject T004_theWii = getWorkitem(T004_wlist, prcid, "id_2");
			assertTrue(T004_theWii != null);

			client.doTask(token, "T004", (String) T004_theWii.get("PRCID"),
					(String) T004_theWii.get("NODEID"),
					(String) T004_theWii.get("SESSID"), null, null);

			// 再次看这个进程的状态，应该是完成状态
			prcJson = client.getPrcInfo(token, prcid);
			assertEquals("finished", prcJson.get("STATUS"));

			// T004 再取worklist, 应该找不到前面那个work
			T004_wlist = client.getWorklist(token, "T004");
			T004_theWii = getWorkitem(T004_wlist, prcid, "id_5");
			assertTrue(T004_theWii == null);
		} finally {
			if (prcid != null)
				client.deleteProcess(token, prcid);
			client.deleteWft(token, wftid);

			cleanHouse(token);
		}

	}

	// 测试工作流模板中制定活动给特定的角色和reference
	public void test_taskto_role_reference() throws Exception {
		String token = client.getToken("tester1", "test");
		assertAcsk(token);

		// 新建一个模板， 活动id_1，给到流程启动者
		// 活动 id_2, 给到 role Approver
		// 活动 id_3, 给到 role Auditor
		// 活动 id_4, 给到 与id_2一样
		// 活动 id_5, 给到 与id_1一样
		// 活动 id_6, 给到 person T005
		String wft = "<?xml version=\"1.0\" encoding=\"UTF-8\"?><cf:workflow xsi:schemaLocation=\"http://lkh.com/cflow ../schemas/wft.xsd\" name=\"tobedelete\" owner=\"LKH\" acl=\"private\" lastModified=\"2011-03-19T04:18:58\" created=\"2011-03-19T04:18:58\" xmlns:cf=\"http://lkh.com/cflow\" xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\">"
				+ "<node id=\"id_start\" type=\"start\" title=\"Start\" name=\"Start\" x=\"27\" y=\"213\">\n <next targetID=\"id_1\"/></node>"
				+ "<node id=\"id_end\" type=\"end\" title=\"End\" name=\"End\" x=\"738\" y=\"213\">\n <next targetID=\"id_end\"/></node>"
				+ "<node id=\"id_1\" type=\"task\" title=\"Apply Leaving\" name=\"Apply Leaving\" x=\"356\" y=\"203\" acquirable=\"false\" acqThreshold=\"1\" allowRoleChange=\"false\" allowDelegate=\"false\" allowAdhoc=\"false\" roleToChange=\"all\" form=\"\" mpsm=\"1\">\n <taskto type=\"role\" whom=\"starter\"/>\n <mpcdc/>\n <oec/>\n <next targetID=\"id_2\"/>\n </node>"
				+ "<node id=\"id_2\" type=\"task\" title=\"Approve Leaving\" name=\"Approve Leaving\" x=\"356\" y=\"203\" acquirable=\"false\" acqThreshold=\"1\" allowRoleChange=\"false\" allowDelegate=\"false\" allowAdhoc=\"false\" roleToChange=\"all\" form=\"\" mpsm=\"1\">\n <taskto type=\"role\" whom=\"Approver\"/>\n <mpcdc/>\n <oec/>\n <next targetID=\"id_3\"/>\n </node>"
				+ "<node id=\"id_3\" type=\"task\" title=\"Auditor Leaving\" name=\"Auditor Leaving\" x=\"356\" y=\"203\" acquirable=\"false\" acqThreshold=\"1\" allowRoleChange=\"false\" allowDelegate=\"false\" allowAdhoc=\"false\" roleToChange=\"all\" form=\"\" mpsm=\"1\">\n <taskto type=\"role\" whom=\"Auditor\"/>\n <mpcdc/>\n <oec/>\n <next targetID=\"id_4\"/>\n </node>"
				+ "<node id=\"id_4\" type=\"task\" title=\"Approver Check Result\" name=\"Approver Check Result\" x=\"356\" y=\"203\" acquirable=\"false\" acqThreshold=\"1\" allowRoleChange=\"false\" allowDelegate=\"false\" allowAdhoc=\"false\" roleToChange=\"all\" form=\"\" mpsm=\"1\">\n <taskto type=\"RefertoNode\" whom=\"id_2\"/>\n <mpcdc/>\n <oec/>\n <next targetID=\"id_5\"/>\n </node>"
				+ "<node id=\"id_5\" type=\"task\" title=\"Starter Check Result\" name=\"Starter Check Result\" x=\"356\" y=\"203\" acquirable=\"false\" acqThreshold=\"1\" allowRoleChange=\"false\" allowDelegate=\"false\" allowAdhoc=\"false\" roleToChange=\"all\" form=\"\" mpsm=\"1\">\n <taskto type=\"RefertoNode\" whom=\"id_1\"/>\n <mpcdc/>\n <oec/>\n <next targetID=\"id_6\"/>\n </node>"
				+ "<node id=\"id_6\" type=\"task\" title=\"Approve Leaving\" name=\"Approve Leaving\" x=\"356\" y=\"203\" acquirable=\"false\" acqThreshold=\"1\" allowRoleChange=\"false\" allowDelegate=\"false\" allowAdhoc=\"false\" roleToChange=\"all\" form=\"\" mpsm=\"1\">\n <taskto type=\"person\" whom=\"T005\"/>\n <mpcdc/>\n <oec/>\n <next targetID=\"id_end\"/>\n </node>"
				+ "</cf:workflow>";

		String wftid = client.uploadWft(token, wft, "testProcess_2");

		// 新建一个Team
		String teamid = client.createTeam(token, "test_team2",
				"test_team2_memo");
		// 指派团队成员
		JSONObject members = new JSONObject();
		members.put("T003", "Approver");
		members.put("T004", "Auditor");
		client.addTeamMembers(token, teamid, members);

		// 启动进程
		String prcid = null;
		try {
			prcid = client.startWorkflow(token, "T001", wftid, teamid,
					"testProcess_2", null);
			assertFalse(prcid.startsWith("ERROR"));

			// 取该进程的内容（JSON格式）
			JSONObject prcJson = client.getPrcInfo(token, prcid);
			assertEquals("running", prcJson.get("STATUS"));
			String thePrcId = (String) prcJson.get("PRCID");
			assertEquals(prcid, thePrcId);

			// 取得worklist, 找到属于该进程的那个work
			JSONArray wlist = client.getWorklist(token, "T001", prcid);
			assertTrue(wlist.size() > 0);
			JSONObject theWii = getWorkitem(wlist, prcid, "id_1");
			assertTrue(theWii != null);

			// 完成这个work
			client.doTask(token, "T001", prcid, (String) theWii.get("NODEID"),
					(String) theWii.get("SESSID"), null, null);

			JSONArray wlist_tmp = client.getWorklist(token, "T003", prcid);
			assertTrue(wlist_tmp.size() > 0);
			JSONObject theWii_tmp = getWorkitem(wlist_tmp, prcid, "id_2");
			assertTrue(theWii_tmp != null);

			client.doTask(token, "T003", (String) theWii_tmp.get("PRCID"),
					(String) theWii_tmp.get("NODEID"),
					(String) theWii_tmp.get("SESSID"), null, null);

			wlist_tmp = client.getWorklist(token, "T004", prcid);
			assertTrue(wlist_tmp.size() > 0);
			theWii_tmp = getWorkitem(wlist_tmp, prcid, "id_3");
			assertTrue(theWii_tmp != null);
			client.doTask(token, "T004", (String) theWii_tmp.get("PRCID"),
					(String) theWii_tmp.get("NODEID"),
					(String) theWii_tmp.get("SESSID"), null, null);

			wlist_tmp = client.getWorklist(token, "T003", prcid);
			assertTrue(wlist_tmp.size() > 0);
			theWii_tmp = getWorkitem(wlist_tmp, prcid, "id_4");
			assertTrue(theWii_tmp != null);
			client.doTask(token, "T003", (String) theWii_tmp.get("PRCID"),
					(String) theWii_tmp.get("NODEID"),
					(String) theWii_tmp.get("SESSID"), null, null);

			wlist = client.getWorklist(token, "T001", prcid);
			assertTrue(wlist.size() > 0);
			theWii = getWorkitem(wlist, prcid, "id_5");
			assertTrue(theWii != null);
			client.doTask(token, "T001", (String) theWii.get("PRCID"),
					(String) theWii.get("NODEID"),
					(String) theWii.get("SESSID"), null, null);

			wlist_tmp = client.getWorklist(token, "T005", prcid);
			assertTrue(wlist_tmp.size() > 0);
			theWii_tmp = getWorkitem(wlist_tmp, prcid, "id_6");
			assertTrue(theWii_tmp != null);
			client.doTask(token, "T005", (String) theWii_tmp.get("PRCID"),
					(String) theWii_tmp.get("NODEID"),
					(String) theWii_tmp.get("SESSID"), null, null);

			// 再次看这个进程的状态，应该是完成状态
			prcJson = client.getPrcInfo(token, prcid);
			assertEquals("finished", prcJson.get("STATUS"));
		} finally {
			if (prcid != null)
				client.deleteProcess(token, prcid);

			client.deleteTeamById(token, teamid);

			client.deleteWft(token, wftid);

			cleanHouse(token);
		}

	}

	// 测试工作流模板中指定活动给特定的角色和reference
	public void test_taskto_differentTeam() throws Exception {
		String token = client.getToken("tester1", "test");
		assertAcsk(token);

		String wft = "<?xml version=\"1.0\" encoding=\"UTF-8\"?><cf:workflow xsi:schemaLocation=\"http://lkh.com/cflow ../schemas/wft.xsd\" name=\"tobedelete\" owner=\"LKH\" acl=\"private\" lastModified=\"2011-03-19T04:18:58\" created=\"2011-03-19T04:18:58\" xmlns:cf=\"http://lkh.com/cflow\" xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\">"
				+ "<node id=\"id_start\" type=\"start\" title=\"Start\" name=\"Start\" x=\"27\" y=\"213\">\n <next targetID=\"id_1\"/></node>"
				+ "<node id=\"id_end\" type=\"end\" title=\"End\" name=\"End\" x=\"738\" y=\"213\">\n <next targetID=\"id_end\"/></node>"
				+ "<node id=\"id_1\" type=\"task\" title=\"Apply Leaving\" name=\"Apply Leaving\" x=\"356\" y=\"203\" acquirable=\"false\" acqThreshold=\"1\" allowRoleChange=\"false\" allowDelegate=\"false\" allowAdhoc=\"false\" roleToChange=\"all\" form=\"\" mpsm=\"1\">\n "
				+ "<taskto type=\"role\" whom=\"Approver\"/>\n"
				+ "<mpcdc/>\n <oec/>\n <next targetID=\"id_end\"/>\n </node>"
				+ "</cf:workflow>";

		String wftid = client.uploadWft(token, wft, "testProcess_2");
		assertTrue(wftid != null);

		// 新建一个Team
		String team1 = client.createTeam(token, "team1", "team1Memo");
		String team2 = client.createTeam(token, "team2", "team2Memo");
		// 指派团队成员
		JSONObject members = new JSONObject();
		members.put("T003", "Approver");
		members.put("T004", "Auditor");
		client.addTeamMembers(token, team1, members);
		members.clear();
		members.put("T002", "Approver");
		client.addTeamMembers(token, team2, members);

		String prcid = null;
		JSONArray wlist = null;
		JSONObject wii = null;
		JSONObject prcJson = null;
		// 启动进程
		try {
			prcid = client.startWorkflow(token, "T001", wftid, team1,
					"testProcess_2", null);
			assertFalse(prcid.startsWith("ERROR"));

			wlist = client.getWorklist(token, "T003", prcid);
			assertTrue(wlist.size() > 0);
			wii = getWorkitem(wlist, prcid, "id_1");
			assertTrue(wii != null);

			// 完成这个work
			client.doTask(token, "T003", prcid, (String) wii.get("NODEID"),
					(String) wii.get("SESSID"), null, null);

			prcJson = client.getPrcInfo(token, prcid);
			assertEquals("finished", prcJson.get("STATUS"));
			if (prcid != null)
				client.deleteProcess(token, prcid);

			//
			//
			// Now, start with another team
			prcid = client.startWorkflow(token, "T001", wftid, team2,
					"testProcess_2", null);
			assertFalse(prcid.startsWith("ERROR"));

			wlist = client.getWorklist(token, "T002", prcid);
			assertTrue(wlist.size() > 0);
			wii = getWorkitem(wlist, prcid, "id_1");
			assertTrue(wii != null);

			client.doTask(token, "T002", prcid, (String) wii.get("NODEID"),
					(String) wii.get("SESSID"), null, null);

			prcJson = client.getPrcInfo(token, prcid);
			assertEquals("finished", prcJson.get("STATUS"));
		} finally {

			if (prcid != null)
				client.deleteProcess(token, prcid);

			client.deleteTeamById(token, team1);
			client.deleteTeamById(token, team2);

			client.deleteWft(token, wftid);

			cleanHouse(token);
		}

	}

	// 测试选择
	public void test_option() throws Exception {
		String token = client.getToken("tester1", "test");
		assertAcsk(token);

		String wft = "<?xml version=\"1.0\" encoding=\"UTF-8\"?><cf:workflow xsi:schemaLocation=\"http://lkh.com/cflow ../schemas/wft.xsd\" name=\"tobedelete\" owner=\"LKH\" acl=\"private\" lastModified=\"2011-03-19T04:18:58\" created=\"2011-03-19T04:18:58\" xmlns:cf=\"http://lkh.com/cflow\" xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\">"
				+ "<node id=\"id_start\" type=\"start\" title=\"Start\" name=\"Start\" x=\"27\" y=\"213\">\n <next targetID=\"id_apply_leaving\"/></node>"
				+ "<node id=\"id_end\" type=\"end\" title=\"End\" name=\"End\" x=\"738\" y=\"213\">\n <next targetID=\"id_end\"/></node>"
				+ "<node id=\"id_apply_leaving\" type=\"task\" title=\"Apply Leaving\" name=\"Apply Leaving\" x=\"356\" y=\"203\" acquirable=\"false\" acqThreshold=\"1\" allowRoleChange=\"false\" allowDelegate=\"false\" allowAdhoc=\"false\" roleToChange=\"all\" form=\"\" mpsm=\"1\">\n <taskto type=\"role\" whom=\"starter\"/>\n <mpcdc/>\n <oec/>\n <next targetID=\"id_approve_leaving\"/>\n </node>"
				+ "<node id=\"id_approve_leaving\" type=\"task\" title=\"Approve Leaving\" name=\"Approve Leaving\" x=\"356\" y=\"203\" acquirable=\"false\" acqThreshold=\"1\" allowRoleChange=\"false\" allowDelegate=\"false\" allowAdhoc=\"false\" roleToChange=\"all\" form=\"\" mpsm=\"1\">\n <taskto type=\"role\" whom=\"Approver\"/>\n <mpcdc/>\n <oec/>\n <next option=\"Approve\" targetID=\"id_approved\"/><next option=\"Reject\" targetID=\"id_rejected\"/>\n </node>"
				+ "<node id=\"id_approved\" type=\"task\" title=\"Approved\" name=\"Approved\" x=\"356\" y=\"203\" acquirable=\"false\" acqThreshold=\"1\" allowRoleChange=\"false\" allowDelegate=\"false\" allowAdhoc=\"false\" roleToChange=\"all\" form=\"\" mpsm=\"1\">\n <taskto type=\"RefertoNode\" whom=\"id_apply_leaving\"/>\n <mpcdc/>\n <oec/>\n <next targetID=\"id_end\"/>\n </node>"
				+ "<node id=\"id_rejected\" type=\"task\" title=\"Rejected\" name=\"Rejected\" x=\"356\" y=\"203\" acquirable=\"false\" acqThreshold=\"1\" allowRoleChange=\"false\" allowDelegate=\"false\" allowAdhoc=\"false\" roleToChange=\"all\" form=\"\" mpsm=\"1\">\n <taskto type=\"RefertoNode\" whom=\"id_apply_leaving\"/>\n <mpcdc/>\n <oec/>\n <next targetID=\"id_end\"/>\n </node>"
				+ "</cf:workflow>";

		String wftid = client.uploadWft(token, wft, "testProcess_3");

		// 新建一个Team
		String teamid = client.createTeam(token, "test_team2",
				"test_team2_memo");
		// 指派团队成员
		JSONObject members = new JSONObject();
		members.put("T002", "Approver");
		members.put("T003", "Auditor");
		client.addTeamMembers(token, teamid, members);
		JSONArray wlist = null;
		// 启动进程
		String prcid = null;
		JSONObject theWii = null;
		JSONObject prcJson = null;
		try {
			prcid = client.startWorkflow(token, "T001", wftid, teamid,
					"testProcess_3", null);
			assertFalse(prcid.startsWith("ERROR"));

			// 取得worklist, 找到属于该进程的那个work
			wlist = client.getWorklist(token, "T001", prcid);
			assertTrue(wlist.size() > 0);
			theWii = getWorkitem(wlist, prcid, "id_apply_leaving");
			assertTrue(theWii != null);

			// 完成这个work
			client.doTask(token, "T001", prcid, (String) theWii.get("NODEID"),
					(String) theWii.get("SESSID"), null, null);

			wlist = client.getWorklist(token, "T002", prcid);
			assertTrue(wlist.size() > 0);
			theWii = getWorkitem(wlist, prcid, "id_approve_leaving");
			assertTrue(theWii != null);

			client.doTask(token, "T002", (String) theWii.get("PRCID"),
					(String) theWii.get("NODEID"),
					(String) theWii.get("SESSID"), "Approve", null);

			wlist = client.getWorklist(token, "T001", prcid);
			assertTrue(wlist.size() > 0);
			theWii = getWorkitem(wlist, prcid, "id_rejected");
			assertTrue(theWii == null);
			theWii = getWorkitem(wlist, prcid, "id_approved");
			assertTrue(theWii != null);
			assertEquals(theWii.get("WORKNAME"), "Approved");
			client.doTask(token, "T001", (String) theWii.get("PRCID"),
					(String) theWii.get("NODEID"),
					(String) theWii.get("SESSID"), null, null);

			// 再次看这个进程的状态，应该是完成状态
			prcJson = client.getPrcInfo(token, prcid);
			assertEquals("finished", prcJson.get("STATUS"));
		} finally {

			// 删除这个新进程
			if (prcid != null)
				client.deleteProcess(token, prcid);
		}

		// 启动进程
		prcid = null;
		try {
			prcid = client.startWorkflow(token, "T001", wftid, teamid,
					"testProcess_3", null);
			assertFalse(prcid.startsWith("ERROR"));

			// 取得worklist, 找到属于该进程的那个work
			wlist = client.getWorklist(token, "T001", prcid);
			assertTrue(wlist.size() > 0);
			theWii = getWorkitem(wlist, prcid, "id_apply_leaving");
			assertTrue(theWii != null);

			// 完成这个work
			client.doTask(token, "T001", prcid, (String) theWii.get("NODEID"),
					(String) theWii.get("SESSID"), null, null);

			// 取T3307的Worklist
			wlist = client.getWorklist(token, "T002", prcid);
			assertTrue(wlist.size() > 0);
			theWii = getWorkitem(wlist, prcid, "id_approve_leaving");
			assertTrue(theWii != null);

			client.doTask(token, "T002", (String) theWii.get("PRCID"),
					(String) theWii.get("NODEID"),
					(String) theWii.get("SESSID"), "Reject", null);

			wlist = client.getWorklist(token, "T001", prcid);
			assertTrue(wlist.size() > 0);
			theWii = getWorkitem(wlist, prcid, "id_approved");
			assertTrue(theWii == null);
			theWii = getWorkitem(wlist, prcid, "id_rejected");
			assertTrue(theWii != null);
			assertEquals(theWii.get("WORKNAME"), "Rejected");
			client.doTask(token, "T001", (String) theWii.get("PRCID"),
					(String) theWii.get("NODEID"),
					(String) theWii.get("SESSID"), null, null);

			// 再次看这个进程的状态，应该是完成状态
			prcJson = client.getPrcInfo(token, prcid);
			assertEquals("finished", prcJson.get("STATUS"));
		} finally {
			// 删除这个新进程
			if (prcid != null)
				client.deleteProcess(token, prcid);

			// 删除前面测试创建的Team
			client.deleteTeamById(token, teamid);

			// 删除这个模板
			client.deleteWft(token, wftid);

			cleanHouse(token);
		}

	}

	// 测试AND_OR
	public void test_andor() throws Exception {
		String token = client.getToken("tester1", "test");
		assertAcsk(token);

		String wft = "<?xml version=\"1.0\" encoding=\"UTF-8\"?><cf:workflow xsi:schemaLocation=\"http://lkh.com/cflow ../schemas/wft.xsd\" name=\"tobedelete\" owner=\"LKH\" acl=\"private\" lastModified=\"2011-03-19T04:18:58\" created=\"2011-03-19T04:18:58\" xmlns:cf=\"http://lkh.com/cflow\" xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\">"
				+ "<node id=\"id_start\" type=\"start\" title=\"Start\" name=\"Start\" x=\"27\" y=\"213\">\n <next targetID=\"id_apply_leaving\"/></node>"
				+ "<node id=\"id_end\" type=\"end\" title=\"End\" name=\"End\" x=\"738\" y=\"213\">\n <next targetID=\"id_end\"/></node>"
				+ "<node id=\"id_apply_leaving\" type=\"task\" title=\"Apply Leaving\" name=\"Apply Leaving\"  acquirable=\"false\" acqThreshold=\"1\" allowRoleChange=\"false\" allowDelegate=\"false\" allowAdhoc=\"false\" roleToChange=\"all\" form=\"\" mpsm=\"1\">\n "
				+ "<taskto type=\"role\" whom=\"starter\"/>\n <mpcdc/>\n <oec/>\n <next targetID=\"id_approve_leaving\"/>\n </node>"
				+ "<node id=\"id_approve_leaving\" type=\"task\" title=\"Approve Leaving\" name=\"Approve Leaving\"  acquirable=\"false\" acqThreshold=\"1\" allowRoleChange=\"false\" allowDelegate=\"false\" allowAdhoc=\"false\" roleToChange=\"all\" form=\"\" mpsm=\"1\">\n "
				+ "<taskto type=\"role\" whom=\"Approver\"/>\n <mpcdc/>\n <oec/>\n <next option=\"Approve\" targetID=\"id_approved\"/><next option=\"Approve\" targetID=\"id_approved2\"/><next option=\"Reject\" targetID=\"id_rejected\"/><next option=\"Reject\" targetID=\"id_rejected2\"/>\n </node>"
				+ "<node id=\"id_approved\" type=\"task\" title=\"Approved\" name=\"Approved\"  acquirable=\"false\" acqThreshold=\"1\" allowRoleChange=\"false\" allowDelegate=\"false\" allowAdhoc=\"false\" roleToChange=\"all\" form=\"\" mpsm=\"1\">\n "
				+ "<taskto type=\"RefertoNode\" whom=\"id_apply_leaving\"/>\n <mpcdc/>\n <oec/>\n <next targetID=\"id_AND\"/>\n </node>"
				+ "<node id=\"id_approved2\" type=\"task\" title=\"Approved2\" name=\"Approved2\"  acquirable=\"false\" acqThreshold=\"1\" allowRoleChange=\"false\" allowDelegate=\"false\" allowAdhoc=\"false\" roleToChange=\"all\" form=\"\" mpsm=\"1\">\n "
				+ "<taskto type=\"RefertoNode\" whom=\"id_approve_leaving\"/>\n <mpcdc/>\n <oec/>\n <next targetID=\"id_AND\"/>\n </node>"
				+ "<node id=\"id_AND\" type=\"and\" ><next targetID=\"id_end\"/></node>\n "
				+ "<node id=\"id_rejected\" type=\"task\" title=\"Rejected\" name=\"Rejected\"  acquirable=\"false\" acqThreshold=\"1\" allowRoleChange=\"false\" allowDelegate=\"false\" allowAdhoc=\"false\" roleToChange=\"all\" form=\"\" mpsm=\"1\">\n "
				+ "<taskto type=\"RefertoNode\" whom=\"id_apply_leaving\"/>\n <mpcdc/>\n <oec/>\n <next targetID=\"id_OR\"/>\n </node>"
				+ "<node id=\"id_rejected2\" type=\"task\" title=\"Rejected2\" name=\"Rejected2\"  acquirable=\"false\" acqThreshold=\"1\" allowRoleChange=\"false\" allowDelegate=\"false\" allowAdhoc=\"false\" roleToChange=\"all\" form=\"\" mpsm=\"1\">\n "
				+ "<taskto type=\"RefertoNode\" whom=\"id_approve_leaving\"/>\n <mpcdc/>\n <oec/>\n <next targetID=\"id_OR\"/>\n </node>"
				+ "<node id=\"id_OR\" type=\"or\" ><next targetID=\"id_end\"/></node>\n "
				+ "</cf:workflow>";

		String wftid = client.uploadWft(token, wft, "testProcess_4");

		// 新建一个Team
		String teamid = client.createTeam(token, "test_team2",
				"test_team2_memo");
		// 指派团队成员
		JSONObject members = new JSONObject();
		members.put("T002", "Approver");
		members.put("T003", "Auditor");
		client.addTeamMembers(token, teamid, members);

		// 启动进程
		String prcid = null;
		JSONArray wlist = null;
		JSONObject wii = null;
		JSONObject prcJson = null;
		try {
			prcid = client.startWorkflow(token, "T001", wftid, teamid,
					"testProcess_4", null);
			assertFalse(prcid.startsWith("ERROR"));

			// id_apply_leaving
			wlist = client.getWorklist(token, "T001", prcid);
			assertTrue(wlist.size() > 0);
			wii = getWorkitem(wlist, prcid, "id_apply_leaving");
			assertTrue(wii != null);
			client.doTask(token, "T001", prcid, (String) wii.get("NODEID"),
					(String) wii.get("SESSID"), null, null);

			wlist = client.getWorklist(token, "T002", prcid);
			assertTrue(wlist.size() > 0);
			wii = getWorkitem(wlist, prcid, "id_approve_leaving");
			assertTrue(wii != null);

			client.doTask(token, "T002", (String) wii.get("PRCID"),
					(String) wii.get("NODEID"), (String) wii.get("SESSID"),
					"Approve", null);

			// id_approved refer to id_apply_leaving
			wlist = client.getWorklist(token, "T001", prcid);
			wii = getWorkitem(wlist, prcid, "id_approved");
			assertTrue(wii != null);
			assertEquals(wii.get("WORKNAME"), "Approved");
			client.doTask(token, "T001", (String) wii.get("PRCID"),
					(String) wii.get("NODEID"), (String) wii.get("SESSID"),
					null, null);

			prcJson = client.getPrcInfo(token, prcid);
			assertEquals("running", prcJson.get("STATUS"));

			// id_approved2 refer to id_approve_leaving
			wlist = client.getWorklist(token, "T002", prcid);
			wii = getWorkitem(wlist, prcid, "id_approved2");
			assertTrue(wii != null);
			assertEquals(wii.get("WORKNAME"), "Approved2");
			client.doTask(token, "T002", (String) wii.get("PRCID"),
					(String) wii.get("NODEID"), (String) wii.get("SESSID"),
					null, null);

			// 再次看这个进程的状态，应该是完成状态
			prcJson = client.getPrcInfo(token, prcid);
			assertEquals("finished", prcJson.get("STATUS"));
		} finally {
			// 删除这个新进程
			if (prcid != null)
				client.deleteProcess(token, prcid);
		}

		prcid = null;
		try {
			// 启动进程
			prcid = client.startWorkflow(token, "T001", wftid, teamid,
					"testProcess_4", null);
			assertFalse(prcid.startsWith("ERROR"));

			wlist = client.getWorklist(token, "T001", prcid);
			wii = getWorkitem(wlist, prcid, "id_apply_leaving");
			assertTrue(wlist.size() > 0);
			assertTrue(wii != null);

			// 完成这个work
			client.doTask(token, "T001", prcid, (String) wii.get("NODEID"),
					(String) wii.get("SESSID"), null, null);

			wlist = client.getWorklist(token, "T002", prcid);
			assertTrue(wlist.size() > 0);
			wii = getWorkitem(wlist, prcid, "id_approve_leaving");
			assertTrue(wii != null);

			client.doTask(token, "T002", (String) wii.get("PRCID"),
					(String) wii.get("NODEID"), (String) wii.get("SESSID"),
					"Reject", null);

			wlist = client.getWorklist(token, "T001");
			wii = getWorkitem(wlist, prcid, "id_rejected");
			assertTrue(wii != null);
			assertEquals(wii.get("WORKNAME"), "Rejected");
			client.doTask(token, "T001", (String) wii.get("PRCID"),
					(String) wii.get("NODEID"), (String) wii.get("SESSID"),
					null, null);

			wlist = client.getWorklist(token, "T002");
			wii = getWorkitem(wlist, prcid, "id_rejected2");
			assertTrue(wii == null);

			// 再次看这个进程的状态，应该是完成状态
			prcJson = client.getPrcInfo(token, prcid);
			assertEquals("finished", prcJson.get("STATUS"));
		} finally {

			if (prcid != null)
				client.deleteProcess(token, prcid);
			client.deleteTeamById(token, teamid);
			client.deleteWft(token, wftid);

			cleanHouse(token);
		}

	}

	// 测试 Option, AND_OR, Variables, Script执行，以及script回写参数值
	// script回写的例子是com.lkh.cflow.test.MyLiner, 通过 java类型的script来调用
	public void test_script() throws Exception {
		String token = client.getToken("tester1", "test");
		assertAcsk(token);

		String wft_script_java = "<?xml version=\"1.0\" encoding=\"UTF-8\"?><cf:workflow xsi:schemaLocation=\"http://lkh.com/cflow ../schemas/wft.xsd\" name=\"tobedelete\" owner=\"LKH\" acl=\"private\" lastModified=\"2011-03-19T04:18:58\" created=\"2011-03-19T04:18:58\" xmlns:cf=\"http://lkh.com/cflow\" xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\">"
				+ "<node id=\"id_start\" type=\"start\" title=\"Start\" name=\"Start\" x=\"27\" y=\"213\">\n <next targetID=\"id_apply_leaving\"/></node>"
				+ "<node id=\"id_end\" type=\"end\" title=\"End\" name=\"End\" x=\"738\" y=\"213\">\n <next targetID=\"id_end\"/></node>"

				+ "<node id=\"id_apply_leaving\" type=\"task\" title=\"Apply Leaving\" name=\"Apply Leaving\"  acquirable=\"false\" acqThreshold=\"1\" allowRoleChange=\"false\" allowDelegate=\"false\" allowAdhoc=\"false\" roleToChange=\"all\" form=\"\" mpsm=\"1\">\n "
				+ "<attachment type=\"int\" label=\"Leave days\" attname=\"days\" value=\"\"/>"
				+ "<attachment type=\"String\" label=\"Leave reason\" attname=\"reason\" value=\"\"/>"
				+ "<taskto type=\"role\" whom=\"starter\"/>\n <mpcdc/>\n <oec/>\n "
				+ "<next targetID=\"id_reason\"/></node>"

				+ "<node id=\"id_reason\" type=\"task\" title=\"Give Reason\" name=\"Give Reason\">"
				+ "<attachment type=\"String\" label=\"Leave reason\" attname=\"reason\" value=\"\"/>"
				+ "<taskto type=\"role\" whom=\"starter\"/>\n <mpcdc/>\n <oec/>\n "
				+ "<next targetID=\"id_script\"/>\n "
				+ "</node>"

				+ "<node id='id_script' type='script'><script>JAVA:com.lkh.cflow.test.MyJavaAdapter</script>"
				+ "<next option='long' targetID='id_long'/>"
				+ "<next option='short' targetID='id_short'/>"
				+ "</node>"

				+ "<node id='id_long' type='task' name='LONG'>"
				+ "<taskto type=\"RefertoNode\" whom=\"id_apply_leaving\"/>"
				+ "<next targetID='id_end'/>"
				+ "</node>"

				+ "<node id='id_short' type='task' name='SHORT'>"
				+ "<taskto type=\"RefertoNode\" whom=\"id_apply_leaving\"/>"
				+ "<next targetID='id_end'/>" + "</node>"

				+ "</cf:workflow>";

		String wft_script_web = "<?xml version=\"1.0\" encoding=\"UTF-8\"?><cf:workflow xsi:schemaLocation=\"http://lkh.com/cflow ../schemas/wft.xsd\" name=\"tobedelete\" owner=\"LKH\" acl=\"private\" lastModified=\"2011-03-19T04:18:58\" created=\"2011-03-19T04:18:58\" xmlns:cf=\"http://lkh.com/cflow\" xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\">"
				+ "<node id=\"id_start\" type=\"start\" title=\"Start\" name=\"Start\" x=\"27\" y=\"213\">\n <next targetID=\"id_apply_leaving\"/></node>"
				+ "<node id=\"id_end\" type=\"end\" title=\"End\" name=\"End\" x=\"738\" y=\"213\">\n <next targetID=\"id_end\"/></node>"

				+ "<node id=\"id_apply_leaving\" type=\"task\" title=\"Apply Leaving\" name=\"Apply Leaving\"  acquirable=\"false\" acqThreshold=\"1\" allowRoleChange=\"false\" allowDelegate=\"false\" allowAdhoc=\"false\" roleToChange=\"all\" form=\"\" mpsm=\"1\">\n "
				+ "<attachment type=\"int\" label=\"Leave days\" attname=\"days\" value=\"\"/>"
				+ "<attachment type=\"String\" label=\"Leave Reason\" attname=\"reason\" value=\"\"/>"
				+ "<taskto type=\"role\" whom=\"starter\"/>\n <mpcdc/>\n <oec/>\n "
				+ "<next targetID=\"id_script\"/>\n "
				+ "</node>"

				+ "<node id='id_script' type='script'><script>URL:http://"
				+ hostname
				+ "/cflow/TestScriptWeb</script>"
				+ "<next option='long' targetID='id_long'/>"
				+ "<next option='short' targetID='id_short'/>"
				+ "</node>"

				+ "<node id='id_long' type='task' name='LONG'>"
				+ "<taskto type=\"RefertoNode\" whom=\"id_apply_leaving\"/>"
				+ "<next targetID='id_end'/>"
				+ "</node>"

				+ "<node id='id_short' type='task' name='SHORT'>"
				+ "<taskto type=\"RefertoNode\" whom=\"id_apply_leaving\"/>"
				+ "<next targetID='id_end'/>" + "</node>"

				+ "</cf:workflow>";
		String wft_script_javascript = "<?xml version=\"1.0\" encoding=\"UTF-8\"?><cf:workflow xsi:schemaLocation=\"http://lkh.com/cflow ../schemas/wft.xsd\" name=\"tobedelete\" owner=\"LKH\" acl=\"private\" lastModified=\"2011-03-19T04:18:58\" created=\"2011-03-19T04:18:58\" xmlns:cf=\"http://lkh.com/cflow\" xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\">"
				+ "<node id=\"id_start\" type=\"start\" title=\"Start\" name=\"Start\" x=\"27\" y=\"213\">\n <next targetID=\"id_apply_leaving\"/></node>"
				+ "<node id=\"id_end\" type=\"end\" title=\"End\" name=\"End\" x=\"738\" y=\"213\">\n <next targetID=\"id_end\"/></node>"

				+ "<node id=\"id_apply_leaving\" type=\"task\" title=\"Apply Leaving\" name=\"Apply Leaving\"  acquirable=\"false\" acqThreshold=\"1\" allowRoleChange=\"false\" allowDelegate=\"false\" allowAdhoc=\"false\" roleToChange=\"all\" form=\"\" mpsm=\"1\">\n "
				+ "<attachment type=\"int\" label=\"Leave days\" attname=\"days\" value=\"\"/>"
				+ "<taskto type=\"role\" whom=\"starter\"/>\n <mpcdc/>\n <oec/>\n "
				+ "<next targetID=\"id_script\"/>\n "
				+ "</node>"

				+ "<node id='id_script' type='script'><script>if(days>10) data.RETURN=\"long\"; else data.RETURN=\"short\"; </script>"
				+ "<next option='long' targetID='id_long'/>"
				+ "<next option='short' targetID='id_short'/>"
				+ "</node>"

				+ "<node id='id_long' type='task' name='LONG'>"
				+ "<taskto type=\"RefertoNode\" whom=\"id_apply_leaving\"/>"
				+ "<next targetID='id_end'/>"
				+ "</node>"

				+ "<node id='id_short' type='task' name='SHORT'>"
				+ "<taskto type=\"RefertoNode\" whom=\"id_apply_leaving\"/>"
				+ "<next targetID='id_end'/>" + "</node>"

				+ "</cf:workflow>";

		String wftid_script_java = client.uploadWft(token, wft_script_java,
				"testProcess_5_script_java");
		String wftid_script_web = client.uploadWft(token, wft_script_web,
				"testProcess_5_script_web");
		String wftid_script_javascript = client.uploadWft(token,
				wft_script_javascript, "testProcess_5_script_JS");

		// 新建一个Team
		String teamid = client.createTeam(token, "test_team2",
				"test_team2_memo");
		// 指派团队成员
		JSONObject members = new JSONObject();
		members.put("T002", "Approver");
		members.put("T003", "Auditor");
		client.addTeamMembers(token, teamid, members);
		JSONObject prcJson = null;
		JSONArray wlist = null;
		JSONObject theWii = null;
		// 启动进程
		String prcid = null;
		try {
			prcid = client.startWorkflow(token, "T001", wftid_script_java,
					teamid, "testProcess_5_inst", null);
			assertFalse(prcid.startsWith("ERROR"));

			// id_apply_leaving
			wlist = client.getWorklist(token, "T001", prcid);
			assertTrue(wlist.size() > 0);
			theWii = getWorkitem(wlist, prcid, "id_apply_leaving");
			assertTrue(theWii != null);
			client.doTask(token, "T001", prcid, (String) theWii.get("NODEID"),
					(String) theWii.get("SESSID"), null,
					"{\"days\":\"11\", \"reason\":\"gohome\", \"var3\":\"value3\"}");

			wlist = client.getWorklist(token, "T001", prcid);
			assertTrue(wlist.size() > 0);
			theWii = getWorkitem(wlist, prcid, "id_reason");
			assertTrue(theWii != null);
			client.doTask(token, "T001", prcid, (String) theWii.get("NODEID"),
					(String) theWii.get("SESSID"), null,
					"{ \"reason\":\"gohome2\"}");

			wlist = client.getWorklist(token, "T001", prcid);
			theWii = getWorkitem(wlist, prcid, "id_long");
			assertTrue(theWii != null);
			assertEquals(theWii.get("WORKNAME"), "LONG");
			client.doTask(token, "T001", (String) theWii.get("PRCID"),
					(String) theWii.get("NODEID"),
					(String) theWii.get("SESSID"), null, null);

			// 再次看这个进程的状态，应该是完成状态
			prcJson = client.getPrcInfo(token, prcid);
			assertEquals("finished", prcJson.get("STATUS"));
		} finally {
			// 删除这个新进程
			if (prcid != null)
				client.deleteProcess(token, prcid);
		}

		prcid = null;
		try {
			// 启动进程
			prcid = client.startWorkflow(token, "T001", wftid_script_java,
					teamid, "testProcess_5", null);
			assertFalse(prcid.startsWith("ERROR"));

			// id_apply_leaving
			wlist = client.getWorklist(token, "T001", prcid);
			assertTrue(wlist.size() > 0);
			theWii = getWorkitem(wlist, prcid, "id_apply_leaving");
			assertTrue(theWii != null);
			client.doTask(token, "T001", prcid, (String) theWii.get("NODEID"),
					(String) theWii.get("SESSID"), null,
					"{\"days\":\"11\", \"reason\":\"gohome\"}");

			wlist = client.getWorklist(token, "T001", prcid);
			assertTrue(wlist.size() > 0);
			theWii = getWorkitem(wlist, prcid, "id_reason");
			assertTrue(theWii != null);

			JSONObject beforeScript = client.getPrcVariables(token, prcid);
			// 下面一个task完成后，将自动调用script活动
			client.doTask(token, "T001", prcid, (String) theWii.get("NODEID"),
					(String) theWii.get("SESSID"), null,
					"{\"days\":\"9\", \"reason\":\"gohome2\"}");
			// Here, the script node will be executed.
			// com.lkh.cflow.test.MyLinker.
			// will write "test value to change back to process attachment" back
			// to
			// “reason”
			JSONObject afterScript = client.getPrcVariables(token, prcid);
			assertTrue(beforeScript.get("reason").equals("gohome"));
			assertTrue(afterScript.get("reason").equals(
					"test value to change back to process attachment."));
			assertTrue(afterScript.get("ignored") != null);

			wlist = client.getWorklist(token, "T001", prcid);
			theWii = getWorkitem(wlist, prcid, "id_short");
			assertTrue(theWii != null);
			assertEquals(theWii.get("WORKNAME"), "SHORT");
			client.doTask(token, "T001", (String) theWii.get("PRCID"),
					(String) theWii.get("NODEID"),
					(String) theWii.get("SESSID"), null, null);

			// 再次看这个进程的状态，应该是完成状态
			prcJson = client.getPrcInfo(token, prcid);
			assertEquals("finished", prcJson.get("STATUS"));
		} finally {
			// 删除这个新进程
			if (prcid != null)
				client.deleteProcess(token, prcid);
		}

		prcid = null;
		try {
			// 启动进程
			prcid = client.startWorkflow(token, "T001", wftid_script_web,
					teamid, "testProcess_5", null);
			assertFalse(prcid.startsWith("ERROR"));

			// id_apply_leaving
			wlist = client.getWorklist(token, "T001", prcid);
			assertTrue(wlist.size() > 0);
			theWii = getWorkitem(wlist, prcid, "id_apply_leaving");
			assertTrue(theWii != null);
			client.doTask(token, "T001", prcid, (String) theWii.get("NODEID"),
					(String) theWii.get("SESSID"), null,
					"{\"days\":\"11\", \"reason\":\"gohome\"}");

			wlist = client.getWorklist(token, "T001", prcid);
			theWii = getWorkitem(wlist, prcid, "id_long");
			assertTrue(theWii != null);
			assertEquals(theWii.get("WORKNAME"), "LONG");
			client.doTask(token, "T001", (String) theWii.get("PRCID"),
					(String) theWii.get("NODEID"),
					(String) theWii.get("SESSID"), null, null);

			// 再次看这个进程的状态，应该是完成状态
			prcJson = client.getPrcInfo(token, prcid);
			assertEquals("finished", prcJson.get("STATUS"));
		} finally {
			// 删除这个新进程
			if (prcid != null)
				client.deleteProcess(token, prcid);
		}
		prcid = null;
		try {

			// 启动进程
			prcid = client.startWorkflow(token, "T001", wftid_script_web,
					teamid, "testProcess_5", null);
			assertFalse(prcid.startsWith("ERROR"));

			// id_apply_leaving
			wlist = client.getWorklist(token, "T001", prcid);
			assertTrue(wlist.size() > 0);
			theWii = getWorkitem(wlist, prcid, "id_apply_leaving");
			assertTrue(theWii != null);
			client.doTask(token, "T001", prcid, (String) theWii.get("NODEID"),
					(String) theWii.get("SESSID"), null,
					"{\"days\":\"6\", \"reason\":\"gohome\"}");

			wlist = client.getWorklist(token, "T001", prcid);
			theWii = getWorkitem(wlist, prcid, "id_short");
			assertTrue(theWii != null);
			assertEquals(theWii.get("WORKNAME"), "SHORT");
			client.doTask(token, "T001", (String) theWii.get("PRCID"),
					(String) theWii.get("NODEID"),
					(String) theWii.get("SESSID"), null, null);

			// 再次看这个进程的状态，应该是完成状态
			prcJson = client.getPrcInfo(token, prcid);
			assertEquals("finished", prcJson.get("STATUS"));
		} finally {
			// 删除这个新进程
			if (prcid != null)
				client.deleteProcess(token, prcid);
		}
		prcid = null;
		try {

			// 启动进程
			prcid = client.startWorkflow(token, "T001",
					wftid_script_javascript, teamid, "testProcess_5", null);
			assertFalse(prcid.startsWith("ERROR"));

			// id_apply_leaving
			wlist = client.getWorklist(token, "T001", prcid);
			assertTrue(wlist.size() > 0);
			theWii = getWorkitem(wlist, prcid, "id_apply_leaving");
			assertTrue(theWii != null);
			client.doTask(token, "T001", prcid, (String) theWii.get("NODEID"),
					(String) theWii.get("SESSID"), null,
					"{\"days\":\"12\", \"reason\":\"gohome\"}");

			wlist = client.getWorklist(token, "T001", prcid);
			theWii = getWorkitem(wlist, prcid, "id_long");
			assertTrue(theWii != null);
			assertEquals(theWii.get("WORKNAME"), "LONG");
			client.doTask(token, "T001", (String) theWii.get("PRCID"),
					(String) theWii.get("NODEID"),
					(String) theWii.get("SESSID"), null, null);

			// 再次看这个进程的状态，应该是完成状态
			prcJson = client.getPrcInfo(token, prcid);
			assertEquals("finished", prcJson.get("STATUS"));
		} finally {
			// 删除这个新进程
			if (prcid != null)
				client.deleteProcess(token, prcid);
		}
		prcid = null;
		try {

			// 启动进程
			prcid = client.startWorkflow(token, "T001",
					wftid_script_javascript, teamid, "testProcess_5", null);
			assertFalse(prcid.startsWith("ERROR"));

			// id_apply_leaving
			wlist = client.getWorklist(token, "T001", prcid);
			assertTrue(wlist.size() > 0);
			theWii = getWorkitem(wlist, prcid, "id_apply_leaving");
			assertTrue(theWii != null);
			client.doTask(token, "T001", prcid, (String) theWii.get("NODEID"),
					(String) theWii.get("SESSID"), null,
					"{\"days\":\"6\", \"reason\":\"gohome\"}");

			wlist = client.getWorklist(token, "T001");
			theWii = getWorkitem(wlist, prcid, "id_short");
			assertTrue(theWii != null);
			assertEquals(theWii.get("WORKNAME"), "SHORT");
			client.doTask(token, "T001", (String) theWii.get("PRCID"),
					(String) theWii.get("NODEID"),
					(String) theWii.get("SESSID"), null, null);

			// 再次看这个进程的状态，应该是完成状态
			prcJson = client.getPrcInfo(token, prcid);
			assertEquals("finished", prcJson.get("STATUS"));
		} finally {
			// 删除这个新进程
			if (prcid != null)
				client.deleteProcess(token, prcid);

			// 删除前面测试创建的Team
			client.deleteTeamById(token, teamid);

			// 删除这个模板
			client.deleteWft(token, wftid_script_java);
			client.deleteWft(token, wftid_script_web);
		}

	}

	public void test_child() throws Exception {
		String token = client.getToken("tester1", "test");
		assertAcsk(token);
		cleanHouse(token);
		String wft_child = null;
		String wftid_child = null;
		String wft_parent_wrong = null;
		String wftid_wrong = null;
		String wftid_right = null;
		String teamid = null;
		String prcid_wrong = null;
		String prcid_right = null;
		String prcid_child = null;
		try {

			// 进程中一个人工活动，一个javascript, 这个JavaScript中返回了RETURN_TO_PARENT,
			// 将影响父进程中的流程走向
			wft_child = "<?xml version=\"1.0\" encoding=\"UTF-8\"?><cf:workflow xsi:schemaLocation=\"http://lkh.com/cflow ../schemas/wft.xsd\" name=\"tobedelete\" owner=\"LKH\" acl=\"private\" lastModified=\"2011-03-19T04:18:58\" created=\"2011-03-19T04:18:58\" xmlns:cf=\"http://lkh.com/cflow\" xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\">"
					+ " <node id=\"id_start\" type=\"start\" title=\"Start\" name=\"Start\" >"
					+ " <next targetID=\"id_1\"/>"
					+ " </node>"
					+ " <node id=\"id_end\" type=\"end\" title=\"End\" name=\"End\" >"
					+ " <next targetID=\"id_end\"/>"
					+ " </node>"
					+ " <node id=\"id_1\" type=\"task\" title=\"Task\" name=\"Task\" acquirable=\"false\" acqThreshold=\"1\" allowRoleChange=\"false\" allowDelegate=\"false\" allowAdhoc=\"false\" roleToChange=\"all\" form=\"\" mpsm=\"1\">"
					+ " <taskto type=\"role\" whom=\"starter\"/>"
					+ " <mpcdc/>"
					+ " <oec/>"
					+ " <next targetID=\"id_script\"/>"
					+ " </node>"
					+ " <node id=\"id_script\" type=\"script\" title=\"Script\" name=\"Script\" >"
					+ " <script>data.RETURN=\"long\"; data.RETURN_TO_PARENT=\"good\";</script>"
					+ " <next targetID=\"id_end\"/>" + " </node>"

					+ "</cf:workflow>";

			wftid_child = client.uploadWft(token, wft_child, "childwft");
			assertTrue(wftid_child != null);

			// 这个父亲工作流，其中的子流程ID编号错误。CFLOW自动根据onerror确定该子流程节点后的流程走向
			wft_parent_wrong = "<?xml version=\"1.0\" encoding=\"UTF-8\"?><cf:workflow xsi:schemaLocation=\"http://lkh.com/cflow ../schemas/wft.xsd\" name=\"tobedelete\" owner=\"LKH\" acl=\"private\" lastModified=\"2011-03-19T04:18:58\" created=\"2011-03-19T04:18:58\" xmlns:cf=\"http://lkh.com/cflow\" xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\">"
					+ "<node id=\"E8D8B454-699A-4050-293A-E0830EEB4B8D\" type=\"start\" title=\"Start\" name=\"Start\" x=\"28\" y=\"228\">"
					+ "<next targetID=\"id_node_script\"/>"
					+ "</node>"
					+ "<node id=\"id_end\" type=\"end\" title=\"End\" name=\"End\" x=\"708\" y=\"228\">"
					+ "<next targetID=\"id_end\"/>"
					+ "</node>"
					+ "<node id=\"id_node_script\" type=\"sub\" title=\"abcd\" name=\"Sub\" x=\"171\" y=\"225\" subWftUID=\""
					+ "WRONGCHILDWFTID"
					+ "\" subWftWG=\"\">"
					+ "<next option=\"good\" targetID=\"id_good\"/>"
					+ "<next option=\"bad\" targetID=\"id_bad\"/>"
					+ "<next option=\"onerror\" targetID=\"id_child_fail\"/>"
					+ "<next option=\"DEFAULT\" targetID=\"id_default\"/>"
					+ "</node>"
					+ "<node id=\"id_good\" type=\"task\" title=\"Task\" name=\"GOOD\" x=\"316\" y=\"164\" acquirable=\"false\" acqThreshold=\"1\" allowRoleChange=\"false\" allowDelegate=\"false\" allowAdhoc=\"false\" roleToChange=\"all\" form=\"\" mpsm=\"1\">"
					+ "<taskto type=\"role\" whom=\"starter\"/>"
					+ "<mpcdc/>"
					+ "<oec/>"
					+ "<next targetID=\"id_end\"/>"
					+ "</node>"
					+ "<node id=\"id_bad\" type=\"task\" title=\"Task\" name=\"BAD\" x=\"327\" y=\"333\" acquirable=\"false\" acqThreshold=\"1\" allowRoleChange=\"false\" allowDelegate=\"false\" allowAdhoc=\"false\" roleToChange=\"all\" form=\"\" mpsm=\"1\">"
					+ "<taskto type=\"role\" whom=\"starter\"/>"
					+ "<mpcdc/>"
					+ "<oec/>"
					+ "<next targetID=\"id_end\"/>"
					+ "</node>"
					+ "<node id=\"id_child_fail\" type=\"task\" title=\"Task\" name=\"child fail\" x=\"327\" y=\"333\" acquirable=\"false\" acqThreshold=\"1\" allowRoleChange=\"false\" allowDelegate=\"false\" allowAdhoc=\"false\" roleToChange=\"all\" form=\"\" mpsm=\"1\">"
					+ "<taskto type=\"role\" whom=\"starter\"/>"
					+ "<mpcdc/>"
					+ "<oec/>"
					+ "<next targetID=\"id_end\"/>"
					+ "</node>"
					+ "<node id=\"id_default\" type=\"task\" title=\"Task\" name=\"DEFAULT\" x=\"327\" y=\"333\" acquirable=\"false\" acqThreshold=\"1\" allowRoleChange=\"false\" allowDelegate=\"false\" allowAdhoc=\"false\" roleToChange=\"all\" form=\"\" mpsm=\"1\">"
					+ "<taskto type=\"role\" whom=\"starter\"/>"
					+ "<mpcdc/>"
					+ "<oec/>"
					+ "<next targetID=\"id_end\"/>"
					+ "</node>"
					+ "</cf:workflow>";

			// 这个流程是一个正确的父流程。因前面子流程RETURN_TO_PARENT=good. 所以，将执行后面的id_good人工活动
			String wft_parent_right = "<?xml version=\"1.0\" encoding=\"UTF-8\"?><cf:workflow xsi:schemaLocation=\"http://lkh.com/cflow ../schemas/wft.xsd\" name=\"tobedelete\" owner=\"LKH\" acl=\"private\" lastModified=\"2011-03-19T04:18:58\" created=\"2011-03-19T04:18:58\" xmlns:cf=\"http://lkh.com/cflow\" xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\">"
					+ "<node id=\"E8D8B454-699A-4050-293A-E0830EEB4B8D\" type=\"start\" title=\"Start\" name=\"Start\" x=\"28\" y=\"228\">"
					+ "<next targetID=\"id_node_script\"/>"
					+ "</node>"
					+ "<node id=\"id_end\" type=\"end\" title=\"End\" name=\"End\" x=\"708\" y=\"228\">"
					+ "<next targetID=\"id_end\"/>"
					+ "</node>"
					+ "<node id=\"id_node_script\" type=\"sub\" title=\"abcd\" name=\"Sub\" x=\"171\" y=\"225\" subWftUID=\""
					+ wftid_child
					+ "\" subWftWG=\"\">"
					+ "<next option=\"good\" targetID=\"id_good\"/>"
					+ "<next option=\"bad\" targetID=\"id_bad\"/>"
					+ "<next option=\"onerror\" targetID=\"id_child_fail\"/>"
					+ "<next option=\"DEFAULT\" targetID=\"id_default\"/>"
					+ "</node>"
					+ "<node id=\"id_good\" type=\"task\" title=\"Task\" name=\"GOOD\" x=\"316\" y=\"164\" acquirable=\"false\" acqThreshold=\"1\" allowRoleChange=\"false\" allowDelegate=\"false\" allowAdhoc=\"false\" roleToChange=\"all\" form=\"\" mpsm=\"1\">"
					+ "<taskto type=\"role\" whom=\"starter\"/>"
					+ "<mpcdc/>"
					+ "<oec/>"
					+ "<next targetID=\"id_end\"/>"
					+ "</node>"
					+ "<node id=\"id_bad\" type=\"task\" title=\"Task\" name=\"BAD\" x=\"327\" y=\"333\" acquirable=\"false\" acqThreshold=\"1\" allowRoleChange=\"false\" allowDelegate=\"false\" allowAdhoc=\"false\" roleToChange=\"all\" form=\"\" mpsm=\"1\">"
					+ "<taskto type=\"role\" whom=\"starter\"/>"
					+ "<mpcdc/>"
					+ "<oec/>"
					+ "<next targetID=\"id_end\"/>"
					+ "</node>"
					+ "<node id=\"id_child_fail\" type=\"task\" title=\"Task\" name=\"child fail\" x=\"327\" y=\"333\" acquirable=\"false\" acqThreshold=\"1\" allowRoleChange=\"false\" allowDelegate=\"false\" allowAdhoc=\"false\" roleToChange=\"all\" form=\"\" mpsm=\"1\">"
					+ "<taskto type=\"role\" whom=\"starter\"/>"
					+ "<mpcdc/>"
					+ "<oec/>"
					+ "<next targetID=\"id_end\"/>"
					+ "</node>"
					+ "<node id=\"id_default\" type=\"task\" title=\"Task\" name=\"DEFAULT\" x=\"327\" y=\"333\" acquirable=\"false\" acqThreshold=\"1\" allowRoleChange=\"false\" allowDelegate=\"false\" allowAdhoc=\"false\" roleToChange=\"all\" form=\"\" mpsm=\"1\">"
					+ "<taskto type=\"role\" whom=\"starter\"/>"
					+ "<mpcdc/>"
					+ "<oec/>"
					+ "<next targetID=\"id_end\"/>"
					+ "</node>"
					+ "</cf:workflow>";

			wftid_wrong = client
					.uploadWft(token, wft_parent_wrong, "parentwft");
			assertTrue(wftid_wrong != null);
			wftid_right = client
					.uploadWft(token, wft_parent_right, "parentwft");
			assertTrue(wftid_right != null);

			// 新建一个Team
			teamid = client.createTeam(token, "test_team2", "test_team2_memo");
			// 指派团队成员
			JSONObject members = new JSONObject();
			members.put("T002", "Approver");
			members.put("T003", "Auditor");
			client.addTeamMembers(token, teamid, members);

			JSONObject wii = null;
			JSONArray wlist = null;
			prcid_wrong = null;
			JSONObject prcJson = null;
			try {
				// 启动进程
				prcid_wrong = client.startWorkflow(token, "T001", wftid_wrong,
						teamid, "testProcess_5_inst", null);
				assertFalse(prcid_wrong.startsWith("ERROR"));

				wlist = client.getWorklist(token, "T001", prcid_wrong);
				assertTrue(wlist.size() > 0);
				wii = getWorkitem(wlist, prcid_wrong, "id_child_fail");
				client.doTask(token, "T001", prcid_wrong,
						(String) wii.get("NODEID"), (String) wii.get("SESSID"),
						null, null);
				// 再次看这个进程的状态，应该是完成状态
				prcJson = client.getPrcInfo(token, prcid_wrong);
				assertEquals("finished", prcJson.get("STATUS"));
			} finally {
				if (prcid_wrong != null)
					client.deleteProcess(token, prcid_wrong);
			}
			//
			//
			//
			//
			//

			// 启动进程
			prcid_right = null;
			try {
				prcid_right = client.startWorkflow(token, "T001", wftid_right,
						teamid, "testProcess_5_inst", null);
				assertFalse(prcid_right.startsWith("ERROR"));
				wlist = client.getWorklist(token, "T001");
				wii = null;
				for (int i = 0; i < wlist.size(); i++) {
					JSONObject tmp = (JSONObject) wlist.get(i);
					if (tmp.get("NODEID").equals("id_1")
							&& tmp.get("PPID").equals(prcid_right)) {
						wii = tmp;
						prcid_child = (String) tmp.get("PRCID");
						break;
					}
				}
				assertTrue(wii != null);
				client.doTask(token, "T001", prcid_child,
						(String) wii.get("NODEID"), (String) wii.get("SESSID"),
						null, null);

				wlist = client.getWorklist(token, "T001", prcid_right);
				assertTrue(wlist.size() > 0);
				wii = getWorkitem(wlist, prcid_right, "id_good");
				assertTrue(wii != null);
				client.doTask(token, "T001", prcid_right,
						(String) wii.get("NODEID"), (String) wii.get("SESSID"),
						null, null);

				// 再次看这个进程的状态，应该是完成状态
				prcJson = client.getPrcInfo(token, prcid_right);
				assertEquals("finished", prcJson.get("STATUS"));
			} finally {
				if (prcid_right != null)
					client.deleteProcess(token, prcid_right);

				if (prcid_child != null)
					client.deleteProcess(token, prcid_child);
			}
		} catch (Exception ex) {
			ex.printStackTrace();
		} finally {

			// 删除前面测试创建的Team
			client.deleteTeamById(token, teamid);

			// 删除这个模板
			client.deleteWft(token, wftid_child);
			client.deleteWft(token, wftid_right);
			client.deleteWft(token, wftid_wrong);

			cleanHouse(token);
		}

	}

	private void assertAcsk(String token) {
		assertFalse(token == null);
	}

	private void cleanHouse(String token) {
		try {

			String[] status = new String[3];
			status[0] = "running";
			status[1] = "finished";
			status[2] = "canceled";
			for (int s = 0; s < 3; s++) {
				JSONArray tmp = client.getProcessesByStatus(token, status[s]);
				for (int i = 0; i < tmp.size(); i++) {
					JSONObject prcInfo = (JSONObject) tmp.get(i);
					String tmpPrcId = (String) prcInfo.get("PRCID");
					String tmpWftId = (String) prcInfo.get("WFTID");
					client.deleteProcess(token, tmpPrcId);
					client.deleteWft(token, tmpWftId);
				}
			}

			JSONArray tmp = client.getWfts(token);
			for (int i = 0; i < tmp.size(); i++) {
				JSONObject info = (JSONObject) tmp.get(i);
				String tmpWftId = (String) info.get("WFTID");
				client.deleteWft(token, tmpWftId);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	private void loadTestUsers(String token) throws Exception {
		client.addUser(token, "T001", "T001", "T001@null.com", "GMT+08:00",
				"zh-CN", "E");
		client.addUser(token, "T002", "T002", "T002@null.com", "GMT+08:00",
				"zh-CN", "E");
		client.addUser(token, "T003", "T003", "T003@null.com", "GMT+08:00",
				"zh-CN", "E");
		client.addUser(token, "T004", "T004", "T004@null.com", "GMT+08:00",
				"zh-CN", "E");
		client.addUser(token, "T005", "T005", "T005@null.com", "GMT+08:00",
				"zh-CN", "E");
	}

	private void unloadTestUsers(String token) throws Exception {
		client.deleteUser(token, "T001");
		client.deleteUser(token, "T002");
		client.deleteUser(token, "T003");
		client.deleteUser(token, "T004");
		client.deleteUser(token, "T005");
	}

	private void inpsToOups(InputStream inps, OutputStream oups) {
		byte[] buffer = new byte[1024];
		int i = 0;
		try {
			while ((i = inps.read(buffer)) != -1) {
				oups.write(buffer, 0, i);
			}// end while
		} catch (Exception ex) {
			logger.error(ex.getLocalizedMessage());
		} finally {
			try {
				inps.close();
				oups.flush();
				oups.close();
			} catch (IOException ex) {
				logger.error(ex.getLocalizedMessage());
				ex.printStackTrace();
			}
		}
	}

	private JSONObject getWorkitem(JSONArray wlist, String prcId, String nodeId) {
		JSONObject wii = null;
		for (int i = 0; i < wlist.size(); i++) {
			JSONObject tmp = (JSONObject) wlist.get(i);
			if (tmp.get("PRCID").equals(prcId)
					&& tmp.get("NODEID").equals(nodeId)) {
				wii = tmp;
				break;
			}
		}
		return wii;
	}

}
