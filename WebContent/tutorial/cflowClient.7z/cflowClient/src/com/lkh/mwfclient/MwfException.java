package com.lkh.mwfclient;

public class MwfException extends Exception {

	public MwfException(String msg) {
		super(msg);
	}

}
