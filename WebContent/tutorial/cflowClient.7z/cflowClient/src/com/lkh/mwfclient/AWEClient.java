package com.lkh.mwfclient;

import java.net.URI;
import java.util.ArrayList;
import java.util.List;

import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.NameValuePair;
import org.apache.http.client.HttpClient;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.HttpDelete;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.client.methods.HttpPut;
import org.apache.http.client.utils.URIBuilder;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.message.BasicNameValuePair;
import org.apache.http.protocol.BasicHttpContext;
import org.apache.http.protocol.HttpContext;
import org.apache.http.util.EntityUtils;
import org.apache.log4j.Logger;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;

/**
 * AWEClient is a MWF Restful API wrapper class. AWEClient use <a
 * href="http://hc.apache.org/">Apache HttpComponents</a> to invoke http request
 * to MWF Server.
 * 
 * @author Nean
 * 
 * @version 0.9
 * 
 */
public class AWEClient {
	private static Logger logger = Logger.getLogger(AWEClient.class);
	private HttpClient httpclient = new DefaultHttpClient();
	private HttpContext localContext = new BasicHttpContext();
	private String hostname = "localhost";
	private JSONParser parser = new JSONParser();

	/**
	 * Initiate a AWEClient instance.
	 * 
	 * @param hostname
	 *            The hostname of MWF server, for example, "www.myworldflow.com"
	 * @return a AWEClient instance
	 */
	public static AWEClient newClient(String hostname) {
		AWEClient ret = new AWEClient();
		ret.setHost(hostname);

		return ret;
	}

	/**
	 * Set the hostname of MWF server
	 * 
	 * @param hostname
	 *            the hostname of IP of MWF server
	 */
	public void setHost(String hostname) {
		this.hostname = hostname;
	}

	/**
	 * Delete a workflow template on MWF server
	 * 
	 * @param token
	 *            current access session key
	 * @param wftid
	 *            the id of workflow template to be deleted.
	 * @return true if deleted successfully.
	 * @throws Exception
	 */
	public String deleteWft(String token, String wftId) throws Exception {
		URIBuilder builder = new URIBuilder();
		builder.setScheme("http").setHost(hostname).setPath("/cflow/rest/wft")
				.setParameter("wftid", wftId).setParameter("token", token);
		String ret = myDelete(builder.build());
		if (ret.startsWith("ERROR")) {
			logger.error(ret);
			ret = null;
			throw new MwfException(ret);
		}
		return ret;
	}

	/**
	 * Delete a process (workflow instance) by id
	 * 
	 * @param token
	 *            current token
	 * @param prcId
	 *            the id of process to be deleted
	 * @return true if deleted successfully
	 * @throws Exception
	 */
	public String deleteProcess(String token, String prcId) throws Exception {
		URIBuilder builder = new URIBuilder();
		builder.setScheme("http").setHost(hostname)
				.setPath("/cflow/rest/process").setParameter("prcid", prcId)
				.setParameter("token", token);
		String ret = myDelete(builder.build());
		if (ret.startsWith("ERROR")) {
			logger.error(ret);
			ret = null;
			throw new MwfException(ret);
		}

		return ret;

	}

	/**
	 * Do a task. When a task is done, MWF will drive the process to move
	 * forward.
	 * 
	 * @param token
	 *            current token.
	 * @param prcId
	 *            the id of the process which the task belong to.
	 * @param nodeId
	 *            the nodeId of the current task, which is the id of it's
	 *            corresponding workflow node.
	 * @param sessId
	 *            the sessId of current task
	 * @param option
	 *            the option value you provided.
	 * @param attachments
	 *            the attachments to this task.
	 * @return the sessId of next task if the current task is done successfully.
	 * @throws Exception
	 */
	public String doTask(String token, String actor, String prcId,
			String nodeId, String sessId, String option, String attachments)
			throws Exception {
		if (option == null)
			option = "DEFAULT";
		List<NameValuePair> formparams = new ArrayList<NameValuePair>();
		formparams.add(new BasicNameValuePair("actor", actor));
		formparams.add(new BasicNameValuePair("prcid", prcId));
		formparams.add(new BasicNameValuePair("nodeid", nodeId));
		formparams.add(new BasicNameValuePair("sessid", sessId));
		formparams.add(new BasicNameValuePair("option", option));
		formparams.add(new BasicNameValuePair("token", token));
		if (attachments != null)
			formparams.add(new BasicNameValuePair("attachments", attachments));

		URIBuilder builder = new URIBuilder();
		builder.setScheme("http").setHost(hostname).setPath("/cflow/rest/task");
		String ret = myPost(builder.build(), formparams);
		if (ret.startsWith("ERROR")) {
			logger.error(ret);
			throw new MwfException(ret);
		}

		return ret;
	}

	/**
	 * Login and get token to MWF
	 * 
	 * @param devid
	 *            developer access id
	 * @param accesskey
	 *            developer access key
	 * @return the token. Token must be provided for following API calls to
	 *         interact with MWF server. Token is expired in 30 minutes.
	 * @throws Exception
	 */
	public String getToken(String devid, String accesskey) throws Exception {

		List<NameValuePair> formparams = new ArrayList<NameValuePair>();
		formparams.add(new BasicNameValuePair("devid", devid));
		formparams.add(new BasicNameValuePair("acsk", accesskey));

		URIBuilder builder = new URIBuilder();
		builder.setScheme("http").setHost(hostname)
				.setPath("/cflow/rest/dev/login");
		String ret = myPost(builder.build(), formparams);
		if (ret.startsWith("ERROR")) {
			logger.error(ret);
			ret = null;
			throw new MwfException(ret);
		}

		return ret;

	}

	public String releaseToken(String tokenString) throws Exception {

		URIBuilder builder = new URIBuilder();
		builder.setScheme("http").setHost(hostname)
				.setPath("/cflow/rest/dev/logout")
				.setParameter("token", tokenString);
		String ret = myGet(builder.build());
		if (ret.startsWith("ERROR")) {
			logger.error(ret);
			throw new MwfException(ret);
		} else
			return ret;

	}

	/**
	 * Get user's profile by identity
	 * 
	 * @param tokenString
	 * @return a JSONObject represents user profile attributes.
	 * @see MWF Restful API
	 * @throws Exception
	 */
	public JSONObject getUserInfo(String tokenString, String identity)
			throws Exception {
		URIBuilder builder = new URIBuilder();
		builder.setScheme("http").setHost(hostname).setPath("/cflow/rest/user")
				.setParameter("token", tokenString)
				.setParameter("identity", identity);
		String ret = myGet(builder.build());
		if (ret.startsWith("ERROR")) {
			logger.error(ret);
			throw new MwfException(ret);
		} else
			return (JSONObject) parser.parse(ret);
	}

	public JSONArray getAllUsers(String tokenString) throws Exception {
		URIBuilder builder = new URIBuilder();
		builder.setScheme("http").setHost(hostname)
				.setPath("/cflow/rest/user/all")
				.setParameter("token", tokenString);
		String ret = myGet(builder.build());
		if (ret.startsWith("ERROR")) {
			logger.error(ret);
			throw new MwfException(ret);
		} else
			return (JSONArray) parser.parse(ret);
	}

	public JSONObject getTask(String tokenString, String tid) throws Exception {
		URIBuilder builder = new URIBuilder();
		builder.setScheme("http").setHost(hostname).setPath("/cflow/rest/task")
				.setParameter("token", tokenString).setParameter("tid", tid);
		String ret = myGet(builder.build());
		if (ret.startsWith("ERROR")) {
			logger.error(ret);
			throw new MwfException(ret);
		} else
			return (JSONObject) parser.parse(ret);
	}

	/**
	 * Add an user
	 * 
	 * @param tokenString
	 * @param userid
	 * @param username
	 * @param email
	 * @param tzid
	 * @param lang
	 * @return
	 * @throws Exception
	 */
	public String addUser(String tokenString, String identity, String username,
			String email, String tzid, String lang, String notify)
			throws Exception {

		List<NameValuePair> formparams = new ArrayList<NameValuePair>();
		formparams.add(new BasicNameValuePair("identity", identity));
		formparams.add(new BasicNameValuePair("username", username));
		formparams.add(new BasicNameValuePair("email", email));
		formparams.add(new BasicNameValuePair("tzid", tzid));
		formparams.add(new BasicNameValuePair("lang", lang));
		formparams.add(new BasicNameValuePair("notify", notify));
		formparams.add(new BasicNameValuePair("token", tokenString));

		URIBuilder builder = new URIBuilder();
		builder.setScheme("http").setHost(hostname)
				.setPath("/cflow/rest/user/new");
		return myPost(builder.build(), formparams);
	}

	public String updateUser(String tokenString, String identity,
			String username, String email, String tzid, String lang,
			String notify) throws Exception {

		List<NameValuePair> formparams = new ArrayList<NameValuePair>();
		formparams.add(new BasicNameValuePair("identity", identity));
		formparams.add(new BasicNameValuePair("username", username));
		formparams.add(new BasicNameValuePair("email", email));
		formparams.add(new BasicNameValuePair("tzid", tzid));
		formparams.add(new BasicNameValuePair("lang", lang));
		formparams.add(new BasicNameValuePair("notify", notify));
		formparams.add(new BasicNameValuePair("token", tokenString));

		URIBuilder builder = new URIBuilder();
		builder.setScheme("http").setHost(hostname)
				.setPath("/cflow/rest/user/update");
		return myPutForm(builder.build(), formparams);
	}

	/**
	 * Delete a user
	 * 
	 * @param tokenString
	 * @param userid
	 * @return
	 * @throws Exception
	 */
	public String deleteUser(String tokenString, String identity)
			throws Exception {
		URIBuilder builder = new URIBuilder();
		builder.setScheme("http").setHost(hostname).setPath("/cflow/rest/user")
				.setParameter("identity", identity)
				.setParameter("token", tokenString);
		return myDelete(builder.build());
	}

	/**
	 * Get a user's work list.
	 * 
	 * @param tokenString
	 *            current token
	 * @return a JSONArray contains all works assigned to the user.
	 * @throws Exception
	 */
	public synchronized JSONArray getWorklist(String tokenString, String doer)
			throws Exception {
		JSONArray retObj = null;
		URIBuilder builder = new URIBuilder();
		builder.setScheme("http").setHost(hostname)
				.setPath("/cflow/rest/worklist").setParameter("doer", doer)
				.setParameter("token", tokenString);
		String ret = myGet(builder.build());
		if (ret.startsWith("ERROR")) {
			logger.error(ret);
			throw new MwfException(ret);
		} else {
			try {
				retObj = (JSONArray) parser.parse(ret);
			} catch (Exception ex) {
				System.out.println(ret);
				ex.printStackTrace();
				retObj = null;
			}
		}
		return retObj;
	}

	public synchronized JSONArray getWorklist(String tokenString, String doer,
			String prcId) throws Exception {
		JSONArray retObj = null;
		URIBuilder builder = new URIBuilder();
		builder.setScheme("http").setHost(hostname)
				.setPath("/cflow/rest/worklist").setParameter("doer", doer)
				.setParameter("prcid", prcId)
				.setParameter("token", tokenString);
		String ret = myGet(builder.build());
		if (ret.startsWith("ERROR")) {
			logger.error(ret);
			retObj = null;
			throw new MwfException(ret);
		} else {
			retObj = (JSONArray) parser.parse(ret);
		}

		return retObj;
	}

	/**
	 * Upload a workflow template XML to MWF server
	 * 
	 * @param tokenString
	 * @param wft
	 *            the content of template XML
	 * @param wftname
	 *            the name of this template
	 * @return the id of newly created workflow template.
	 * @throws Exception
	 */
	public String uploadWft(String tokenString, String wft, String wftname)
			throws Exception {
		String ret = null;

		List<NameValuePair> formparams = new ArrayList<NameValuePair>();
		formparams.add(new BasicNameValuePair("wft", wft));
		formparams.add(new BasicNameValuePair("wftname", wftname));
		formparams.add(new BasicNameValuePair("token", tokenString));

		URIBuilder builder = new URIBuilder();
		builder.setScheme("http").setHost(hostname).setPath("/cflow/rest/wft");
		ret = myPost(builder.build(), formparams);
		if (ret.startsWith("ERROR")) {
			logger.error(ret);
			throw new MwfException(ret);
		}

		return ret;

	}

	/**
	 * Get content of a workflow template
	 * 
	 * @param tokenString
	 * @param wftId
	 *            the id of workflow template
	 * @return the content of the workflow template
	 * @throws Exception
	 */
	public String getWftDoc(String tokenString, String wftId) throws Exception {
		URIBuilder builder = new URIBuilder();
		builder.setScheme("http").setHost(hostname)
				.setPath("/cflow/rest/wft/doc").setParameter("wftid", wftId)
				.setParameter("token", tokenString);
		String ret = myGet(builder.build());
		if (ret.startsWith("ERROR")) {
			logger.error(ret);
			throw new MwfException(ret);
		} else
			return ret;
	}

	/**
	 * Start a workflow. The corresponding process will be created
	 * 
	 * @param tokenString
	 *            current token
	 * @param startBy
	 *            the id of the starter
	 * @param wftId
	 *            the id of tempalte
	 * @param teamId
	 *            the id of team members of which will participate in the
	 *            process.
	 * @param instanceName
	 *            give the newly created process a instance name
	 * @return the id of the newly created process
	 * @throws Exception
	 */
	public String startWorkflow(String tokenString, String startBy,
			String wftId, String teamId, String instanceName, JSONObject ctx)
			throws Exception {
		List<NameValuePair> formparams = new ArrayList<NameValuePair>();
		formparams.add(new BasicNameValuePair("wftid", wftId));
		if (teamId != null && teamId.trim().length() > 0)
			formparams.add(new BasicNameValuePair("teamid", teamId));
		formparams.add(new BasicNameValuePair("instancename", instanceName));
		formparams.add(new BasicNameValuePair("startby", startBy));
		formparams.add(new BasicNameValuePair("token", tokenString));
		if (ctx != null) {
			formparams.add(new BasicNameValuePair("ctx", ctx.toString()));
		}

		URIBuilder builder = new URIBuilder();
		builder.setScheme("http").setHost(hostname)
				.setPath("/cflow/rest/process");
		String ret = myPost(builder.build(), formparams);
		if (ret.startsWith("ERROR")) {
			logger.error(ret);
			throw new MwfException(ret);
		} else {
			return ret;
		}

	}

	public String startWorkflowByName(String tokenString, String startBy,
			String wftName, String teamName, String instanceName, JSONObject ctx)
			throws Exception {
		List<NameValuePair> formparams = new ArrayList<NameValuePair>();
		formparams.add(new BasicNameValuePair("wftname", wftName));
		formparams.add(new BasicNameValuePair("teamname", teamName));
		formparams.add(new BasicNameValuePair("instancename", instanceName));
		formparams.add(new BasicNameValuePair("startby", startBy));
		formparams.add(new BasicNameValuePair("token", tokenString));
		if (ctx != null) {
			formparams.add(new BasicNameValuePair("ctx", ctx.toString()));
		}

		URIBuilder builder = new URIBuilder();
		builder.setScheme("http").setHost(hostname)
				.setPath("/cflow/rest/process/byname");
		String ret = myPost(builder.build(), formparams);
		if (ret.startsWith("ERROR")) {
			logger.error(ret);
			throw new MwfException(ret);
		} else {
			return ret;
		}

	}

	/**
	 * Get contextual variables and their values of a process
	 * 
	 * @param tokenString
	 *            current token
	 * @param prcId
	 *            the id of the process
	 * @return a JSONObject contains all process contextual varialbes and their
	 *         values.
	 * @see MWF Restful API
	 * @throws Exception
	 * 
	 */
	public JSONObject getPrcVariables(String tokenString, String prcId)
			throws Exception {
		URIBuilder builder = new URIBuilder();
		builder.setScheme("http").setHost(hostname)
				.setPath("/cflow/rest/process/variables")
				.setParameter("prcid", prcId)
				.setParameter("token", tokenString);
		String ret = myGet(builder.build());
		if (ret.startsWith("ERROR")) {
			logger.error(ret);
			throw new MwfException(ret);
		} else
			return (JSONObject) parser.parse(ret);
	}

	/**
	 * Create a team
	 * 
	 * @param tokenString
	 *            current token
	 * @param teamName
	 *            the name
	 * @param teamMemo
	 *            the memo
	 * @return the id of newly created team
	 * @throws Exception
	 */
	public String createTeam(String tokenString, String teamName,
			String teamMemo) throws Exception {
		List<NameValuePair> formparams = new ArrayList<NameValuePair>();
		formparams.add(new BasicNameValuePair("teamname", teamName));
		formparams.add(new BasicNameValuePair("memo", teamMemo));
		formparams.add(new BasicNameValuePair("token", tokenString));

		URIBuilder builder = new URIBuilder();
		builder.setScheme("http").setHost(hostname).setPath("/cflow/rest/team");
		return myPost(builder.build(), formparams);
	}

	/**
	 * Add multiple members to a team
	 * 
	 * @param tokenString
	 *            current token
	 * @param teamId
	 *            the id of the team
	 * @param memberships
	 *            memberships description in JSON format. For example;
	 *            {"USER_ID1":"USER_ROLE1", "USER_ID2":"USER_ROLE2"} It's better
	 *            to construct a JSONObject like this:<BR>
	 *            JSONObject members = new JSONObject(); <BR>
	 *            members.put("U3307", "Approver"); <BR>
	 *            members.put("U3308", "Auditor");
	 *            client.addTeamMembers(tokenString, teamId,
	 *            members.toString());
	 * @return
	 * @throws Exception
	 */
	public String addTeamMembers(String tokenString, String teamId,
			String memberships) throws Exception {
		List<NameValuePair> formparams = new ArrayList<NameValuePair>();
		formparams.add(new BasicNameValuePair("teamid", teamId));
		formparams.add(new BasicNameValuePair("memberships", memberships));
		formparams.add(new BasicNameValuePair("token", tokenString));

		URIBuilder builder = new URIBuilder();
		builder.setScheme("http").setHost(hostname)
				.setPath("/cflow/rest/team/members");
		String ret = myPost(builder.build(), formparams);
		if (ret.startsWith("ERROR")) {
			logger.error(ret);
			throw new MwfException(ret);
		} else {
			return ret;
		}
	}

	public String addTeamMembers(String tokenString, String teamId,
			JSONObject membershipsObject) throws Exception {
		List<NameValuePair> formparams = new ArrayList<NameValuePair>();
		formparams.add(new BasicNameValuePair("teamid", teamId));
		formparams.add(new BasicNameValuePair("memberships", membershipsObject
				.toString()));
		formparams.add(new BasicNameValuePair("token", tokenString));

		URIBuilder builder = new URIBuilder();
		builder.setScheme("http").setHost(hostname)
				.setPath("/cflow/rest/team/members");
		String ret = myPost(builder.build(), formparams);
		if (ret.startsWith("ERROR")) {
			logger.error(ret);
			throw new MwfException(ret);
		} else {
			return ret;
		}
	}

	public JSONArray getTeamMembers(String tokenString, String teamId)
			throws Exception {
		URIBuilder builder = new URIBuilder();
		builder.setScheme("http").setHost(hostname)
				.setPath("/cflow/rest/team/members")
				.setParameter("token", tokenString)
				.setParameter("teamid", teamId);
		String ret = myGet(builder.build());
		if (ret.startsWith("ERROR")) {
			logger.error(ret);
			throw new MwfException(ret);
		} else
			return (JSONArray) parser.parse(ret);
	}

	public JSONArray getTeamMembersByRole(String tokenString, String teamId,
			String role) throws Exception {
		URIBuilder builder = new URIBuilder();
		builder.setScheme("http").setHost(hostname)
				.setPath("/cflow/rest/team/membersbyrole")
				.setParameter("token", tokenString)
				.setParameter("teamid", teamId).setParameter("role", role);
		String ret = myGet(builder.build());
		if (ret.startsWith("ERROR")) {
			logger.error(ret);
			throw new MwfException(ret);
		} else
			return (JSONArray) parser.parse(ret);
	}

	public String removeTeamMember(String tokenString, String teamId,
			String memberId) throws Exception {
		URIBuilder builder = new URIBuilder();
		builder.setScheme("http").setHost(hostname)
				.setPath("/cflow/rest/team/member")
				.setParameter("teamid", teamId)
				.setParameter("memberid", memberId)
				.setParameter("token", tokenString);
		String ret = myDelete(builder.build());
		if (ret.startsWith("ERROR")) {
			logger.error(ret);
			throw new MwfException(ret);
		} else
			return ret;
	}

	/**
	 * Delete a team from WMF server by it's id
	 * 
	 * @param tokenString
	 *            current token
	 * @param teamId
	 *            id of the team to be deleted
	 * @return true if success
	 * @throws Exception
	 */
	public String deleteTeamById(String tokenString, String teamId)
			throws Exception {
		URIBuilder builder = new URIBuilder();
		builder.setScheme("http").setHost(hostname).setPath("/cflow/rest/team")
				.setParameter("teamid", teamId)
				.setParameter("token", tokenString);
		String ret = myDelete(builder.build());
		if (ret.startsWith("ERROR")) {
			logger.error(ret);
			throw new MwfException(ret);
		} else
			return ret;
	}

	/**
	 * Get all teams of a user
	 * 
	 * @param tokenString
	 *            current token.
	 * @return a JSONArray contains user's teams
	 * @see MWF Restful API
	 * @throws Exception
	 */
	public JSONArray getTeams(String tokenString) throws Exception {
		URIBuilder builder = new URIBuilder();
		builder.setScheme("http").setHost(hostname)
				.setPath("/cflow/rest/team/all")
				.setParameter("token", tokenString);
		String ret = myGet(builder.build());
		if (ret.startsWith("ERROR")) {
			logger.error(ret);
			throw new MwfException(ret);
		} else
			return (JSONArray) parser.parse(ret);
	}

	/**
	 * Get team information by it's id
	 * 
	 * @param tokenString
	 * @param teamName
	 *            the name of the team
	 * @return return a JSONObject describe the team
	 * @throws Exception
	 */
	public JSONObject getTeamByName(String tokenString, String teamName)
			throws Exception {
		URIBuilder builder = new URIBuilder();
		builder.setScheme("http").setHost(hostname)
				.setPath("/cflow/rest/team/byname")
				.setParameter("teamname", teamName)
				.setParameter("token", tokenString);
		String ret = myGet(builder.build());
		if (ret.startsWith("ERROR")) {
			logger.error(ret);
			throw new MwfException(ret);
		} else
			return (JSONObject) parser.parse(ret);
	}

	public JSONObject getTeamById(String tokenString, String teamId)
			throws Exception {
		URIBuilder builder = new URIBuilder();
		builder.setScheme("http").setHost(hostname)
				.setPath("/cflow/rest/team/byid")
				.setParameter("teamid", teamId)
				.setParameter("token", tokenString);
		String ret = myGet(builder.build());
		if (ret.startsWith("ERROR")) {
			logger.error(ret);
			throw new MwfException(ret);
		} else
			return (JSONObject) parser.parse(ret);
	}

	/**
	 * Get the context value of a process
	 * 
	 * @param tokenString
	 *            current token
	 * @param prcId
	 *            id of the process
	 * @return a JSONObject represent the context value.
	 * @throws Exception
	 */
	public JSONObject getPrcInfo(String tokenString, String prcId)
			throws Exception {
		URIBuilder builder = new URIBuilder();
		builder.setScheme("http").setHost(hostname)
				.setPath("/cflow/rest/process").setParameter("prcid", prcId)
				.setParameter("token", tokenString);
		String ret = myGet(builder.build());
		if (ret.startsWith("ERROR")) {
			logger.error(ret);
			throw new MwfException(ret);
		} else
			try {
				return (JSONObject) parser.parse(ret);
			} catch (Exception ex) {
				System.out.println(ret);
				return null;
			}
	}

	/**
	 * Get processes by status
	 * 
	 * @param tokenString
	 *            current token
	 * @param status
	 *            process status, should be one of "running", "suspended",
	 *            "finished", "canceled"
	 * @return a JSONArray of processes.
	 * @throws Exception
	 */
	public JSONArray getProcessesByStatus(String tokenString, String status)
			throws Exception {
		URIBuilder builder = new URIBuilder();
		builder.setScheme("http").setHost(hostname)
				.setPath("/cflow/rest/process/all")
				.setParameter("status", status)
				.setParameter("token", tokenString);
		String ret = myGet(builder.build());
		if (ret.startsWith("ERROR")) {
			logger.error(ret);
			throw new MwfException(ret);
		} else
			return (JSONArray) parser.parse(ret);
	}

	/**
	 * Get workflow templates user can use
	 * 
	 * @param tokenString
	 *            current token
	 * @return a JSONArray of workflow templates information
	 * @throws Exception
	 */
	public JSONArray getWfts(String tokenString) throws Exception {
		URIBuilder builder = new URIBuilder();
		builder.setScheme("http").setHost(hostname)
				.setPath("/cflow/rest/wft/all")
				.setParameter("token", tokenString);
		String ret = myGet(builder.build());
		if (ret.startsWith("ERROR")) {
			logger.error(ret);
			throw new MwfException(ret);
		} else
			return (JSONArray) parser.parse(ret);
	}

	/**
	 * Get workflow info
	 * 
	 * @param tokenString
	 *            current token
	 * @return a JSONArray of workflow templates information
	 * @throws Exception
	 */
	public JSONObject getWftInfo(String tokenString, String wftId)
			throws Exception {
		URIBuilder builder = new URIBuilder();
		builder.setScheme("http").setHost(hostname).setPath("/cflow/rest/wft")
				.setParameter("token", tokenString)
				.setParameter("wftid", wftId);
		String ret = myGet(builder.build());
		if (ret.startsWith("ERROR")) {
			logger.error(ret);
			throw new MwfException(ret);
		} else
			return (JSONObject) parser.parse(ret);
	}

	public String getWftExample(String tokenString, String modelId)
			throws Exception {
		URIBuilder builder = new URIBuilder();
		builder.setScheme("http").setHost(hostname)
				.setPath("/cflow/rest/wft/example")
				.setParameter("token", tokenString)
				.setParameter("modelid", modelId);
		String ret = myGet(builder.build());
		if (ret.startsWith("ERROR")) {
			logger.error(ret);
			throw new MwfException(ret);
		} else
			return ret;
	}

	/**
	 * Suspend a process
	 * 
	 * @param tokenString
	 *            current token
	 * @param prcId
	 *            id of the process to be suspended
	 * @return
	 * @throws Exception
	 */
	public String suspendProcess(String tokenString, String prcId)
			throws Exception {
		return _changeProcessStatus(tokenString, prcId, "suspendProcess");
	}

	/**
	 * Resume a process
	 * 
	 * @param tokenString
	 *            current token
	 * @param prcId
	 *            id of the process to be resumed
	 * @return
	 * @throws Exception
	 */
	public String resumeProcess(String tokenString, String prcId)
			throws Exception {
		return _changeProcessStatus(tokenString, prcId, "resumeProcess");
	}

	/**
	 * Suspend a work
	 * 
	 * @param tokenString
	 *            current token
	 * @param prcId
	 *            id of the process this work belongs to
	 * @param nodeId
	 *            id of the node to be suspended
	 * @return
	 * @throws Exception
	 */
	public String suspendWork(String tokenString, String prcId, String nodeId)
			throws Exception {
		return _changeWorkStatus(tokenString, prcId, nodeId, "suspendWork");
	}

	/**
	 * Resume a work
	 * 
	 * @param tokenString
	 *            current token
	 * @param prcId
	 *            id of the process this work belongs to
	 * @param nodeId
	 *            id of the node to be resumed
	 * @return
	 * @throws Exception
	 */
	public String resumeWork(String tokenString, String prcId, String nodeId)
			throws Exception {
		return _changeWorkStatus(tokenString, prcId, nodeId, "resumeWork");
	}

	/**
	 * @param tokenString
	 * @param prcId
	 * @param action
	 * @return
	 * @throws Exception
	 */
	private String _changeProcessStatus(String tokenString, String prcId,
			String action) throws Exception {
		URIBuilder builder = new URIBuilder();
		builder.setScheme("http").setHost(hostname)
				.setPath("/cflow/rest/process/status")
				.setParameter("prcid", prcId).setParameter("action", action)
				.setParameter("token", tokenString);
		String ret = myPut(builder.build());
		if (ret.startsWith("ERROR")) {
			logger.error(ret);
			throw new MwfException(ret);
		}

		return ret;
	}

	/**
	 * @param tokenString
	 * @param prcId
	 * @param nodeId
	 * @param action
	 * @return
	 * @throws Exception
	 */
	private String _changeWorkStatus(String tokenString, String prcId,
			String nodeId, String action) throws Exception {
		URIBuilder builder = new URIBuilder();
		builder.setScheme("http").setHost(hostname)
				.setPath("/cflow/rest/process/status")
				.setParameter("prcid", prcId).setParameter("nodeid", nodeId)
				.setParameter("action", action)
				.setParameter("token", tokenString);
		return myPut(builder.build());
	}

	/**
	 * Delete a task from delegater to delegatee
	 * 
	 * @param tokenString
	 *            current token
	 * @param prcId
	 *            process id
	 * @param sessId
	 *            sessId of the task
	 * @param delegater
	 *            delegate from delegater
	 * @param delegatee
	 *            delegate to delegatee
	 * @return
	 * @throws Exception
	 */
	public String delegate(String tokenString, String prcId, String sessId,
			String delegater, String delegatee) throws Exception {
		List<NameValuePair> formparams = new ArrayList<NameValuePair>();
		formparams.add(new BasicNameValuePair("delegater", delegater));
		formparams.add(new BasicNameValuePair("delegatee", delegatee));
		formparams.add(new BasicNameValuePair("prcid", prcId));
		formparams.add(new BasicNameValuePair("sessid", sessId));
		formparams.add(new BasicNameValuePair("token", tokenString));

		URIBuilder builder = new URIBuilder();
		builder.setScheme("http").setHost(hostname)
				.setPath("/cflow/rest/delegation");
		String ret = myPost(builder.build(), formparams);
		if (ret.startsWith("ERROR")) {
			logger.error(ret);
			throw new MwfException(ret);
		}

		return ret;
	}

	public String uploadVt(String tokenString, String content, String vtname)
			throws Exception {

		List<NameValuePair> formparams = new ArrayList<NameValuePair>();
		formparams.add(new BasicNameValuePair("content", content));
		formparams.add(new BasicNameValuePair("vtname", vtname));
		formparams.add(new BasicNameValuePair("token", tokenString));

		URIBuilder builder = new URIBuilder();
		builder.setScheme("http").setHost(hostname).setPath("/cflow/rest/vt");
		String ret = myPost(builder.build(), formparams);
		if (ret.startsWith("ERROR")) {
			logger.error(ret);
			throw new MwfException(ret);
		}
		return ret;
	}

	public String deleteVt(String token, String vtname) throws Exception {
		URIBuilder builder = new URIBuilder();
		builder.setScheme("http").setHost(hostname).setPath("/cflow/rest/vt")
				.setParameter("vtname", vtname).setParameter("token", token);
		String ret = myDelete(builder.build());
		if (ret.startsWith("ERROR")) {
			logger.error(ret);
			throw new MwfException(ret);
		}
		return ret;
	}

	public JSONArray getVts(String tokenString) throws Exception {
		URIBuilder builder = new URIBuilder();
		builder.setScheme("http").setHost(hostname)
				.setPath("/cflow/rest/vt/all")
				.setParameter("token", tokenString);
		String ret = myGet(builder.build());
		if (ret.startsWith("ERROR")) {
			logger.error(ret);
			throw new MwfException(ret);
		} else
			return (JSONArray) parser.parse(ret);
	}

	private String myGet(URI url) throws Exception {
		String ret = null;
		HttpGet httpGet = new HttpGet(url);
		HttpResponse response = httpclient.execute(httpGet, localContext);
		try {
			int statusCode = response.getStatusLine().getStatusCode();
			HttpEntity entity_return = response.getEntity();
			if (statusCode == 200) {
				ret = EntityUtils.toString(entity_return);
			} else {
				String tmp = EntityUtils.toString(entity_return);
				ret = "ERROR[" + statusCode + "]" + tmp;
			}
			EntityUtils.consume(entity_return);
			return ret;
		} finally {
			httpGet.releaseConnection();
		}
	}

	private String myDelete(URI url) throws Exception {
		String ret = null;
		HttpDelete httpDelete = new HttpDelete(url);
		HttpResponse response = httpclient.execute(httpDelete, localContext);
		try {
			int statusCode = response.getStatusLine().getStatusCode();
			HttpEntity entity_return = response.getEntity();
			if (statusCode == 200) {
				ret = EntityUtils.toString(entity_return);
			} else {
				String tmp = EntityUtils.toString(entity_return);
				logger.error("Response status " + statusCode + ": " + tmp);
				ret = "ERROR[" + statusCode + "]" + tmp;
			}
			EntityUtils.consume(entity_return);

			return ret;
		} finally {
			httpDelete.releaseConnection();
		}
	}

	private String myPut(URI url) throws Exception {
		String ret = null;
		HttpPut httpPut = new HttpPut(url);
		HttpResponse response = httpclient.execute(httpPut, localContext);
		try {
			int statusCode = response.getStatusLine().getStatusCode();
			HttpEntity entity_return = response.getEntity();
			if (statusCode == 200) {
				ret = EntityUtils.toString(entity_return);
			} else {
				String tmp = EntityUtils.toString(entity_return);
				logger.error("Response status " + statusCode + ": " + tmp);
				ret = "ERROR[" + statusCode + "]" + tmp;
			}
			EntityUtils.consume(entity_return);

			return ret;
		} finally {
			httpPut.releaseConnection();
		}
	}

	private String myPutForm(URI url, List<NameValuePair> formparams)
			throws Exception {
		String ret = null;

		HttpPut httpPut = new HttpPut(url);
		UrlEncodedFormEntity entity = new UrlEncodedFormEntity(formparams,
				"UTF-8");
		httpPut.setEntity(entity);

		HttpResponse response = httpclient.execute(httpPut, localContext);
		try {
			int statusCode = response.getStatusLine().getStatusCode();
			HttpEntity entity_return = response.getEntity();
			if (statusCode == 200) {
				ret = EntityUtils.toString(entity_return);
			} else {
				String tmp = EntityUtils.toString(entity_return);
				logger.error("Response status " + statusCode + ": " + tmp);
				ret = "ERROR[" + statusCode + "]" + tmp;
			}
			EntityUtils.consume(entity);

			return ret;
		} finally {
			httpPut.releaseConnection();
		}
	}

	private String myPost(URI url, List<NameValuePair> formparams)
			throws Exception {
		String ret = null;

		HttpPost httpPost = new HttpPost(url);
		UrlEncodedFormEntity entity = new UrlEncodedFormEntity(formparams,
				"UTF-8");
		httpPost.setEntity(entity);

		HttpResponse response = httpclient.execute(httpPost, localContext);
		try {
			int statusCode = response.getStatusLine().getStatusCode();
			HttpEntity entity_return = response.getEntity();
			if (statusCode == 200) {
				ret = EntityUtils.toString(entity_return);
			} else {
				String tmp = EntityUtils.toString(entity_return);
				ret = "ERROR[" + statusCode + "]" + tmp;
			}
			EntityUtils.consume(entity);

			return ret;
		} catch (Exception ex) {
			ex.printStackTrace();
			ret = "ERROR: Exception:" + ex.getLocalizedMessage();
			return ret;
		} finally {
			httpPost.releaseConnection();
		}
	}
}
